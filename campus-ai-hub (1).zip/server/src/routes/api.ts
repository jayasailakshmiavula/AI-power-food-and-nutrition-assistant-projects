import { Router } from 'express';
import { authController } from '../controllers/authController.ts';
import { nutritionController } from '../controllers/nutritionController.ts';
import { lostFoundController } from '../controllers/lostFoundController.ts';
import { adminController } from '../controllers/adminController.ts';
import { notificationController } from '../controllers/notificationController.ts';
import { requireAuth, requireAdmin } from '../middleware/auth.ts';

export const apiRouter = Router();

// --- Auth Routes ---
apiRouter.post('/auth/register', authController.register);
apiRouter.post('/auth/login', authController.login);
apiRouter.post('/auth/logout', (req, res) => {
  return res.json({ success: true, message: 'Logged out successfully' });
});
apiRouter.get('/auth/me', requireAuth, authController.me);
apiRouter.put('/auth/profile', requireAuth, authController.updateProfile);

// --- Nutrition Routes ---
apiRouter.get('/nutrition/profile', requireAuth, nutritionController.getProfile);
apiRouter.put('/nutrition/profile', requireAuth, nutritionController.updateProfile);
apiRouter.post('/nutrition/meal-plan/generate', requireAuth, nutritionController.generateMealPlan);
apiRouter.get('/nutrition/meal-plans', requireAuth, nutritionController.getMealPlans);
apiRouter.post('/nutrition/meal-plans', requireAuth, nutritionController.saveMealPlan);
apiRouter.delete('/nutrition/meal-plans/:id', requireAuth, nutritionController.deleteMealPlan);
apiRouter.post('/nutrition/analyze-food', requireAuth, nutritionController.analyzeFood);
apiRouter.get('/nutrition/meal-log', requireAuth, nutritionController.getMealLogs);
apiRouter.post('/nutrition/meal-log', requireAuth, nutritionController.createMealLog);
apiRouter.delete('/nutrition/meal-log/:id', requireAuth, nutritionController.deleteMealLog);
apiRouter.get('/nutrition/daily-summary', requireAuth, nutritionController.getDailySummary);
apiRouter.get('/nutrition/grocery-list', requireAuth, nutritionController.getGroceryList);
apiRouter.post('/nutrition/grocery-list', requireAuth, nutritionController.addGroceryItem);
apiRouter.put('/nutrition/grocery-list/:id', requireAuth, nutritionController.updateGroceryItem);
apiRouter.delete('/nutrition/grocery-list/:id', requireAuth, nutritionController.deleteGroceryItem);
apiRouter.post('/nutrition/grocery-list/from-plan', requireAuth, nutritionController.generateGroceryFromPlan);

// --- Lost & Found Routes ---
apiRouter.get('/lost-found', lostFoundController.getItems);
apiRouter.get('/lost-found/my-items', requireAuth, lostFoundController.getMyItems);
apiRouter.get('/lost-found/all-matches', requireAuth, lostFoundController.getAllMatches);
apiRouter.get('/lost-found/matches/:id', requireAuth, lostFoundController.getItemMatches);
apiRouter.get('/lost-found/:id', lostFoundController.getItemById);
apiRouter.post('/lost-found/lost', requireAuth, lostFoundController.reportLost);
apiRouter.post('/lost-found/found', requireAuth, lostFoundController.reportFound);
apiRouter.put('/lost-found/:id', requireAuth, lostFoundController.updateItem);
apiRouter.delete('/lost-found/:id', requireAuth, lostFoundController.deleteItem);
apiRouter.post('/lost-found/:id/claim', requireAuth, lostFoundController.claimItem);

// --- Admin Routes ---
apiRouter.get('/admin/dashboard', requireAdmin, adminController.getDashboard);
apiRouter.get('/admin/users', requireAdmin, adminController.getUsers);
apiRouter.put('/admin/users/:id', requireAdmin, adminController.updateUser);
apiRouter.delete('/admin/users/:id', requireAdmin, adminController.deleteUser);
apiRouter.get('/admin/items', requireAdmin, adminController.getItems);
apiRouter.put('/admin/items/:id/status', requireAdmin, adminController.updateItemStatus);
apiRouter.delete('/admin/items/:id', requireAdmin, adminController.deleteItem);
apiRouter.get('/admin/claims', requireAdmin, adminController.getClaims);
apiRouter.put('/admin/claims/:id', requireAdmin, adminController.updateClaim);
apiRouter.get('/admin/activity-logs', requireAdmin, adminController.getActivityLogs);

// --- Notification Routes ---
apiRouter.get('/notifications', requireAuth, notificationController.getNotifications);
apiRouter.put('/notifications/read-all', requireAuth, notificationController.markAllRead);
apiRouter.put('/notifications/:id/read', requireAuth, notificationController.markRead);

// --- Image / Media Upload Route ---
apiRouter.post('/upload', requireAuth, (req, res) => {
  const { imageBase64, fileName } = req.body;
  if (!imageBase64) {
    return res.status(400).json({ success: false, message: 'No image data provided' });
  }
  // Accepts base64 data URLs directly for zero-external-dependency local storage & rendering
  return res.json({
    success: true,
    data: {
      url: imageBase64,
      fileName: fileName || 'uploaded_image.jpg',
    },
  });
});
