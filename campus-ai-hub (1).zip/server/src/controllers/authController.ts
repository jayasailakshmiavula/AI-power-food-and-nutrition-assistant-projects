import { Response } from 'express';
import bcrypt from 'bcryptjs';
import { dbStore } from '../db/dbStore.ts';
import { AuthenticatedRequest, signToken } from '../middleware/auth.ts';
import { User } from '../types/index.ts';

export const authController = {
  async register(req: AuthenticatedRequest, res: Response) {
    try {
      const { fullName, email, password, confirmPassword, studentId, department, year, role } = req.body;

      if (!fullName || !email || !password) {
        return res.status(400).json({
          success: false,
          message: 'Full Name, Email, and Password are required.',
        });
      }

      if (password !== confirmPassword) {
        return res.status(400).json({
          success: false,
          message: 'Passwords do not match.',
        });
      }

      if (password.length < 6) {
        return res.status(400).json({
          success: false,
          message: 'Password must be at least 6 characters.',
        });
      }

      const existingUser = dbStore.getUserByEmail(email);
      if (existingUser) {
        return res.status(409).json({
          success: false,
          message: 'An account with this email address already exists.',
        });
      }

      const passwordHash = await bcrypt.hash(password, 10);
      const userRole = role === 'ADMIN' ? 'ADMIN' : 'STUDENT';

      const newUser: User = {
        id: 'usr_' + Math.random().toString(36).substring(2, 9),
        fullName: fullName.trim(),
        email: email.trim().toLowerCase(),
        passwordHash,
        studentId: studentId?.trim(),
        department: department?.trim(),
        year: year?.trim(),
        role: userRole,
        avatarUrl: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(fullName)}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      dbStore.createUser(newUser);
      dbStore.logActivity('New Account Registered', `${newUser.fullName} (${newUser.role}) signed up`, newUser.id, newUser.fullName);

      // Create welcome notification
      dbStore.createNotification({
        id: 'notif_' + Math.random().toString(36).substring(2, 9),
        userId: newUser.id,
        title: 'Welcome to Campus AI Hub!',
        message: 'Explore your AI Nutrition Assistant and Campus Lost & Found portal.',
        type: 'system',
        link: '/dashboard',
        isRead: false,
        createdAt: new Date().toISOString(),
      });

      const token = signToken({
        id: newUser.id,
        email: newUser.email,
        role: newUser.role,
        fullName: newUser.fullName,
      });

      const { passwordHash: _, ...safeUser } = newUser;
      return res.status(201).json({
        success: true,
        message: 'Account created successfully',
        data: {
          token,
          user: safeUser,
        },
      });
    } catch (err: any) {
      console.error('Registration error:', err);
      return res.status(500).json({
        success: false,
        message: err.message || 'Internal server error during registration',
      });
    }
  },

  async login(req: AuthenticatedRequest, res: Response) {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({
          success: false,
          message: 'Email and password are required',
        });
      }

      const user = dbStore.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'Invalid credentials. Please verify your email and password.',
        });
      }

      const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
      if (!isPasswordValid) {
        return res.status(401).json({
          success: false,
          message: 'Invalid credentials. Please verify your email and password.',
        });
      }

      const token = signToken({
        id: user.id,
        email: user.email,
        role: user.role,
        fullName: user.fullName,
      });

      const { passwordHash: _, ...safeUser } = user;
      dbStore.logActivity('User Login', `${user.fullName} logged in`, user.id, user.fullName);

      return res.json({
        success: true,
        message: 'Login successful',
        data: {
          token,
          user: safeUser,
        },
      });
    } catch (err: any) {
      console.error('Login error:', err);
      return res.status(500).json({
        success: false,
        message: 'Internal server error during login',
      });
    }
  },

  async me(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        return res.status(401).json({ success: false, message: 'Unauthorized' });
      }

      const user = dbStore.getUserById(req.user.id);
      if (!user) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }

      const { passwordHash: _, ...safeUser } = user;
      const profile = dbStore.getProfileByUserId(user.id);

      return res.json({
        success: true,
        data: {
          user: safeUser,
          profile,
        },
      });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Error retrieving user details' });
    }
  },

  async updateProfile(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) return res.status(401).json({ success: false, message: 'Unauthorized' });

      const { fullName, studentId, department, year, avatarUrl } = req.body;
      const updated = dbStore.updateUser(req.user.id, {
        ...(fullName && { fullName: fullName.trim() }),
        ...(studentId !== undefined && { studentId }),
        ...(department !== undefined && { department }),
        ...(year !== undefined && { year }),
        ...(avatarUrl && { avatarUrl }),
      });

      if (!updated) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }

      const { passwordHash: _, ...safeUser } = updated;
      return res.json({
        success: true,
        message: 'Profile updated successfully',
        data: safeUser,
      });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Error updating profile' });
    }
  },
};
