import { Response } from 'express';
import { dbStore } from '../db/dbStore.ts';
import { AuthenticatedRequest } from '../middleware/auth.ts';
import { matchingService } from '../services/matchingService.ts';
import { LostFoundItem, Claim } from '../types/index.ts';

let trackingSeq = 140;

export const lostFoundController = {
  async getItems(req: AuthenticatedRequest, res: Response) {
    try {
      const { type, category, location, status, query } = req.query;
      const items = dbStore.getLostFoundItems({
        type: typeof type === 'string' ? type : undefined,
        category: typeof category === 'string' ? category : undefined,
        location: typeof location === 'string' ? location : undefined,
        status: typeof status === 'string' ? status : undefined,
        query: typeof query === 'string' ? query : undefined,
      });

      return res.json({ success: true, count: items.length, data: items });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve lost and found items' });
    }
  },

  async getItemById(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const item = dbStore.getLostFoundItemById(id);
      if (!item) {
        return res.status(404).json({ success: false, message: 'Item not found' });
      }

      const matches = dbStore.getMatchesForItem(item.id);
      const claims = dbStore.getClaims({ itemId: item.id });

      return res.json({
        success: true,
        data: {
          ...item,
          matches,
          claims,
        },
      });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve item details' });
    }
  },

  async reportLost(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user!.id;
      const userName = req.user!.fullName;
      const {
        itemName,
        category,
        description,
        color,
        brand,
        uniqueFeatures,
        location,
        date,
        time,
        imageUrl,
        contactPreference,
      } = req.body;

      if (!itemName || !category || !description || !location || !date) {
        return res.status(400).json({
          success: false,
          message: 'Item name, category, description, location, and date are required.',
        });
      }

      trackingSeq += 1;
      const trackingId = `LF-2026-${String(trackingSeq).padStart(6, '0')}`;

      const newItem: LostFoundItem = {
        id: 'lf_' + Math.random().toString(36).substring(2, 9),
        trackingId,
        type: 'LOST',
        itemName: itemName.trim(),
        category,
        description: description.trim(),
        color: color || 'Unspecified',
        brand: brand?.trim(),
        uniqueFeatures: uniqueFeatures?.trim(),
        location: location.trim(),
        date,
        time: time || '12:00',
        imageUrl: imageUrl || 'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=400&auto=format&fit=crop&q=80',
        contactPreference: contactPreference || 'Campus Lost & Found Portal',
        status: 'LOST',
        reportedByUserId: userId,
        reportedByName: userName,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const savedItem = dbStore.createLostFoundItem(newItem);
      dbStore.logActivity('Reported Lost Item', `${userName} reported ${savedItem.itemName} (${trackingId})`, userId, userName);

      // Run automated AI matching against found items
      matchingService.runAutoMatchForItem(savedItem).catch(err => {
        console.warn('Auto match error on lost report:', err);
      });

      return res.status(201).json({
        success: true,
        message: 'Your lost item has been reported.',
        data: {
          trackingId,
          item: savedItem,
        },
      });
    } catch (err: any) {
      console.error('Error reporting lost item:', err);
      return res.status(500).json({ success: false, message: 'Failed to report lost item' });
    }
  },

  async reportFound(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user!.id;
      const userName = req.user!.fullName;
      const {
        itemName,
        category,
        description,
        color,
        brand,
        uniqueFeatures,
        location,
        date,
        time,
        imageUrl,
        submittedLocation,
      } = req.body;

      if (!itemName || !category || !description || !location || !date) {
        return res.status(400).json({
          success: false,
          message: 'Item name, category, description, location, and date are required.',
        });
      }

      trackingSeq += 1;
      const trackingId = `LF-2026-${String(trackingSeq).padStart(6, '0')}`;

      const newItem: LostFoundItem = {
        id: 'lf_' + Math.random().toString(36).substring(2, 9),
        trackingId,
        type: 'FOUND',
        itemName: itemName.trim(),
        category,
        description: description.trim(),
        color: color || 'Unspecified',
        brand: brand?.trim(),
        uniqueFeatures: uniqueFeatures?.trim(),
        location: location.trim(),
        date,
        time: time || '12:00',
        imageUrl: imageUrl || 'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=400&auto=format&fit=crop&q=80',
        submittedLocation: submittedLocation || 'Campus Security Helpdesk',
        status: 'FOUND',
        reportedByUserId: userId,
        reportedByName: userName,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const savedItem = dbStore.createLostFoundItem(newItem);
      dbStore.logActivity('Reported Found Item', `${userName} deposited ${savedItem.itemName} (${trackingId})`, userId, userName);

      // Run automated AI matching against lost items
      matchingService.runAutoMatchForItem(savedItem).catch(err => {
        console.warn('Auto match error on found report:', err);
      });

      return res.status(201).json({
        success: true,
        message: 'Found item successfully reported.',
        data: {
          trackingId,
          item: savedItem,
        },
      });
    } catch (err: any) {
      console.error('Error reporting found item:', err);
      return res.status(500).json({ success: false, message: 'Failed to report found item' });
    }
  },

  async updateItem(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const item = dbStore.getLostFoundItemById(id);
      if (!item) {
        return res.status(404).json({ success: false, message: 'Item not found' });
      }

      // Ensure user owns item or is admin
      if (item.reportedByUserId !== req.user!.id && req.user!.role !== 'ADMIN') {
        return res.status(403).json({ success: false, message: 'Not authorized to edit this item' });
      }

      const updated = dbStore.updateLostFoundItem(id, req.body);
      return res.json({ success: true, message: 'Item updated successfully', data: updated });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to update item' });
    }
  },

  async deleteItem(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const item = dbStore.getLostFoundItemById(id);
      if (!item) {
        return res.status(404).json({ success: false, message: 'Item not found' });
      }

      if (item.reportedByUserId !== req.user!.id && req.user!.role !== 'ADMIN') {
        return res.status(403).json({ success: false, message: 'Not authorized to delete this item' });
      }

      dbStore.deleteLostFoundItem(id);
      return res.json({ success: true, message: 'Item deleted successfully' });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to delete item' });
    }
  },

  async claimItem(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const userId = req.user!.id;
      const userName = req.user!.fullName;
      const userEmail = req.user!.email;

      const item = dbStore.getLostFoundItemById(id);
      if (!item) {
        return res.status(404).json({ success: false, message: 'Item not found' });
      }

      const { whereLost, whenLost, uniqueFeature, proofNotes } = req.body;
      if (!whereLost || !whenLost || !uniqueFeature) {
        return res.status(400).json({
          success: false,
          message: 'Please provide where you lost it, when you lost it, and a unique identifying feature.',
        });
      }

      const claim: Claim = {
        id: 'clm_' + Math.random().toString(36).substring(2, 9),
        itemId: item.id,
        userId,
        itemTitle: item.itemName,
        claimantName: userName,
        claimantEmail: userEmail,
        whereLost: whereLost.trim(),
        whenLost: whenLost.trim(),
        uniqueFeature: uniqueFeature.trim(),
        proofNotes: proofNotes?.trim(),
        status: 'PENDING',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const savedClaim = dbStore.createClaim(claim);
      dbStore.updateLostFoundItem(item.id, { status: 'CLAIM_PENDING' });

      dbStore.logActivity('New Claim Submitted', `${userName} submitted claim on ${item.itemName}`, userId, userName);

      // Notify the item reporter if not self
      if (item.reportedByUserId !== userId) {
        dbStore.createNotification({
          id: 'notif_' + Math.random().toString(36).substring(2, 9),
          userId: item.reportedByUserId,
          title: 'Claim Submitted on Item',
          message: `${userName} has submitted an ownership claim on "${item.itemName}".`,
          type: 'claim',
          link: `/lost-found/${item.id}`,
          isRead: false,
          createdAt: new Date().toISOString(),
        });
      }

      return res.status(201).json({
        success: true,
        message: 'Claim request submitted for admin review.',
        data: savedClaim,
      });
    } catch (err: any) {
      console.error('Error submitting claim:', err);
      return res.status(500).json({ success: false, message: 'Failed to submit claim' });
    }
  },

  async getMyItems(req: AuthenticatedRequest, res: Response) {
    try {
      const items = dbStore.getLostFoundItems({ userId: req.user!.id });
      const userClaims = dbStore.getClaims({ userId: req.user!.id });
      return res.json({ success: true, data: { items, claims: userClaims } });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve your items' });
    }
  },

  async getItemMatches(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const matches = await matchingService.getMatchesForItem(id);
      return res.json({ success: true, data: matches });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve matches' });
    }
  },

  async getAllMatches(req: AuthenticatedRequest, res: Response) {
    try {
      const matches = dbStore.getItemMatches();
      // Enrich with items details
      const enriched = matches.map(m => {
        const lost = dbStore.getLostFoundItemById(m.lostItemId);
        const found = dbStore.getLostFoundItemById(m.foundItemId);
        return {
          ...m,
          lostItem: lost,
          foundItem: found,
        };
      });
      return res.json({ success: true, data: enriched });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve matches' });
    }
  },
};
