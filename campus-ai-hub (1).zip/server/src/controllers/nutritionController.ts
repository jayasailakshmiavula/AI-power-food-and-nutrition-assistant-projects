import { Response } from 'express';
import { dbStore } from '../db/dbStore.ts';
import { AuthenticatedRequest } from '../middleware/auth.ts';
import { aiService } from '../services/aiService.ts';
import { NutritionProfile, MealPlan, MealLog, GroceryItem } from '../types/index.ts';

export const nutritionController = {
  async getProfile(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user!.id;
      const profile = dbStore.getProfileByUserId(userId);
      return res.json({ success: true, data: profile || null });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve nutrition profile' });
    }
  },

  async updateProfile(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user!.id;
      const {
        age,
        gender,
        height,
        weight,
        activityLevel,
        primaryGoal,
        dietType,
        foodPreferences,
        allergies,
        foodsToAvoid,
        dailyBudget,
        availableIngredients,
        mealsPerDay,
        calorieTarget,
        proteinTarget,
      } = req.body;

      // Smart BMR calculation if calorieTarget not explicitly provided
      const h = Number(height) || 170;
      const w = Number(weight) || 68;
      const a = Number(age) || 21;
      let calculatedCal = calorieTarget;
      let calculatedProt = proteinTarget;

      if (!calculatedCal) {
        // Mifflin-St Jeor formula
        let bmr = 10 * w + 6.25 * h - 5 * a + (gender === 'Female' ? -161 : 5);
        let factor = 1.375; // lightly active
        if (activityLevel === 'Moderately Active') factor = 1.55;
        if (activityLevel === 'Very Active') factor = 1.725;
        if (activityLevel === 'Sedentary') factor = 1.2;

        let maintenance = Math.round(bmr * factor);
        if (primaryGoal === 'Lose Weight') calculatedCal = maintenance - 450;
        else if (primaryGoal === 'Build Muscle' || primaryGoal === 'Gain Weight') calculatedCal = maintenance + 350;
        else calculatedCal = maintenance;
      }

      if (!calculatedProt) {
        if (primaryGoal === 'Build Muscle') calculatedProt = Math.round(w * 1.8);
        else if (primaryGoal === 'Lose Weight') calculatedProt = Math.round(w * 1.6);
        else calculatedProt = Math.round(w * 1.2);
      }

      const existing = dbStore.getProfileByUserId(userId);
      const profile: NutritionProfile = {
        id: existing?.id || 'np_' + Math.random().toString(36).substring(2, 9),
        userId,
        age: Number(age) || 20,
        gender: gender || 'Other',
        height: h,
        weight: w,
        activityLevel: activityLevel || 'Moderately Active',
        primaryGoal: primaryGoal || 'Improve General Health',
        dietType: dietType || 'No Preference',
        foodPreferences: Array.isArray(foodPreferences) ? foodPreferences : [],
        allergies: Array.isArray(allergies) ? allergies : [],
        foodsToAvoid: Array.isArray(foodsToAvoid) ? foodsToAvoid : [],
        dailyBudget: Number(dailyBudget) || 200,
        availableIngredients: Array.isArray(availableIngredients) ? availableIngredients : [],
        mealsPerDay: Number(mealsPerDay) || 3,
        calorieTarget: Number(calculatedCal) || 2000,
        proteinTarget: Number(calculatedProt) || 80,
        createdAt: existing?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const saved = dbStore.saveProfile(profile);
      dbStore.logActivity('Updated Nutrition Profile', `Goal: ${saved.primaryGoal}, Diet: ${saved.dietType}`, userId, req.user!.fullName);

      return res.json({ success: true, message: 'Nutrition profile updated successfully', data: saved });
    } catch (err: any) {
      console.error('Error updating nutrition profile:', err);
      return res.status(500).json({ success: false, message: 'Failed to update nutrition profile' });
    }
  },

  async generateMealPlan(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user!.id;
      const profile = dbStore.getProfileByUserId(userId);

      const {
        goal = profile?.primaryGoal || 'Maintain Weight',
        calories = profile?.calorieTarget || 2200,
        proteinTarget = profile?.proteinTarget || 100,
        budget = profile?.dailyBudget || 250,
        diet = profile?.dietType || 'Vegetarian',
        allergies = profile?.allergies || [],
        foodsToAvoid = profile?.foodsToAvoid || [],
        preferences = profile?.foodPreferences || [],
        availableIngredients = profile?.availableIngredients || [],
      } = req.body;

      const generated = await aiService.generateMealPlan({
        goal,
        calories: Number(calories),
        proteinTarget: Number(proteinTarget),
        budget: Number(budget),
        diet,
        allergies,
        foodsToAvoid,
        preferences,
        availableIngredients,
      });

      return res.json({
        success: true,
        message: 'Personalized meal plan generated successfully',
        data: generated,
      });
    } catch (err: any) {
      console.error('Error generating meal plan:', err);
      return res.status(500).json({ success: false, message: 'Failed to generate meal plan' });
    }
  },

  async getMealPlans(req: AuthenticatedRequest, res: Response) {
    try {
      const plans = dbStore.getMealPlansByUserId(req.user!.id);
      return res.json({ success: true, data: plans });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve meal plans' });
    }
  },

  async saveMealPlan(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user!.id;
      const { title, goal, totalCalories, totalProtein, totalCost, diet, meals } = req.body;

      if (!meals || !Array.isArray(meals)) {
        return res.status(400).json({ success: false, message: 'Meals array is required' });
      }

      const mealPlan: MealPlan = {
        id: 'mp_' + Math.random().toString(36).substring(2, 9),
        userId,
        title: title || 'Saved Campus Meal Plan',
        goal: goal || 'Improve General Health',
        totalCalories: Number(totalCalories) || 2000,
        totalProtein: Number(totalProtein) || 80,
        totalCost: Number(totalCost) || 200,
        diet: diet || 'No Preference',
        meals,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const saved = dbStore.createMealPlan(mealPlan);
      dbStore.logActivity('Saved Meal Plan', `Saved plan "${saved.title}"`, userId, req.user!.fullName);

      dbStore.createNotification({
        id: 'notif_' + Math.random().toString(36).substring(2, 9),
        userId,
        title: 'Meal Plan Saved',
        message: `"${saved.title}" is saved to your meal plans.`,
        type: 'meal_plan',
        link: '/nutrition/meal-planner',
        isRead: false,
        createdAt: new Date().toISOString(),
      });

      return res.status(201).json({ success: true, message: 'Meal plan saved successfully', data: saved });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to save meal plan' });
    }
  },

  async deleteMealPlan(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const success = dbStore.deleteMealPlan(id);
      if (!success) {
        return res.status(404).json({ success: false, message: 'Meal plan not found' });
      }
      return res.json({ success: true, message: 'Meal plan deleted successfully' });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to delete meal plan' });
    }
  },

  async analyzeFood(req: AuthenticatedRequest, res: Response) {
    try {
      const { foodName, ingredients, servingSize, imageBase64 } = req.body;
      if (!foodName && !imageBase64) {
        return res.status(400).json({ success: false, message: 'Food name or image is required for analysis' });
      }

      const result = await aiService.analyzeFood({
        foodName: foodName || 'Campus Food Item',
        ingredients,
        servingSize,
        imageBase64,
      });

      return res.json({ success: true, data: result });
    } catch (err: any) {
      console.error('Error in analyzeFood:', err);
      return res.status(500).json({ success: false, message: 'Failed to analyze food' });
    }
  },

  async getMealLogs(req: AuthenticatedRequest, res: Response) {
    try {
      const { date } = req.query;
      const logs = dbStore.getMealLogs(req.user!.id, typeof date === 'string' ? date : undefined);
      return res.json({ success: true, data: logs });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve meal logs' });
    }
  },

  async createMealLog(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user!.id;
      const { mealType, foodName, calories, protein, carbs, fat, fiber, date } = req.body;

      if (!foodName || calories === undefined) {
        return res.status(400).json({ success: false, message: 'Food name and calories are required' });
      }

      const todayStr = new Date().toISOString().split('T')[0];
      const newLog: MealLog = {
        id: 'ml_' + Math.random().toString(36).substring(2, 9),
        userId,
        mealType: mealType || 'Lunch',
        foodName: foodName.trim(),
        calories: Number(calories) || 0,
        protein: Number(protein) || 0,
        carbs: Number(carbs) || 0,
        fat: Number(fat) || 0,
        fiber: Number(fiber) || 0,
        date: date || todayStr,
        loggedAt: new Date().toISOString(),
      };

      const saved = dbStore.createMealLog(newLog);
      return res.status(201).json({ success: true, message: 'Meal logged successfully', data: saved });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to log meal' });
    }
  },

  async deleteMealLog(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const success = dbStore.deleteMealLog(id);
      if (!success) {
        return res.status(404).json({ success: false, message: 'Meal log not found' });
      }
      return res.json({ success: true, message: 'Meal log removed' });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to delete meal log' });
    }
  },

  async getDailySummary(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user!.id;
      const profile = dbStore.getProfileByUserId(userId);
      const todayStr = new Date().toISOString().split('T')[0];

      const todayLogs = dbStore.getMealLogs(userId, todayStr);

      const caloriesGoal = profile?.calorieTarget || 2200;
      const proteinGoal = profile?.proteinTarget || 120;
      const carbsGoal = Math.round((caloriesGoal * 0.5) / 4);
      const fatGoal = Math.round((caloriesGoal * 0.25) / 9);
      const waterGoal = 3000; // 3 Liters in ml

      const consumedCalories = todayLogs.reduce((sum, l) => sum + l.calories, 0);
      const consumedProtein = todayLogs.reduce((sum, l) => sum + l.protein, 0);
      const consumedCarbs = todayLogs.reduce((sum, l) => sum + l.carbs, 0);
      const consumedFat = todayLogs.reduce((sum, l) => sum + l.fat, 0);
      const consumedFiber = todayLogs.reduce((sum, l) => sum + (l.fiber || 0), 0);

      // Generate 7-day trend for Recharts
      const weeklyProgress = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const dayStr = d.toISOString().split('T')[0];
        const dayLogs = dbStore.getMealLogs(userId, dayStr);
        const dayCals = dayLogs.reduce((s, l) => s + l.calories, 0);
        const dayProt = dayLogs.reduce((s, l) => s + l.protein, 0);

        // day name abbreviation
        const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
        weeklyProgress.push({
          date: dayStr,
          day: dayName,
          calories: dayCals || (i === 0 ? consumedCalories : Math.round(caloriesGoal * (0.85 + (i % 3) * 0.08))),
          target: caloriesGoal,
          protein: dayProt || (i === 0 ? consumedProtein : Math.round(proteinGoal * (0.88 + (i % 2) * 0.06))),
          proteinTarget: proteinGoal,
        });
      }

      const weightProgress = [
        { date: 'Sep 10', weight: (profile?.weight || 72) + 1.8 },
        { date: 'Sep 17', weight: (profile?.weight || 72) + 1.2 },
        { date: 'Sep 24', weight: (profile?.weight || 72) + 0.6 },
        { date: 'Oct 01', weight: (profile?.weight || 72) + 0.2 },
        { date: 'Today', weight: profile?.weight || 72 },
      ];

      return res.json({
        success: true,
        data: {
          todayDate: todayStr,
          goals: {
            calories: caloriesGoal,
            protein: proteinGoal,
            carbs: carbsGoal,
            fat: fatGoal,
            water: waterGoal,
          },
          consumed: {
            calories: consumedCalories,
            protein: Math.round(consumedProtein),
            carbs: Math.round(consumedCarbs),
            fat: Math.round(consumedFat),
            fiber: Math.round(consumedFiber),
            water: 2200, // mock logged 2.2L
          },
          percentages: {
            calories: Math.min(Math.round((consumedCalories / caloriesGoal) * 100), 100),
            protein: Math.min(Math.round((consumedProtein / proteinGoal) * 100), 100),
            carbs: Math.min(Math.round((consumedCarbs / carbsGoal) * 100), 100),
            fat: Math.min(Math.round((consumedFat / fatGoal) * 100), 100),
          },
          todayLogs,
          weeklyProgress,
          weightProgress,
        },
      });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to compute daily summary' });
    }
  },

  async getGroceryList(req: AuthenticatedRequest, res: Response) {
    try {
      const items = dbStore.getGroceryItems(req.user!.id);
      const totalEstimated = items.reduce((sum, item) => sum + (item.purchased ? 0 : item.estimatedPrice), 0);
      return res.json({ success: true, data: { items, estimatedTotal: totalEstimated } });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve grocery list' });
    }
  },

  async addGroceryItem(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user!.id;
      const { name, category, quantity, estimatedPrice } = req.body;

      if (!name) {
        return res.status(400).json({ success: false, message: 'Item name is required' });
      }

      const item: GroceryItem = {
        id: 'gi_' + Math.random().toString(36).substring(2, 9),
        userId,
        name: name.trim(),
        category: category || 'Other',
        quantity: quantity || '1 unit',
        estimatedPrice: Number(estimatedPrice) || 50,
        purchased: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const saved = dbStore.createGroceryItem(item);
      return res.status(201).json({ success: true, message: 'Item added', data: saved });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to add grocery item' });
    }
  },

  async updateGroceryItem(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const updates = req.body;
      const updated = dbStore.updateGroceryItem(id, updates);
      if (!updated) {
        return res.status(404).json({ success: false, message: 'Grocery item not found' });
      }
      return res.json({ success: true, data: updated });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to update grocery item' });
    }
  },

  async deleteGroceryItem(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const success = dbStore.deleteGroceryItem(id);
      if (!success) {
        return res.status(404).json({ success: false, message: 'Grocery item not found' });
      }
      return res.json({ success: true, message: 'Item deleted' });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to delete grocery item' });
    }
  },

  async generateGroceryFromPlan(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user!.id;
      const { mealPlanId } = req.body;
      let plan: MealPlan | undefined;

      if (mealPlanId) {
        plan = dbStore.getMealPlanById(mealPlanId);
      } else {
        const plans = dbStore.getMealPlansByUserId(userId);
        plan = plans[0];
      }

      if (!plan || !plan.meals) {
        return res.status(400).json({ success: false, message: 'No meal plan found to generate groceries from' });
      }

      // Parse ingredients and categorize into requested grocery categories:
      // Vegetables, Fruits, Grains, Protein, Dairy, Spices, Other
      const categorizedItems: GroceryItem[] = [];

      const categorize = (ing: string): 'Vegetables' | 'Fruits' | 'Grains' | 'Protein' | 'Dairy' | 'Spices' | 'Other' => {
        const l = ing.toLowerCase();
        if (l.includes('spinach') || l.includes('broccoli') || l.includes('carrot') || l.includes('onion') || l.includes('tomato') || l.includes('bell pepper') || l.includes('cucumber') || l.includes('zucchini')) return 'Vegetables';
        if (l.includes('banana') || l.includes('apple') || l.includes('berry') || l.includes('berries') || l.includes('orange') || l.includes('lemon')) return 'Fruits';
        if (l.includes('oats') || l.includes('rice') || l.includes('quinoa') || l.includes('roti') || l.includes('toast') || l.includes('bread') || l.includes('chana') || l.includes('lentils') || l.includes('dal')) return 'Grains';
        if (l.includes('egg') || l.includes('chicken') || l.includes('fish') || l.includes('tofu') || l.includes('soya') || l.includes('whey')) return 'Protein';
        if (l.includes('milk') || l.includes('curd') || l.includes('yogurt') || l.includes('paneer') || l.includes('cheese')) return 'Dairy';
        if (l.includes('cinnamon') || l.includes('turmeric') || l.includes('cumin') || l.includes('salt') || l.includes('garlic') || l.includes('seeds')) return 'Spices';
        return 'Other';
      };

      const seen = new Set<string>();

      for (const meal of plan.meals) {
        for (const ing of meal.ingredients) {
          const cleanName = ing.replace(/\d+g|\d+ml|\d+\s*(cups?|tbsp|tsp|slices?|pcs|cup)/gi, '').trim();
          if (!seen.has(cleanName.toLowerCase()) && cleanName.length > 2) {
            seen.add(cleanName.toLowerCase());
            categorizedItems.push({
              id: 'gi_' + Math.random().toString(36).substring(2, 9),
              userId,
              name: ing,
              category: categorize(ing),
              quantity: 'Weekly supply',
              estimatedPrice: Math.floor(Math.random() * 80) + 35,
              purchased: false,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            });
          }
        }
      }

      const savedList = dbStore.setGroceryItems(userId, categorizedItems);
      return res.json({
        success: true,
        message: 'Grocery list generated from meal plan',
        data: { items: savedList },
      });
    } catch (err: any) {
      console.error('Error generating grocery list:', err);
      return res.status(500).json({ success: false, message: 'Failed to generate grocery list' });
    }
  },
};
