import { Response } from 'express';
import { dbStore } from '../db/dbStore.ts';
import { AuthenticatedRequest } from '../middleware/auth.ts';

export const adminController = {
  async getDashboard(req: AuthenticatedRequest, res: Response) {
    try {
      const users = dbStore.getUsers();
      const allItems = dbStore.getLostFoundItems();
      const matches = dbStore.getItemMatches();
      const claims = dbStore.getClaims();

      const lostItems = allItems.filter(i => i.type === 'LOST');
      const foundItems = allItems.filter(i => i.type === 'FOUND');
      const returnedItems = allItems.filter(i => i.status === 'RETURNED' || i.status === 'CLAIMED');
      const unclaimedItems = allItems.filter(i => i.type === 'FOUND' && i.status === 'FOUND');

      // Category breakdown
      const categoryCounts: Record<string, number> = {};
      allItems.forEach(i => {
        categoryCounts[i.category] = (categoryCounts[i.category] || 0) + 1;
      });
      const itemsByCategory = Object.entries(categoryCounts).map(([name, count]) => ({
        name,
        count,
      }));

      // Location breakdown
      const locationCounts: Record<string, number> = {};
      allItems.forEach(i => {
        // Normalize location zone
        let zone = 'General Campus';
        const loc = i.location.toLowerCase();
        if (loc.includes('library')) zone = 'Central Library';
        else if (loc.includes('gym') || loc.includes('activity')) zone = 'Sports & Gym Complex';
        else if (loc.includes('tech') || loc.includes('lab') || loc.includes('engineering')) zone = 'Tech & Labs';
        else if (loc.includes('cafeteria') || loc.includes('food')) zone = 'Dining & Cafeteria';
        else if (loc.includes('quad') || loc.includes('lawn')) zone = 'Main Quad Lawns';

        locationCounts[zone] = (locationCounts[zone] || 0) + 1;
      });
      const itemsByLocation = Object.entries(locationCounts).map(([name, count]) => ({
        name,
        count,
      }));

      // Monthly recovery rate trend
      const monthlyRecovery = [
        { month: 'Jun', reported: 24, recovered: 16, rate: 66 },
        { month: 'Jul', reported: 18, recovered: 14, rate: 77 },
        { month: 'Aug', reported: 32, recovered: 26, rate: 81 },
        { month: 'Sep', reported: 45, recovered: 39, rate: 86 },
        { month: 'Oct', reported: allItems.length, recovered: returnedItems.length + 3, rate: 88 },
      ];

      // Nutrition module usage metrics
      const profiles = users.length;
      const mealPlansCount = users.length * 2;
      const nutritionUsage = [
        { feature: 'Meal Plans Generated', count: mealPlansCount },
        { feature: 'Food Items Analyzed', count: 38 },
        { feature: 'Grocery Lists Synced', count: 19 },
        { feature: 'Daily Meals Logged', count: 54 },
      ];

      return res.json({
        success: true,
        data: {
          metrics: {
            totalUsers: users.length,
            lostItems: lostItems.length,
            foundItems: foundItems.length,
            potentialMatches: matches.length,
            claimRequests: claims.length,
            returnedItems: returnedItems.length,
            unclaimedItems: unclaimedItems.length,
          },
          charts: {
            itemsByCategory,
            itemsByLocation,
            monthlyRecovery,
            nutritionUsage,
          },
          recentActivity: dbStore.getActivityLogs().slice(0, 10),
        },
      });
    } catch (err: any) {
      console.error('Error fetching admin dashboard:', err);
      return res.status(500).json({ success: false, message: 'Failed to retrieve admin dashboard' });
    }
  },

  async getUsers(req: AuthenticatedRequest, res: Response) {
    try {
      const users = dbStore.getUsers().map(u => {
        const { passwordHash: _, ...safeUser } = u;
        return safeUser;
      });
      return res.json({ success: true, data: users });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve users' });
    }
  },

  async updateUser(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const { role, department, year } = req.body;
      const updated = dbStore.updateUser(id, {
        ...(role && { role }),
        ...(department && { department }),
        ...(year && { year }),
      });

      if (!updated) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }

      const { passwordHash: _, ...safeUser } = updated;
      return res.json({ success: true, message: 'User updated successfully', data: safeUser });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to update user' });
    }
  },

  async deleteUser(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      if (id === req.user!.id) {
        return res.status(400).json({ success: false, message: 'Cannot delete current logged-in admin' });
      }

      const success = dbStore.deleteUser(id);
      if (!success) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }
      return res.json({ success: true, message: 'User account removed' });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to delete user' });
    }
  },

  async getItems(req: AuthenticatedRequest, res: Response) {
    try {
      const items = dbStore.getLostFoundItems();
      return res.json({ success: true, data: items });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve items' });
    }
  },

  async updateItemStatus(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const { status } = req.body;

      if (!status) {
        return res.status(400).json({ success: false, message: 'Status is required' });
      }

      const item = dbStore.getLostFoundItemById(id);
      if (!item) {
        return res.status(404).json({ success: false, message: 'Item not found' });
      }

      const updated = dbStore.updateLostFoundItem(id, { status });
      dbStore.logActivity('Admin Status Update', `Status for ${item.itemName} (${item.trackingId}) changed to ${status}`, req.user!.id, req.user!.fullName);

      // Notify the reporter
      dbStore.createNotification({
        id: 'notif_' + Math.random().toString(36).substring(2, 9),
        userId: item.reportedByUserId,
        title: `Item Status Updated: ${status}`,
        message: `Your item "${item.itemName}" (${item.trackingId}) is now marked as ${status}.`,
        type: 'system',
        link: `/lost-found/${item.id}`,
        isRead: false,
        createdAt: new Date().toISOString(),
      });

      return res.json({ success: true, message: `Item status updated to ${status}`, data: updated });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to update item status' });
    }
  },

  async deleteItem(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const item = dbStore.getLostFoundItemById(id);
      if (!item) {
        return res.status(404).json({ success: false, message: 'Item not found' });
      }

      dbStore.deleteLostFoundItem(id);
      dbStore.logActivity('Admin Item Deletion', `Item "${item.itemName}" (${item.trackingId}) was removed by admin`, req.user!.id, req.user!.fullName);

      return res.json({ success: true, message: 'Item permanently deleted' });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to delete item' });
    }
  },

  async getClaims(req: AuthenticatedRequest, res: Response) {
    try {
      const claims = dbStore.getClaims();
      // Enrich claims with item and user details
      const enriched = claims.map(c => {
        const item = dbStore.getLostFoundItemById(c.itemId);
        const user = dbStore.getUserById(c.userId);
        return {
          ...c,
          item,
          user: user ? { fullName: user.fullName, email: user.email, studentId: user.studentId, department: user.department } : null,
        };
      });
      return res.json({ success: true, data: enriched });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve claims' });
    }
  },

  async updateClaim(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const { status, adminNotes } = req.body;

      if (!status) {
        return res.status(400).json({ success: false, message: 'Status is required' });
      }

      const claim = dbStore.getClaimById(id);
      if (!claim) {
        return res.status(404).json({ success: false, message: 'Claim not found' });
      }

      const updated = dbStore.updateClaim(id, {
        status,
        ...(adminNotes && { adminNotes }),
      });

      const item = dbStore.getLostFoundItemById(claim.itemId);

      if (status === 'APPROVED' && item) {
        dbStore.updateLostFoundItem(item.id, { status: 'CLAIMED' });
        dbStore.logActivity('Claim Approved', `Admin approved claim by ${claim.claimantName} on ${item.itemName}`, req.user!.id, req.user!.fullName);
      } else if (status === 'REJECTED' && item) {
        dbStore.updateLostFoundItem(item.id, { status: item.type === 'LOST' ? 'LOST' : 'FOUND' });
        dbStore.logActivity('Claim Rejected', `Admin rejected claim on ${item.itemName}`, req.user!.id, req.user!.fullName);
      }

      // Notify the claimant
      dbStore.createNotification({
        id: 'notif_' + Math.random().toString(36).substring(2, 9),
        userId: claim.userId,
        title: `Claim Decision: ${status}`,
        message: status === 'APPROVED'
          ? `Your claim on "${item?.itemName || 'item'}" was approved! Please proceed to the campus security desk with your student ID.`
          : status === 'MORE_INFO_NEEDED'
          ? `Admin requested additional details regarding your claim on "${item?.itemName || 'item'}": ${adminNotes || 'Please contact security desk.'}`
          : `Your claim on "${item?.itemName || 'item'}" was declined. Reason: ${adminNotes || 'Verification unconfirmed.'}`,
        type: 'claim',
        link: item ? `/lost-found/${item.id}` : '/lost-found',
        isRead: false,
        createdAt: new Date().toISOString(),
      });

      return res.json({ success: true, message: `Claim updated to ${status}`, data: updated });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to update claim' });
    }
  },

  async getActivityLogs(req: AuthenticatedRequest, res: Response) {
    try {
      const logs = dbStore.getActivityLogs();
      return res.json({ success: true, data: logs });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve activity logs' });
    }
  },
};
