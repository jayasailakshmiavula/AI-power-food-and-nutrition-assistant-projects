import { Response } from 'express';
import { dbStore } from '../db/dbStore.ts';
import { AuthenticatedRequest } from '../middleware/auth.ts';

export const notificationController = {
  async getNotifications(req: AuthenticatedRequest, res: Response) {
    try {
      const notifs = dbStore.getNotifications(req.user!.id);
      const unreadCount = notifs.filter(n => !n.isRead).length;
      return res.json({ success: true, count: notifs.length, unreadCount, data: notifs });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to retrieve notifications' });
    }
  },

  async markRead(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const success = dbStore.markNotificationAsRead(id, req.user!.id);
      return res.json({ success, message: success ? 'Marked as read' : 'Notification not found' });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to update notification' });
    }
  },

  async markAllRead(req: AuthenticatedRequest, res: Response) {
    try {
      dbStore.markAllNotificationsAsRead(req.user!.id);
      return res.json({ success: true, message: 'All notifications marked as read' });
    } catch (err: any) {
      return res.status(500).json({ success: false, message: 'Failed to update notifications' });
    }
  },
};
