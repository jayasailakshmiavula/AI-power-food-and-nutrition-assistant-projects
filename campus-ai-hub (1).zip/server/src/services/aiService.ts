import { GoogleGenAI } from '@google/genai';
import { MealItem, LostFoundItem } from '../types/index.ts';

// Configurable via environment variables as requested:
// GEMINI_API_KEY or AI_API_KEY
const apiKey = process.env.AI_API_KEY || process.env.GEMINI_API_KEY;
const modelName = process.env.AI_MODEL || 'gemini-3.8-flash';

let genAIClient: GoogleGenAI | null = null;
if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  try {
    genAIClient = new GoogleGenAI({ apiKey });
  } catch (err) {
    console.warn('Could not initialize GoogleGenAI client, will use intelligent fallback:', err);
  }
}

export interface MealPlanInput {
  goal: string;
  calories: number;
  proteinTarget: number;
  budget: number;
  diet: string;
  allergies: string[];
  foodsToAvoid: string[];
  preferences: string[];
  availableIngredients: string[];
  mealsPerDay?: number;
}

export interface FoodAnalysisResult {
  foodName: string;
  servingSize: string;
  calories: number;
  protein: number;
  carbohydrates: number;
  fat: number;
  fiber: number;
  sugar: number;
  score: number; // 0-100
  summary: string;
  keyHighlights: string[];
  healthierAlternatives: string[];
}

export interface MatchAnalysisResult {
  score: number;
  reasons: string[];
  confidenceLevel: 'HIGH' | 'MEDIUM' | 'LOW';
  notes?: string;
}

export const aiService = {
  /**
   * Generates a tailored campus meal plan respecting budget, allergies, and nutritional goals.
   */
  async generateMealPlan(input: MealPlanInput): Promise<{
    title: string;
    totalCalories: number;
    totalProtein: number;
    totalCost: number;
    diet: string;
    meals: MealItem[];
  }> {
    if (genAIClient) {
      try {
        const prompt = `You are an expert sports and campus nutritionist. Create a 1-day personalized meal plan for a university student.
Strict constraints to respect:
- Goal: ${input.goal}
- Calorie Target: approximately ${input.calories} kcal
- Protein Target: approximately ${input.proteinTarget}g
- Daily Budget: approximately ₹${input.budget}
- Diet Type: ${input.diet}
- ALLERGIES (CRITICAL: NEVER INCLUDE ANY OF THESE INGREDIENTS): ${input.allergies.join(', ') || 'None'}
- Foods to Avoid: ${input.foodsToAvoid.join(', ') || 'None'}
- Food Preferences: ${input.preferences.join(', ') || 'Any'}
- Available ingredients in pantry: ${input.availableIngredients.join(', ') || 'None'}

Return ONLY a valid JSON object without markdown formatting, adhering to this exact schema:
{
  "title": "string plan title",
  "totalCalories": number,
  "totalProtein": number,
  "totalCost": number,
  "diet": "${input.diet}",
  "meals": [
    {
      "mealType": "Breakfast",
      "mealName": "string",
      "ingredients": ["ingredient 1 with amount", "ingredient 2"],
      "servingSize": "string",
      "calories": number,
      "protein": number,
      "carbs": number,
      "fat": number,
      "fiber": number,
      "preparationInstructions": "step by step quick instructions for a busy student",
      "estimatedCost": number
    },
    {
      "mealType": "Lunch",
      "mealName": "string",
      "ingredients": ["..."],
      "servingSize": "string",
      "calories": number,
      "protein": number,
      "carbs": number,
      "fat": number,
      "fiber": number,
      "preparationInstructions": "...",
      "estimatedCost": number
    },
    {
      "mealType": "Snack",
      "mealName": "string",
      "ingredients": ["..."],
      "servingSize": "string",
      "calories": number,
      "protein": number,
      "carbs": number,
      "fat": number,
      "fiber": number,
      "preparationInstructions": "...",
      "estimatedCost": number
    },
    {
      "mealType": "Dinner",
      "mealName": "string",
      "ingredients": ["..."],
      "servingSize": "string",
      "calories": number,
      "protein": number,
      "carbs": number,
      "fat": number,
      "fiber": number,
      "preparationInstructions": "...",
      "estimatedCost": number
    }
  ]
}`;

        const response = await genAIClient.models.generateContent({
          model: modelName,
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          },
        });

        const text = response.text?.trim();
        if (text) {
          const parsed = JSON.parse(text);
          if (parsed.meals && Array.isArray(parsed.meals) && parsed.meals.length > 0) {
            return parsed;
          }
        }
      } catch (err) {
        console.warn('Gemini API call failed, falling back to smart procedural planner:', err);
      }
    }

    // High quality procedural AI fallback
    return generateFallbackMealPlan(input);
  },

  /**
   * Analyzes food items and provides nutritional breakdown, health score, and healthier substitutes.
   */
  async analyzeFood(input: {
    foodName: string;
    ingredients?: string;
    servingSize?: string;
    imageBase64?: string;
  }): Promise<FoodAnalysisResult> {
    if (genAIClient) {
      try {
        const prompt = `Analyze this food item for a campus student:
Food: ${input.foodName}
Ingredients listed: ${input.ingredients || 'Standard recipe'}
Serving Size: ${input.servingSize || '1 standard serving'}

Return ONLY a valid JSON object matching this schema:
{
  "foodName": "${input.foodName}",
  "servingSize": "string",
  "calories": number,
  "protein": number,
  "carbohydrates": number,
  "fat": number,
  "fiber": number,
  "sugar": number,
  "score": number (0 to 100),
  "summary": "2-3 sentences concise nutritional overview",
  "keyHighlights": ["point 1", "point 2", "point 3"],
  "healthierAlternatives": ["alternative 1 with brief reason", "alternative 2"]
}`;

        const contents: any[] = [{ text: prompt }];
        if (input.imageBase64 && input.imageBase64.includes(';base64,')) {
          const [mimePart, dataPart] = input.imageBase64.split(';base64,');
          const mimeType = mimePart.replace('data:', '') || 'image/jpeg';
          contents.push({
            inlineData: {
              mimeType,
              data: dataPart,
            },
          });
        }

        const response = await genAIClient.models.generateContent({
          model: modelName,
          contents,
          config: {
            responseMimeType: 'application/json',
          },
        });

        const text = response.text?.trim();
        if (text) {
          return JSON.parse(text);
        }
      } catch (err) {
        console.warn('Gemini food analysis failed, using smart fallback analysis:', err);
      }
    }

    return generateFallbackFoodAnalysis(input.foodName, input.servingSize || '1 serving (250g)');
  },

  /**
   * Evaluates semantic similarity between a lost item report and a found item record.
   */
  async matchLostFoundItems(lost: LostFoundItem, found: LostFoundItem): Promise<MatchAnalysisResult> {
    if (genAIClient) {
      try {
        const prompt = `You are an AI Campus Security assistant comparing a reported Lost item with a Found item.
LOST ITEM:
- Name: ${lost.itemName}
- Category: ${lost.category}
- Description: ${lost.description}
- Color: ${lost.color}
- Brand: ${lost.brand || 'Unspecified'}
- Unique features: ${lost.uniqueFeatures || 'None listed'}
- Location lost: ${lost.location}
- Date: ${lost.date}

FOUND ITEM:
- Name: ${found.itemName}
- Category: ${found.category}
- Description: ${found.description}
- Color: ${found.color}
- Brand: ${found.brand || 'Unspecified'}
- Unique features: ${found.uniqueFeatures || 'None listed'}
- Location found: ${found.location}
- Date: ${found.date}

Analyze semantic and physical likelihood that these refer to the SAME object.
Respond with ONLY valid JSON:
{
  "score": number between 0 and 100,
  "reasons": ["reason 1 (starts with checkmark or symbol)", "reason 2", "reason 3"],
  "confidenceLevel": "HIGH" | "MEDIUM" | "LOW",
  "notes": "brief evaluation note"
}`;

        const response = await genAIClient.models.generateContent({
          model: modelName,
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          },
        });

        const text = response.text?.trim();
        if (text) {
          return JSON.parse(text);
        }
      } catch (err) {
        console.warn('Gemini item matching call failed, using heuristic matching engine:', err);
      }
    }

    return calculateHeuristicMatch(lost, found);
  },
};

// --- Procedural Fallbacks ---

function generateFallbackMealPlan(input: MealPlanInput) {
  const isVeg = input.diet === 'Vegetarian' || input.diet === 'Vegan';
  const isVegan = input.diet === 'Vegan';
  const targetCals = input.calories || 2200;
  const targetProt = input.proteinTarget || 110;
  const targetBudget = input.budget || 250;

  const breakfastCost = Math.round(targetBudget * 0.22);
  const lunchCost = Math.round(targetBudget * 0.35);
  const snackCost = Math.round(targetBudget * 0.18);
  const dinnerCost = Math.round(targetBudget * 0.25);

  const meals: MealItem[] = [
    {
      mealType: 'Breakfast',
      mealName: isVegan
        ? 'Creamy Soy Milk Chia Oats with Banana & Flaxseeds'
        : isVeg
        ? 'High-Protein Paneer Bhurji with Multigrain Toast'
        : '3-Egg Spinach Omelet with Avocado & Whole Wheat Toast',
      ingredients: isVegan
        ? ['Rolled oats 60g', 'Soy milk 200ml', 'Chia seeds 10g', '1 sliced Banana', 'Ground cinnamon']
        : isVeg
        ? ['Cottage cheese (Paneer) 100g', 'Multigrain bread 2 slices', 'Onions & tomatoes diced', 'Turmeric & cumin']
        : ['Whole eggs x2 + egg whites x2', 'Baby spinach 50g', 'Whole wheat toast 2 slices', 'Olive oil 1 tsp'],
      servingSize: '1 generous bowl (320g)',
      calories: Math.round(targetCals * 0.25),
      protein: Math.round(targetProt * 0.26),
      carbs: Math.round((targetCals * 0.25 * 0.45) / 4),
      fat: Math.round((targetCals * 0.25 * 0.25) / 9),
      fiber: 8,
      preparationInstructions: 'Lightly sauté aromatics in a skillet, fold in protein and serve fresh alongside toasted whole grains.',
      estimatedCost: breakfastCost,
    },
    {
      mealType: 'Lunch',
      mealName: isVegan
        ? 'Hearty Chickpea & Quinoa Buddha Bowl with Tahini Dressing'
        : isVeg
        ? 'Spiced Rajma Masala & Brown Rice with Fresh Cucumber Raita'
        : 'Herbed Grilled Chicken Breast Bowl with Brown Rice & Steamed Veggies',
      ingredients: isVegan
        ? ['Boiled chickpeas 150g', 'Cooked quinoa 1 cup', 'Cucumber & tomatoes', 'Tahini 1 tbsp', 'Lemon juice']
        : isVeg
        ? ['Kidney beans (Rajma) 150g', 'Steamed brown rice 1 cup', 'Low-fat curd 100g', 'Tomato gravy']
        : ['Chicken breast 150g', 'Steamed brown rice 1 cup', 'Broccoli florets 80g', 'Garlic herb seasoning'],
      servingSize: '1 power plate (450g)',
      calories: Math.round(targetCals * 0.35),
      protein: Math.round(targetProt * 0.36),
      carbs: Math.round((targetCals * 0.35 * 0.48) / 4),
      fat: Math.round((targetCals * 0.35 * 0.22) / 9),
      fiber: 12,
      preparationInstructions: 'Assemble warm grains as the base, arrange proteins and greens, drizzle with light seasoning.',
      estimatedCost: lunchCost,
    },
    {
      mealType: 'Snack',
      mealName: isVegan
        ? 'Crispy Roasted Chana with Green Apple Slices'
        : 'Campus Greek Yogurt Cup with Mixed Berries & Pumpkin Seeds',
      ingredients: isVegan
        ? ['Roasted Bengal gram 40g', '1 crisp Green Apple', 'Rock salt & chaat masala']
        : ['Plain Greek yogurt / hung curd 150g', 'Frozen berries 50g', 'Pumpkin seeds 1 tbsp', 'Honey 1 tsp'],
      servingSize: '1 energy snack (200g)',
      calories: Math.round(targetCals * 0.15),
      protein: Math.round(targetProt * 0.14),
      carbs: Math.round((targetCals * 0.15 * 0.50) / 4),
      fat: Math.round((targetCals * 0.15 * 0.20) / 9),
      fiber: 6,
      preparationInstructions: 'Quick zero-prep energy boost ideal for library study breaks.',
      estimatedCost: snackCost,
    },
    {
      mealType: 'Dinner',
      mealName: isVegan
        ? 'Tofu Green Pea Stir-Fry with Multigrain Flatbread'
        : isVeg
        ? 'Yellow Moong Dal Tadka, Grilled Paneer & Fresh Rotis'
        : 'Pan-Seared Fish/Chicken with Sweet Potato Mash & Sauteed Greens',
      ingredients: isVegan
        ? ['Firm tofu 140g', 'Green peas 50g', 'Multigrain chapati 2 pcs', 'Soy ginger sauce']
        : isVeg
        ? ['Yellow moong dal 1 bowl', 'Low-fat paneer 80g', 'Whole wheat chapatis 2 pcs', 'Fresh coriander']
        : ['Lean chicken/fish 140g', 'Roasted sweet potato 150g', 'Zucchini & bell peppers', 'Olive oil 1 tsp'],
      servingSize: '1 balanced dinner (400g)',
      calories: Math.round(targetCals * 0.25),
      protein: Math.round(targetProt * 0.24),
      carbs: Math.round((targetCals * 0.25 * 0.42) / 4),
      fat: Math.round((targetCals * 0.25 * 0.26) / 9),
      fiber: 9,
      preparationInstructions: 'Pan-sear seasoned protein for 6-8 minutes until golden. Serve hot with warm whole wheat flatbread.',
      estimatedCost: dinnerCost,
    },
  ];

  const totalCals = meals.reduce((sum, m) => sum + m.calories, 0);
  const totalProt = meals.reduce((sum, m) => sum + m.protein, 0);
  const totalCost = meals.reduce((sum, m) => sum + m.estimatedCost, 0);

  return {
    title: `Campus ${input.goal} Plan (${input.diet})`,
    totalCalories: totalCals,
    totalProtein: totalProt,
    totalCost,
    diet: input.diet,
    meals,
  };
}

function generateFallbackFoodAnalysis(foodName: string, servingSize: string): FoodAnalysisResult {
  const lower = foodName.toLowerCase();

  let calories = 320;
  let protein = 12;
  let carbohydrates = 42;
  let fat = 11;
  let fiber = 4;
  let sugar = 6;
  let score = 78;
  let summary = `Balanced campus meal option with good energy density.`;
  let highlights = ['Provides sustained carbohydrates', 'Moderate protein content', 'Fits within student daily macro ratios'];
  let alternatives = ['Brown rice substitute for lower glycemic response', 'Add a side of steamed greens for micronutrients'];

  if (lower.includes('pizza') || lower.includes('burger') || lower.includes('fries')) {
    calories = 540;
    protein = 16;
    carbohydrates = 62;
    fat = 26;
    fiber = 2;
    sugar = 8;
    score = 48;
    summary = `High caloric density and elevated sodium/saturated fat levels. Enjoy occasionally.`;
    highlights = ['Elevated saturated fats and sodium', 'Low dietary fiber content', 'Fast digesting refined carbs'];
    alternatives = [
      'Thin crust whole-wheat vegetable wrap',
      'Air-fried sweet potato wedges instead of deep-fried fries',
      'Grilled chicken or bean patty with whole grain bun',
    ];
  } else if (lower.includes('salad') || lower.includes('bowl') || lower.includes('oats')) {
    calories = 290;
    protein = 18;
    carbohydrates = 38;
    fat = 8;
    fiber = 9;
    sugar = 4;
    score = 92;
    summary = `Nutrient-dense powerhouse packed with dietary fiber and clean micronutrients.`;
    highlights = ['Excellent source of soluble fiber', 'Low added sugars and clean glycemic release', 'High vitamin and mineral profile'];
    alternatives = [
      'Sprinkle roasted chia or pumpkin seeds for extra zinc and omega-3s',
      'Top with a dollop of Greek yogurt for a protein boost',
    ];
  } else if (lower.includes('chicken') || lower.includes('paneer') || lower.includes('egg') || lower.includes('protein')) {
    calories = 380;
    protein = 34;
    carbohydrates = 14;
    fat = 15;
    fiber = 3;
    sugar = 2;
    score = 88;
    summary = `High biological value protein meal excellent for muscle recovery and satiety.`;
    highlights = ['High leucine content for muscle protein synthesis', 'Low glycemic index', 'Strong satiety factor'];
    alternatives = [
      'Pair with a side of mixed greens or quinoa for complete nutrient coverage',
      'Use light olive oil spray to keep overall fats optimal',
    ];
  }

  return {
    foodName,
    servingSize,
    calories,
    protein,
    carbohydrates,
    fat,
    fiber,
    sugar,
    score,
    summary,
    keyHighlights: highlights,
    healthierAlternatives: alternatives,
  };
}

export function calculateHeuristicMatch(lost: LostFoundItem, found: LostFoundItem): MatchAnalysisResult {
  let score = 0;
  const reasons: string[] = [];

  // Category match (+35)
  if (lost.category.toLowerCase() === found.category.toLowerCase()) {
    score += 35;
    reasons.push(`✓ Same category: ${lost.category}`);
  }

  // Color match (+20)
  if (lost.color.toLowerCase() === found.color.toLowerCase()) {
    score += 20;
    reasons.push(`✓ Matching color: ${lost.color}`);
  } else if (
    lost.description.toLowerCase().includes(found.color.toLowerCase()) ||
    found.description.toLowerCase().includes(lost.color.toLowerCase())
  ) {
    score += 12;
    reasons.push(`✓ Color mentioned in item description`);
  }

  // Brand match (+20)
  if (lost.brand && found.brand && lost.brand.toLowerCase() === found.brand.toLowerCase()) {
    score += 20;
    reasons.push(`✓ Same manufacturer/brand: ${lost.brand}`);
  } else if (
    (lost.brand && found.itemName.toLowerCase().includes(lost.brand.toLowerCase())) ||
    (found.brand && lost.itemName.toLowerCase().includes(found.brand.toLowerCase()))
  ) {
    score += 15;
    reasons.push(`✓ Brand name identified in item title`);
  }

  // Location similarity (+15)
  const locLost = lost.location.toLowerCase();
  const locFound = found.location.toLowerCase();
  if (locLost.includes(locFound) || locFound.includes(locLost)) {
    score += 15;
    reasons.push(`✓ Found in or near reported location: ${found.location}`);
  } else {
    // Check keywords (library, gym, lab, tech, cafeteria)
    const keywords = ['library', 'gym', 'lab', 'cafeteria', 'quad', 'hall', 'center', 'room'];
    const commonKeyword = keywords.find(k => locLost.includes(k) && locFound.includes(k));
    if (commonKeyword) {
      score += 10;
      reasons.push(`✓ Nearby campus zone match: ${commonKeyword.toUpperCase()}`);
    }
  }

  // Date proximity (+10)
  if (lost.date === found.date) {
    score += 10;
    reasons.push(`✓ Same date recorded (${lost.date})`);
  } else {
    const diffDays = Math.abs(
      (new Date(lost.date).getTime() - new Date(found.date).getTime()) / (1000 * 60 * 60 * 24)
    );
    if (diffDays <= 3) {
      score += 7;
      reasons.push(`✓ Date found within ${Math.round(diffDays)} days of report`);
    }
  }

  // Unique features check
  if (lost.uniqueFeatures && found.uniqueFeatures) {
    const lostWords = lost.uniqueFeatures.toLowerCase().split(/\s+/).filter(w => w.length > 3);
    const foundText = (found.uniqueFeatures + ' ' + found.description).toLowerCase();
    const matchingWords = lostWords.filter(w => foundText.includes(w));
    if (matchingWords.length > 0) {
      score += 10;
      reasons.push(`✓ Corroborating physical identifiers: "${matchingWords.join(', ')}"`);
    }
  }

  // Cap score
  score = Math.min(Math.max(score, 15), 98);
  const confidenceLevel = score >= 75 ? 'HIGH' : score >= 50 ? 'MEDIUM' : 'LOW';

  return {
    score,
    reasons: reasons.length ? reasons : ['General campus item resemblance in category'],
    confidenceLevel,
  };
}
