import { dbStore } from '../db/dbStore.ts';
import { LostFoundItem, ItemMatch } from '../types/index.ts';
import { aiService } from './aiService.ts';

export const matchingService = {
  /**
   * Evaluates a newly reported item against existing items of the opposite type.
   */
  async runAutoMatchForItem(item: LostFoundItem): Promise<ItemMatch[]> {
    const isLost = item.type === 'LOST';
    const targetType = isLost ? 'FOUND' : 'LOST';

    const candidates = dbStore.getLostFoundItems({ type: targetType });
    const matchesFound: ItemMatch[] = [];

    for (const candidate of candidates) {
      // Fast heuristic pre-filter: category match or description keyword overlap
      const isCategoryMatch = candidate.category.toLowerCase() === item.category.toLowerCase();
      const isColorMatch = candidate.color.toLowerCase() === item.color.toLowerCase();
      const isBrandMatch = candidate.brand && item.brand && candidate.brand.toLowerCase() === item.brand.toLowerCase();

      if (isCategoryMatch || isColorMatch || isBrandMatch) {
        const lostItem = isLost ? item : candidate;
        const foundItem = isLost ? candidate : item;

        const analysis = await aiService.matchLostFoundItems(lostItem, foundItem);

        if (analysis.score >= 55) {
          const match: ItemMatch = {
            id: 'match_' + Math.random().toString(36).substring(2, 9),
            lostItemId: lostItem.id,
            foundItemId: foundItem.id,
            lostItemTitle: lostItem.itemName,
            foundItemTitle: foundItem.itemName,
            score: analysis.score,
            reasons: analysis.reasons,
            status: 'PENDING',
            createdAt: new Date().toISOString(),
          };

          const savedMatch = dbStore.createItemMatch(match);
          matchesFound.push(savedMatch);

          // Update statuses to MATCHED if not already claimed
          if (lostItem.status === 'LOST') {
            dbStore.updateLostFoundItem(lostItem.id, { status: 'MATCHED' });
          }
          if (foundItem.status === 'FOUND') {
            dbStore.updateLostFoundItem(foundItem.id, { status: 'MATCHED' });
          }

          // Send notification to the user who reported the lost item
          dbStore.createNotification({
            id: 'notif_' + Math.random().toString(36).substring(2, 9),
            userId: lostItem.reportedByUserId,
            title: `Potential Match Found (${analysis.score}% Match)`,
            message: `A "${foundItem.itemName}" was found in ${foundItem.location} that matches your lost item "${lostItem.itemName}".`,
            type: 'match',
            link: '/lost-found/matches',
            isRead: false,
            createdAt: new Date().toISOString(),
          });
        }
      }
    }

    return matchesFound;
  },

  /**
   * Returns all potential matches for a given item id.
   */
  async getMatchesForItem(itemId: string): Promise<ItemMatch[]> {
    return dbStore.getMatchesForItem(itemId);
  },
};
