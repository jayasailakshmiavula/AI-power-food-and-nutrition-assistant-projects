import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import {
  User,
  NutritionProfile,
  MealPlan,
  MealLog,
  GroceryItem,
  LostFoundItem,
  Claim,
  ItemMatch,
  Notification,
  ActivityLog,
} from '../types/index.ts';

interface DatabaseData {
  users: User[];
  nutritionProfiles: NutritionProfile[];
  mealPlans: MealPlan[];
  mealLogs: MealLog[];
  groceryItems: GroceryItem[];
  lostFoundItems: LostFoundItem[];
  claims: Claim[];
  itemMatches: ItemMatch[];
  notifications: Notification[];
  activityLogs: ActivityLog[];
}

const DATA_FILE = path.resolve(process.cwd(), 'data', 'campus_db.json');

class DatabaseStore {
  private data: DatabaseData = {
    users: [],
    nutritionProfiles: [],
    mealPlans: [],
    mealLogs: [],
    groceryItems: [],
    lostFoundItems: [],
    claims: [],
    itemMatches: [],
    notifications: [],
    activityLogs: [],
  };

  constructor() {
    this.init();
  }

  private init() {
    try {
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        this.data = JSON.parse(raw);
      } else {
        this.seedInitialData();
        this.persist();
      }
    } catch (err) {
      console.warn('Error reading data file, using fresh seeded store:', err);
      this.seedInitialData();
    }
  }

  private persist() {
    try {
      const dir = path.dirname(DATA_FILE);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(DATA_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to write database file:', err);
    }
  }

  private seedInitialData() {
    const studentPasswordHash = bcrypt.hashSync('Password123!', 10);
    const adminPasswordHash = bcrypt.hashSync('AdminPassword123!', 10);

    const studentUser: User = {
      id: 'usr_student_01',
      fullName: 'Aarav Sharma',
      email: 'student@campus.edu',
      passwordHash: studentPasswordHash,
      studentId: 'CS-2023-049',
      department: 'Computer Science & Engineering',
      year: '3rd Year',
      role: 'STUDENT',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      createdAt: '2026-09-01T08:00:00.000Z',
      updatedAt: '2026-10-01T08:00:00.000Z',
    };

    const adminUser: User = {
      id: 'usr_admin_01',
      fullName: 'Prof. Elena Vance',
      email: 'admin@campus.edu',
      passwordHash: adminPasswordHash,
      studentId: 'FAC-8810',
      department: 'Campus Security & Operations',
      year: 'Faculty / Admin',
      role: 'ADMIN',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
      createdAt: '2026-08-15T08:00:00.000Z',
      updatedAt: '2026-10-01T08:00:00.000Z',
    };

    const studentProfile: NutritionProfile = {
      id: 'np_01',
      userId: studentUser.id,
      age: 21,
      gender: 'Male',
      height: 178,
      weight: 72,
      activityLevel: 'Moderately Active',
      primaryGoal: 'Build Muscle',
      dietType: 'High Protein',
      foodPreferences: ['Oatmeal', 'Paneer', 'Eggs', 'Chicken', 'Bananas', 'Brown Rice'],
      allergies: ['Peanuts'],
      foodsToAvoid: ['Deep fried food', 'Refined sugar'],
      dailyBudget: 250,
      availableIngredients: ['Eggs', 'Oats', 'Milk', 'Spinach', 'Rice', 'Lentils', 'Curd'],
      mealsPerDay: 4,
      calorieTarget: 2450,
      proteinTarget: 135,
      createdAt: '2026-09-10T10:00:00.000Z',
      updatedAt: '2026-10-05T12:00:00.000Z',
    };

    const initialMealPlan: MealPlan = {
      id: 'mp_01',
      userId: studentUser.id,
      title: 'High Protein Muscle Builder (Budget Campus Plan)',
      goal: 'Build Muscle',
      totalCalories: 2420,
      totalProtein: 138,
      totalCost: 215,
      diet: 'High Protein',
      meals: [
        {
          mealType: 'Breakfast',
          mealName: 'Banana Nut & Whey Oats Bowl',
          ingredients: ['Rolled oats 60g', 'Low-fat milk 200ml', '1 Banana', 'Chia seeds 10g', 'Egg whites (boiled x2)'],
          servingSize: '1 large bowl (350g)',
          calories: 520,
          protein: 28,
          carbs: 76,
          fat: 10,
          fiber: 9,
          preparationInstructions: 'Boil oats with milk for 4 mins. Slice fresh banana on top, sprinkle chia seeds and serve with boiled egg whites.',
          estimatedCost: 45,
        },
        {
          mealType: 'Lunch',
          mealName: 'Grilled Paneer & Brown Rice Bowl with Dal',
          ingredients: ['Brown rice 150g cooked', 'Paneer cubes 100g', 'Moong dal 1 cup', 'Steamed broccoli & carrots'],
          servingSize: '1 meal container (450g)',
          calories: 680,
          protein: 36,
          carbs: 82,
          fat: 18,
          fiber: 11,
          preparationInstructions: 'Lightly sauté seasoned paneer with turmeric and cumin. Serve alongside warm yellow moong dal, brown rice, and sautéed greens.',
          estimatedCost: 75,
        },
        {
          mealType: 'Snack',
          mealName: 'Campus Pre-Workout Greek Curd & Roasted Chana',
          ingredients: ['Fresh thick curd 150g', 'Roasted chana 40g', 'Apple slices 1 small', 'Cinnamon powder'],
          servingSize: '1 cup snack (220g)',
          calories: 380,
          protein: 22,
          carbs: 48,
          fat: 7,
          fiber: 8,
          preparationInstructions: 'Mix curd with a dash of cinnamon. Eat alongside crisp roasted chana and fresh diced apples.',
          estimatedCost: 35,
        },
        {
          mealType: 'Dinner',
          mealName: 'Tofu/Chicken Stir-Fry with Multigrain Roti',
          ingredients: ['Tofu/Chicken breast 120g', 'Multigrain roti 2 pcs', 'Mixed bell peppers', 'Green salad'],
          servingSize: '1 dinner plate (400g)',
          calories: 840,
          protein: 52,
          carbs: 78,
          fat: 22,
          fiber: 12,
          preparationInstructions: 'Stir fry protein of choice with garlic, soy sauce, and diced peppers. Accompany with warm rotis and a cucumber lemon salad.',
          estimatedCost: 60,
        },
      ],
      createdAt: '2026-10-04T09:00:00.000Z',
      updatedAt: '2026-10-04T09:00:00.000Z',
    };

    const todayDate = new Date().toISOString().split('T')[0];
    const initialMealLogs: MealLog[] = [
      {
        id: 'ml_01',
        userId: studentUser.id,
        mealType: 'Breakfast',
        foodName: 'Banana Nut & Whey Oats Bowl',
        calories: 520,
        protein: 28,
        carbs: 76,
        fat: 10,
        fiber: 9,
        date: todayDate,
        loggedAt: '2026-10-06T08:30:00.000Z',
      },
      {
        id: 'ml_02',
        userId: studentUser.id,
        mealType: 'Lunch',
        foodName: 'Grilled Paneer & Brown Rice Bowl with Dal',
        calories: 680,
        protein: 36,
        carbs: 82,
        fat: 18,
        fiber: 11,
        date: todayDate,
        loggedAt: '2026-10-06T13:15:00.000Z',
      },
    ];

    const initialGrocery: GroceryItem[] = [
      { id: 'gi_01', userId: studentUser.id, name: 'Rolled Oats (1kg)', category: 'Grains', quantity: '1 pack', estimatedPrice: 160, purchased: true, createdAt: '2026-10-04T10:00:00Z', updatedAt: '2026-10-05T10:00:00Z' },
      { id: 'gi_02', userId: studentUser.id, name: 'Fresh Paneer (500g)', category: 'Dairy', quantity: '500g', estimatedPrice: 180, purchased: false, createdAt: '2026-10-04T10:00:00Z', updatedAt: '2026-10-04T10:00:00Z' },
      { id: 'gi_03', userId: studentUser.id, name: 'Eggs (Dozen)', category: 'Protein', quantity: '12 pcs', estimatedPrice: 90, purchased: true, createdAt: '2026-10-04T10:00:00Z', updatedAt: '2026-10-05T10:00:00Z' },
      { id: 'gi_04', userId: studentUser.id, name: 'Bananas & Apples', category: 'Fruits', quantity: '1 kg', estimatedPrice: 120, purchased: false, createdAt: '2026-10-04T10:00:00Z', updatedAt: '2026-10-04T10:00:00Z' },
      { id: 'gi_05', userId: studentUser.id, name: 'Spinach & Bell Peppers', category: 'Vegetables', quantity: '500g', estimatedPrice: 70, purchased: false, createdAt: '2026-10-04T10:00:00Z', updatedAt: '2026-10-04T10:00:00Z' },
      { id: 'gi_06', userId: studentUser.id, name: 'Chia Seeds & Cinnamon', category: 'Spices', quantity: '100g', estimatedPrice: 95, purchased: true, createdAt: '2026-10-04T10:00:00Z', updatedAt: '2026-10-04T10:00:00Z' },
    ];

    // Seeded Lost & Found items
    const lostItem1: LostFoundItem = {
      id: 'lf_lost_01',
      trackingId: 'LF-2026-000123',
      type: 'LOST',
      itemName: 'Black Casio FX-991EX Scientific Calculator',
      category: 'Calculator',
      description: 'Matte black scientific calculator with carbon fiber texture front slip cover. Has a tiny silver sticker on back.',
      color: 'Black',
      brand: 'Casio',
      uniqueFeatures: 'Silver initial sticker "A.S." on bottom edge of sliding cover',
      location: 'Central Library 2nd Floor Study Cubicle 14',
      date: '2026-10-05',
      time: '16:30',
      imageUrl: 'https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?w=400&auto=format&fit=crop&q=80',
      contactPreference: 'Campus Lost & Found Portal / Email',
      status: 'MATCHED',
      reportedByUserId: studentUser.id,
      reportedByName: studentUser.fullName,
      createdAt: '2026-10-05T17:00:00.000Z',
      updatedAt: '2026-10-06T09:00:00.000Z',
    };

    const foundItem1: LostFoundItem = {
      id: 'lf_found_01',
      trackingId: 'LF-2026-000128',
      type: 'FOUND',
      itemName: 'Black Casio FX-991EX Calculator with Cover',
      category: 'Calculator',
      description: 'Found on desk in Library 2nd floor quiet room. Clean condition with protective slip cover.',
      color: 'Black',
      brand: 'Casio',
      uniqueFeatures: 'Has a small metallic sticker near lower hinge corner',
      location: 'Central Library, 2nd Floor Study Desk',
      date: '2026-10-05',
      time: '18:15',
      imageUrl: 'https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?w=400&auto=format&fit=crop&q=80',
      contactPreference: 'Library Helpdesk',
      submittedLocation: 'Central Library Helpdesk - Counter 1',
      status: 'MATCHED',
      reportedByUserId: adminUser.id,
      reportedByName: 'Library Staff (Staff Desk)',
      createdAt: '2026-10-05T18:30:00.000Z',
      updatedAt: '2026-10-06T09:00:00.000Z',
    };

    const lostItem2: LostFoundItem = {
      id: 'lf_lost_02',
      trackingId: 'LF-2026-000124',
      type: 'LOST',
      itemName: 'Pacific Blue Hydro Flask Water Bottle',
      category: 'Bottle',
      description: '32oz wide mouth insulated bottle with black flex cap. Features an astronaut sticker and mountain logo.',
      color: 'Blue',
      brand: 'Hydro Flask',
      uniqueFeatures: 'NASA astronaut sticker with slightly scuffed bottom rim',
      location: 'Student Activity Center Gym',
      date: '2026-10-04',
      time: '11:00',
      imageUrl: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400&auto=format&fit=crop&q=80',
      contactPreference: 'Phone',
      status: 'LOST',
      reportedByUserId: studentUser.id,
      reportedByName: studentUser.fullName,
      createdAt: '2026-10-04T12:00:00.000Z',
      updatedAt: '2026-10-04T12:00:00.000Z',
    };

    const foundItem2: LostFoundItem = {
      id: 'lf_found_02',
      trackingId: 'LF-2026-000130',
      type: 'FOUND',
      itemName: 'University Student ID Card - Mechanical Dept',
      category: 'ID Card',
      description: 'Laminated campus smartcard found near engineering quad bench. Name on card: Rohan Mehta (ME-2024-112).',
      color: 'White',
      brand: 'Campus ID',
      uniqueFeatures: 'Barcode ending in 9841',
      location: 'Engineering Quad Lawn Bench',
      date: '2026-10-06',
      time: '09:20',
      imageUrl: 'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?w=400&auto=format&fit=crop&q=80',
      contactPreference: 'Security Office',
      submittedLocation: 'Campus Security Main Gate Desk',
      status: 'FOUND',
      reportedByUserId: adminUser.id,
      reportedByName: 'Campus Security Guard',
      createdAt: '2026-10-06T09:45:00.000Z',
      updatedAt: '2026-10-06T09:45:00.000Z',
    };

    const foundItem3: LostFoundItem = {
      id: 'lf_found_03',
      trackingId: 'LF-2026-000135',
      type: 'FOUND',
      itemName: 'Navy Blue Lenovo ThinkPad Charger (65W USB-C)',
      category: 'Accessories',
      description: 'Original Lenovo 65W AC Adapter with Type-C connector and coiled cable wrap.',
      color: 'Black',
      brand: 'Lenovo',
      uniqueFeatures: 'Velcro tie with yellow dot',
      location: 'Computer Lab 3, Tech Building',
      date: '2026-10-06',
      time: '14:00',
      imageUrl: 'https://images.unsplash.com/photo-1588508065123-287b28e013da?w=400&auto=format&fit=crop&q=80',
      contactPreference: 'Lab Instructor',
      submittedLocation: 'Tech Building Reception',
      status: 'FOUND',
      reportedByUserId: adminUser.id,
      reportedByName: 'Lab Admin - Tech Dept',
      createdAt: '2026-10-06T14:30:00.000Z',
      updatedAt: '2026-10-06T14:30:00.000Z',
    };

    const match1: ItemMatch = {
      id: 'match_01',
      lostItemId: lostItem1.id,
      foundItemId: foundItem1.id,
      lostItemTitle: lostItem1.itemName,
      foundItemTitle: foundItem1.itemName,
      score: 94,
      reasons: [
        'Same category: Calculator',
        'Same exact model and color: Casio FX-991EX (Black)',
        'Found at Central Library on the same date (Oct 5, 2026)',
        'Matching physical details: Protective slip cover and bottom metallic identifier sticker',
      ],
      status: 'PENDING',
      createdAt: '2026-10-05T18:35:00.000Z',
    };

    const initialNotifications: Notification[] = [
      {
        id: 'notif_01',
        userId: studentUser.id,
        title: 'High Confidence AI Match Found!',
        message: 'A Black Casio FX-991EX Calculator found in Central Library has a 94% match with your lost item (LF-2026-000123).',
        type: 'match',
        link: '/lost-found/matches',
        isRead: false,
        createdAt: '2026-10-05T18:40:00.000Z',
      },
      {
        id: 'notif_02',
        userId: studentUser.id,
        title: 'Weekly Meal Plan Ready',
        message: 'Your high-protein muscle builder meal plan has been generated with automated grocery list sync.',
        type: 'meal_plan',
        link: '/nutrition/meal-planner',
        isRead: true,
        createdAt: '2026-10-04T09:05:00.000Z',
      },
      {
        id: 'notif_03',
        userId: adminUser.id,
        title: 'New Found Item Submitted',
        message: 'A student ID card was deposited at Campus Security Main Gate Desk.',
        type: 'system',
        link: '/admin/items',
        isRead: false,
        createdAt: '2026-10-06T09:50:00.000Z',
      },
    ];

    const initialActivity: ActivityLog[] = [
      {
        id: 'act_01',
        userId: studentUser.id,
        userName: studentUser.fullName,
        action: 'Reported Lost Item',
        details: 'Reported Black Casio FX-991EX (LF-2026-000123) lost in Library',
        createdAt: '2026-10-05T17:00:00.000Z',
      },
      {
        id: 'act_02',
        userId: adminUser.id,
        userName: adminUser.fullName,
        action: 'Registered Found Item',
        details: 'Turned in Casio Calculator LF-2026-000128 to Central Library Helpdesk',
        createdAt: '2026-10-05T18:30:00.000Z',
      },
      {
        id: 'act_03',
        action: 'AI Match Engine',
        details: 'Automated match generated with 94% confidence between LF-2026-000123 & LF-2026-000128',
        createdAt: '2026-10-05T18:35:00.000Z',
      },
    ];

    this.data = {
      users: [studentUser, adminUser],
      nutritionProfiles: [studentProfile],
      mealPlans: [initialMealPlan],
      mealLogs: initialMealLogs,
      groceryItems: initialGrocery,
      lostFoundItems: [lostItem1, foundItem1, lostItem2, foundItem2, foundItem3],
      claims: [],
      itemMatches: [match1],
      notifications: initialNotifications,
      activityLogs: initialActivity,
    };
  }

  // --- Users ---
  getUsers(): User[] {
    return this.data.users;
  }

  getUserById(id: string): User | undefined {
    return this.data.users.find(u => u.id === id);
  }

  getUserByEmail(email: string): User | undefined {
    return this.data.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  createUser(user: User): User {
    this.data.users.push(user);
    this.persist();
    return user;
  }

  updateUser(id: string, updates: Partial<User>): User | undefined {
    const idx = this.data.users.findIndex(u => u.id === id);
    if (idx === -1) return undefined;
    this.data.users[idx] = { ...this.data.users[idx], ...updates, updatedAt: new Date().toISOString() };
    this.persist();
    return this.data.users[idx];
  }

  deleteUser(id: string): boolean {
    const initialLen = this.data.users.length;
    this.data.users = this.data.users.filter(u => u.id !== id);
    if (this.data.users.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  // --- Nutrition Profile ---
  getProfileByUserId(userId: string): NutritionProfile | undefined {
    return this.data.nutritionProfiles.find(p => p.userId === userId);
  }

  saveProfile(profile: NutritionProfile): NutritionProfile {
    const idx = this.data.nutritionProfiles.findIndex(p => p.userId === profile.userId);
    if (idx >= 0) {
      this.data.nutritionProfiles[idx] = { ...profile, updatedAt: new Date().toISOString() };
    } else {
      this.data.nutritionProfiles.push(profile);
    }
    this.persist();
    return profile;
  }

  // --- Meal Plans ---
  getMealPlansByUserId(userId: string): MealPlan[] {
    return this.data.mealPlans.filter(mp => mp.userId === userId);
  }

  getMealPlanById(id: string): MealPlan | undefined {
    return this.data.mealPlans.find(mp => mp.id === id);
  }

  createMealPlan(mealPlan: MealPlan): MealPlan {
    this.data.mealPlans.unshift(mealPlan);
    this.persist();
    return mealPlan;
  }

  deleteMealPlan(id: string): boolean {
    const initialLen = this.data.mealPlans.length;
    this.data.mealPlans = this.data.mealPlans.filter(mp => mp.id !== id);
    if (this.data.mealPlans.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  // --- Meal Logs ---
  getMealLogs(userId: string, date?: string): MealLog[] {
    return this.data.mealLogs.filter(ml => ml.userId === userId && (!date || ml.date === date));
  }

  createMealLog(mealLog: MealLog): MealLog {
    this.data.mealLogs.push(mealLog);
    this.persist();
    return mealLog;
  }

  deleteMealLog(id: string): boolean {
    const initialLen = this.data.mealLogs.length;
    this.data.mealLogs = this.data.mealLogs.filter(ml => ml.id !== id);
    if (this.data.mealLogs.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  // --- Grocery Items ---
  getGroceryItems(userId: string): GroceryItem[] {
    return this.data.groceryItems.filter(g => g.userId === userId);
  }

  createGroceryItem(item: GroceryItem): GroceryItem {
    this.data.groceryItems.push(item);
    this.persist();
    return item;
  }

  updateGroceryItem(id: string, updates: Partial<GroceryItem>): GroceryItem | undefined {
    const idx = this.data.groceryItems.findIndex(g => g.id === id);
    if (idx === -1) return undefined;
    this.data.groceryItems[idx] = { ...this.data.groceryItems[idx], ...updates, updatedAt: new Date().toISOString() };
    this.persist();
    return this.data.groceryItems[idx];
  }

  deleteGroceryItem(id: string): boolean {
    const initialLen = this.data.groceryItems.length;
    this.data.groceryItems = this.data.groceryItems.filter(g => g.id !== id);
    if (this.data.groceryItems.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  setGroceryItems(userId: string, items: GroceryItem[]): GroceryItem[] {
    this.data.groceryItems = this.data.groceryItems.filter(g => g.userId !== userId).concat(items);
    this.persist();
    return items;
  }

  // --- Lost & Found Items ---
  getLostFoundItems(filters?: {
    type?: string;
    category?: string;
    location?: string;
    status?: string;
    query?: string;
    userId?: string;
  }): LostFoundItem[] {
    let items = [...this.data.lostFoundItems];

    if (filters) {
      if (filters.type) {
        items = items.filter(i => i.type.toUpperCase() === filters.type!.toUpperCase());
      }
      if (filters.category && filters.category !== 'All') {
        items = items.filter(i => i.category.toLowerCase() === filters.category!.toLowerCase());
      }
      if (filters.status && filters.status !== 'All') {
        items = items.filter(i => i.status.toUpperCase() === filters.status!.toUpperCase());
      }
      if (filters.userId) {
        items = items.filter(i => i.reportedByUserId === filters.userId);
      }
      if (filters.query) {
        const q = filters.query.toLowerCase().trim();
        items = items.filter(i =>
          i.itemName.toLowerCase().includes(q) ||
          i.description.toLowerCase().includes(q) ||
          i.location.toLowerCase().includes(q) ||
          i.category.toLowerCase().includes(q) ||
          (i.brand && i.brand.toLowerCase().includes(q)) ||
          i.trackingId.toLowerCase().includes(q)
        );
      }
    }

    return items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  getLostFoundItemById(id: string): LostFoundItem | undefined {
    return this.data.lostFoundItems.find(i => i.id === id || i.trackingId === id);
  }

  createLostFoundItem(item: LostFoundItem): LostFoundItem {
    this.data.lostFoundItems.unshift(item);
    this.persist();
    return item;
  }

  updateLostFoundItem(id: string, updates: Partial<LostFoundItem>): LostFoundItem | undefined {
    const idx = this.data.lostFoundItems.findIndex(i => i.id === id);
    if (idx === -1) return undefined;
    this.data.lostFoundItems[idx] = { ...this.data.lostFoundItems[idx], ...updates, updatedAt: new Date().toISOString() };
    this.persist();
    return this.data.lostFoundItems[idx];
  }

  deleteLostFoundItem(id: string): boolean {
    const initialLen = this.data.lostFoundItems.length;
    this.data.lostFoundItems = this.data.lostFoundItems.filter(i => i.id !== id);
    this.data.itemMatches = this.data.itemMatches.filter(m => m.lostItemId !== id && m.foundItemId !== id);
    this.data.claims = this.data.claims.filter(c => c.itemId !== id);
    if (this.data.lostFoundItems.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  // --- Claims ---
  getClaims(filters?: { itemId?: string; userId?: string; status?: string }): Claim[] {
    let claims = [...this.data.claims];
    if (filters?.itemId) claims = claims.filter(c => c.itemId === filters.itemId);
    if (filters?.userId) claims = claims.filter(c => c.userId === filters.userId);
    if (filters?.status) claims = claims.filter(c => c.status === filters.status);
    return claims.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  getClaimById(id: string): Claim | undefined {
    return this.data.claims.find(c => c.id === id);
  }

  createClaim(claim: Claim): Claim {
    this.data.claims.unshift(claim);
    this.persist();
    return claim;
  }

  updateClaim(id: string, updates: Partial<Claim>): Claim | undefined {
    const idx = this.data.claims.findIndex(c => c.id === id);
    if (idx === -1) return undefined;
    this.data.claims[idx] = { ...this.data.claims[idx], ...updates, updatedAt: new Date().toISOString() };
    this.persist();
    return this.data.claims[idx];
  }

  // --- Matches ---
  getItemMatches(): ItemMatch[] {
    return this.data.itemMatches;
  }

  getMatchesForItem(itemId: string): ItemMatch[] {
    return this.data.itemMatches.filter(m => m.lostItemId === itemId || m.foundItemId === itemId);
  }

  createItemMatch(match: ItemMatch): ItemMatch {
    // Prevent duplicate matches between the same pair
    const existing = this.data.itemMatches.find(
      m => m.lostItemId === match.lostItemId && m.foundItemId === match.foundItemId
    );
    if (existing) {
      existing.score = match.score;
      existing.reasons = match.reasons;
      this.persist();
      return existing;
    }
    this.data.itemMatches.unshift(match);
    this.persist();
    return match;
  }

  // --- Notifications ---
  getNotifications(userId: string): Notification[] {
    return this.data.notifications
      .filter(n => n.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  createNotification(notification: Notification): Notification {
    this.data.notifications.unshift(notification);
    this.persist();
    return notification;
  }

  markNotificationAsRead(id: string, userId: string): boolean {
    const notif = this.data.notifications.find(n => n.id === id && n.userId === userId);
    if (notif) {
      notif.isRead = true;
      this.persist();
      return true;
    }
    return false;
  }

  markAllNotificationsAsRead(userId: string): boolean {
    this.data.notifications.forEach(n => {
      if (n.userId === userId) n.isRead = true;
    });
    this.persist();
    return true;
  }

  // --- Activity Logs ---
  getActivityLogs(): ActivityLog[] {
    return this.data.activityLogs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  logActivity(action: string, details?: string, userId?: string, userName?: string): ActivityLog {
    const log: ActivityLog = {
      id: 'act_' + Math.random().toString(36).substring(2, 9),
      userId,
      userName,
      action,
      details,
      createdAt: new Date().toISOString(),
    };
    this.data.activityLogs.unshift(log);
    if (this.data.activityLogs.length > 200) {
      this.data.activityLogs.pop();
    }
    this.persist();
    return log;
  }
}

export const dbStore = new DatabaseStore();
