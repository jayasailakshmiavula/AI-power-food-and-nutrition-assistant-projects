export type Role = 'STUDENT' | 'ADMIN';
export type ItemType = 'LOST' | 'FOUND';
export type ItemStatus = 'LOST' | 'FOUND' | 'MATCHED' | 'CLAIM_PENDING' | 'CLAIMED' | 'RETURNED' | 'CLOSED';
export type ClaimStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'MORE_INFO_NEEDED';

export interface User {
  id: string;
  fullName: string;
  email: string;
  studentId?: string;
  department?: string;
  year?: string;
  role: Role;
  avatarUrl?: string;
  createdAt: string;
}

export interface NutritionProfile {
  id: string;
  userId: string;
  age: number;
  gender: string;
  height: number;
  weight: number;
  activityLevel: string;
  primaryGoal: string;
  dietType: string;
  foodPreferences: string[];
  allergies: string[];
  foodsToAvoid: string[];
  dailyBudget: number;
  availableIngredients: string[];
  mealsPerDay: number;
  calorieTarget: number;
  proteinTarget: number;
}

export interface MealItem {
  mealType: 'Breakfast' | 'Lunch' | 'Snack' | 'Dinner';
  mealName: string;
  ingredients: string[];
  servingSize: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  preparationInstructions: string;
  estimatedCost: number;
}

export interface MealPlan {
  id: string;
  userId: string;
  title: string;
  goal: string;
  totalCalories: number;
  totalProtein: number;
  totalCost: number;
  diet: string;
  meals: MealItem[];
  createdAt: string;
}

export interface MealLog {
  id: string;
  userId: string;
  mealType: string;
  foodName: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber?: number;
  date: string;
  loggedAt: string;
}

export interface GroceryItem {
  id: string;
  userId: string;
  name: string;
  category: 'Vegetables' | 'Fruits' | 'Grains' | 'Protein' | 'Dairy' | 'Spices' | 'Other';
  quantity: string;
  estimatedPrice: number;
  purchased: boolean;
}

export interface LostFoundItem {
  id: string;
  trackingId: string;
  type: ItemType;
  itemName: string;
  category: string;
  description: string;
  color: string;
  brand?: string;
  uniqueFeatures?: string;
  location: string;
  date: string;
  time?: string;
  imageUrl?: string;
  contactPreference?: string;
  submittedLocation?: string;
  status: ItemStatus;
  reportedByUserId: string;
  reportedByName?: string;
  createdAt: string;
}

export interface Claim {
  id: string;
  itemId: string;
  userId: string;
  itemTitle?: string;
  claimantName?: string;
  claimantEmail?: string;
  whereLost: string;
  whenLost: string;
  uniqueFeature: string;
  proofNotes?: string;
  status: ClaimStatus;
  adminNotes?: string;
  createdAt: string;
  item?: LostFoundItem;
  user?: Partial<User>;
}

export interface ItemMatch {
  id: string;
  lostItemId: string;
  foundItemId: string;
  lostItemTitle?: string;
  foundItemTitle?: string;
  score: number;
  reasons: string[];
  status: 'PENDING' | 'CONFIRMED' | 'DISMISSED';
  createdAt: string;
  lostItem?: LostFoundItem;
  foundItem?: LostFoundItem;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'match' | 'claim' | 'meal_plan' | 'system';
  link?: string;
  isRead: boolean;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  userId?: string;
  userName?: string;
  action: string;
  details?: string;
  createdAt: string;
}
