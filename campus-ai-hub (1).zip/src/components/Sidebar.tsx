import React from 'react';
import {
  LayoutDashboard,
  Utensils,
  Sparkles,
  Search,
  ShoppingCart,
  FileSearch,
  PlusCircle,
  HelpCircle,
  FolderHeart,
  Shield,
  User,
  Activity,
  Layers,
  CheckCircle2,
  Bell,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { useNotifications } from '../context/NotificationContext.tsx';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentPage, onNavigate }) => {
  const { user } = useAuth();
  const { unreadCount } = useNotifications();

  const navItemClass = (pageName: string, accent: 'blue' | 'green' | 'amber' = 'blue') => {
    const isActive = currentPage === pageName || currentPage.startsWith(`${pageName}?`);
    if (isActive) {
      if (accent === 'green') {
        return 'bg-emerald-50 text-emerald-800 font-semibold border-l-4 border-emerald-600';
      }
      if (accent === 'amber') {
        return 'bg-amber-50 text-amber-900 font-semibold border-l-4 border-amber-600';
      }
      return 'bg-blue-50 text-blue-800 font-semibold border-l-4 border-blue-600';
    }
    return 'text-slate-600 hover:text-slate-900 hover:bg-slate-50 font-medium border-l-4 border-transparent';
  };

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col shrink-0 min-h-[calc(100vh-4rem)]">
      <div className="p-4 space-y-6 flex-1 overflow-y-auto">
        {/* Main Section */}
        <div>
          <p className="px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            Main
          </p>
          <div className="space-y-1">
            <button
              onClick={() => onNavigate('dashboard')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('dashboard')}`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Student Dashboard</span>
            </button>
            <button
              onClick={() => onNavigate('notifications')}
              className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('notifications')}`}
            >
              <div className="flex items-center gap-3">
                <Bell className="w-4 h-4" />
                <span>Notifications</span>
              </div>
              {unreadCount > 0 && (
                <span className="text-[10px] bg-red-100 text-red-600 font-bold px-1.5 py-0.5 rounded-full">
                  {unreadCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Nutrition Assistant Section */}
        <div>
          <div className="flex items-center justify-between px-3 mb-2">
            <p className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              AI Nutrition
            </p>
          </div>
          <div className="space-y-1">
            <button
              onClick={() => onNavigate('nutrition/summary')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('nutrition/summary', 'green')}`}
            >
              <Activity className="w-4 h-4 text-emerald-600" />
              <span>Daily Nutrition & Log</span>
            </button>
            <button
              onClick={() => onNavigate('nutrition/meal-planner')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('nutrition/meal-planner', 'green')}`}
            >
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>AI Meal Planner</span>
            </button>
            <button
              onClick={() => onNavigate('nutrition/analyzer')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('nutrition/analyzer', 'green')}`}
            >
              <Utensils className="w-4 h-4 text-emerald-600" />
              <span>Food Analyzer</span>
            </button>
            <button
              onClick={() => onNavigate('nutrition/grocery')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('nutrition/grocery', 'green')}`}
            >
              <ShoppingCart className="w-4 h-4 text-emerald-600" />
              <span>Grocery List</span>
            </button>
          </div>
        </div>

        {/* Lost & Found Section */}
        <div>
          <div className="flex items-center justify-between px-3 mb-2">
            <p className="text-[11px] font-bold text-amber-700 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              Lost & Found
            </p>
          </div>
          <div className="space-y-1">
            <button
              onClick={() => onNavigate('lost-found')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('lost-found', 'amber')}`}
            >
              <Search className="w-4 h-4 text-amber-600" />
              <span>Browse Items</span>
            </button>
            <button
              onClick={() => onNavigate('lost-found/report-lost')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('lost-found/report-lost', 'amber')}`}
            >
              <PlusCircle className="w-4 h-4 text-red-500" />
              <span>Report Lost Item</span>
            </button>
            <button
              onClick={() => onNavigate('lost-found/report-found')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('lost-found/report-found', 'amber')}`}
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Report Found Item</span>
            </button>
            <button
              onClick={() => onNavigate('lost-found/matches')}
              className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('lost-found/matches', 'amber')}`}
            >
              <div className="flex items-center gap-3">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>AI Item Matching</span>
              </div>
              <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded">
                AI
              </span>
            </button>
            <button
              onClick={() => onNavigate('lost-found/my-reports')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('lost-found/my-reports', 'amber')}`}
            >
              <FolderHeart className="w-4 h-4 text-amber-600" />
              <span>My Reports & Claims</span>
            </button>
          </div>
        </div>

        {/* Administration Section */}
        <div>
          <p className="px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-between">
            <span>Administration</span>
            {user?.role !== 'ADMIN' && (
              <span className="text-[9px] bg-slate-100 text-slate-500 px-1 rounded">Faculty</span>
            )}
          </p>
          <div className="space-y-1">
            <button
              onClick={() => onNavigate('admin')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('admin')}`}
            >
              <Shield className="w-4 h-4 text-indigo-600" />
              <span>Admin Dashboard</span>
            </button>
          </div>
        </div>

        {/* Profile */}
        <div>
          <p className="px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            Account
          </p>
          <div className="space-y-1">
            <button
              onClick={() => onNavigate('profile')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs rounded-r-xl transition-all ${navItemClass('profile')}`}
            >
              <User className="w-4 h-4" />
              <span>Student Profile</span>
            </button>
          </div>
        </div>
      </div>

      {/* Footer Banner */}
      <div className="p-3 bg-slate-50 border-t border-slate-200 m-3 rounded-xl text-center">
        <p className="text-[11px] font-semibold text-slate-700">Campus AI Hub v1.0</p>
        <p className="text-[10px] text-slate-400 mt-0.5">Powered by Google Gemini AI</p>
      </div>
    </aside>
  );
};
