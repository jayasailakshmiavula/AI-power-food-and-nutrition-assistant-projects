import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, NutritionProfile } from '../types.ts';
import { api, setAuthToken, clearAuthToken, getAuthToken } from '../services/api.ts';

interface AuthContextType {
  user: User | null;
  profile: NutritionProfile | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (payload: any) => Promise<void>;
  logout: () => void;
  loginAsDemoStudent: () => Promise<void>;
  loginAsDemoAdmin: () => Promise<void>;
  refreshUser: () => Promise<void>;
  setProfile: (p: NutritionProfile) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<NutritionProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const refreshUser = async () => {
    const token = getAuthToken();
    if (!token) {
      setUser(null);
      setProfile(null);
      setLoading(false);
      return;
    }

    try {
      const res = await api.getMe();
      if (res.success && res.data) {
        setUser(res.data.user);
        setProfile(res.data.profile || null);
      } else {
        clearAuthToken();
        setUser(null);
      }
    } catch (err) {
      console.warn('Session expired or invalid, clearing token');
      clearAuthToken();
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // If no token exists on first visit, automatically log in as Demo Student for instant delight
    const token = getAuthToken();
    if (!token) {
      loginAsDemoStudent().catch(() => setLoading(false));
    } else {
      refreshUser();
    }
  }, []);

  const login = async (email: string, password: string) => {
    setLoading(true);
    try {
      const res = await api.login({ email, password });
      if (res.success && res.data) {
        setAuthToken(res.data.token);
        setUser(res.data.user);
        const meRes = await api.getMe();
        if (meRes.data?.profile) setProfile(meRes.data.profile);
      }
    } finally {
      setLoading(false);
    }
  };

  const register = async (payload: any) => {
    setLoading(true);
    try {
      const res = await api.register(payload);
      if (res.success && res.data) {
        setAuthToken(res.data.token);
        setUser(res.data.user);
      }
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    clearAuthToken();
    setUser(null);
    setProfile(null);
  };

  const loginAsDemoStudent = async () => {
    await login('student@campus.edu', 'Password123!');
  };

  const loginAsDemoAdmin = async () => {
    await login('admin@campus.edu', 'AdminPassword123!');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        login,
        register,
        logout,
        loginAsDemoStudent,
        loginAsDemoAdmin,
        refreshUser,
        setProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
