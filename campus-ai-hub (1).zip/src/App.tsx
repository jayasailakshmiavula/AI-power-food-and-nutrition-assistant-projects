import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { NotificationProvider } from './context/NotificationContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { LandingPage } from './pages/LandingPage.tsx';
import { StudentDashboard } from './pages/StudentDashboard.tsx';
import { NutritionPlannerPage } from './pages/NutritionPlannerPage.tsx';
import { FoodAnalyzerPage } from './pages/FoodAnalyzerPage.tsx';
import { DailySummaryPage } from './pages/DailySummaryPage.tsx';
import { GroceryListPage } from './pages/GroceryListPage.tsx';
import { LostFoundBrowsePage } from './pages/LostFoundBrowsePage.tsx';
import { ReportLostPage } from './pages/ReportLostPage.tsx';
import { ReportFoundPage } from './pages/ReportFoundPage.tsx';
import { MatchesPage } from './pages/MatchesPage.tsx';
import { MyReportsPage } from './pages/MyReportsPage.tsx';
import { AdminDashboardPage } from './pages/AdminDashboardPage.tsx';
import { ProfilePage } from './pages/ProfilePage.tsx';
import { NotificationsPage } from './pages/NotificationsPage.tsx';
import { AuthModal } from './pages/AuthModal.tsx';
import { Menu, X } from 'lucide-react';

function AppContent() {
  const { user, loading } = useAuth();
  const [currentPage, setCurrentPage] = useState<string>('dashboard');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Sync route from URL or initial query
  const [initialSearchQuery, setInitialSearchQuery] = useState('');

  const handleNavigate = (page: string) => {
    setMobileSidebarOpen(false);
    if (page.startsWith('lost-found?query=')) {
      const q = decodeURIComponent(page.split('?query=')[1] || '');
      setInitialSearchQuery(q);
      setCurrentPage('lost-found');
    } else {
      setCurrentPage(page);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-bold text-slate-600">Starting Campus AI Hub...</p>
        </div>
      </div>
    );
  }

  // Render Landing Page if requested
  if (currentPage === 'landing') {
    return (
      <>
        <LandingPage
          onNavigate={handleNavigate}
          onOpenAuth={() => setIsAuthModalOpen(true)}
        />
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
        />
      </>
    );
  }

  const renderCurrentView = () => {
    switch (currentPage) {
      case 'dashboard':
        return <StudentDashboard onNavigate={handleNavigate} />;
      case 'nutrition/summary':
        return <DailySummaryPage />;
      case 'nutrition/meal-planner':
        return <NutritionPlannerPage onNavigate={handleNavigate} />;
      case 'nutrition/analyzer':
        return <FoodAnalyzerPage onNavigate={handleNavigate} />;
      case 'nutrition/grocery':
        return <GroceryListPage />;
      case 'lost-found':
        return (
          <LostFoundBrowsePage
            onNavigate={handleNavigate}
            initialQuery={initialSearchQuery}
          />
        );
      case 'lost-found/report-lost':
        return <ReportLostPage onNavigate={handleNavigate} />;
      case 'lost-found/report-found':
        return <ReportFoundPage onNavigate={handleNavigate} />;
      case 'lost-found/matches':
        return <MatchesPage onNavigate={handleNavigate} />;
      case 'lost-found/my-reports':
        return <MyReportsPage onNavigate={handleNavigate} />;
      case 'admin':
        return <AdminDashboardPage />;
      case 'profile':
        return <ProfilePage />;
      case 'notifications':
        return <NotificationsPage onNavigate={handleNavigate} />;
      default:
        // Check dynamic item details route like lost-found/lf_xxx
        if (currentPage.startsWith('lost-found/')) {
          return (
            <LostFoundBrowsePage
              onNavigate={handleNavigate}
              initialQuery={currentPage.replace('lost-found/', '')}
            />
          );
        }
        return <StudentDashboard onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      <Navbar onNavigate={handleNavigate} currentPage={currentPage} />

      {/* Mobile Top Navigation Toggle */}
      <div className="md:hidden bg-white border-b border-slate-200 px-4 py-2 flex items-center justify-between">
        <button
          onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
          className="p-2 text-slate-600 hover:text-slate-900 rounded-lg flex items-center gap-2 text-xs font-semibold"
        >
          {mobileSidebarOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          <span>Navigation Menu</span>
        </button>
        <span className="text-xs font-bold text-slate-500 capitalize">
          {currentPage.split('/')[0]}
        </span>
      </div>

      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Desktop Sidebar */}
        <div className="hidden md:block">
          <Sidebar currentPage={currentPage} onNavigate={handleNavigate} />
        </div>

        {/* Mobile Slide-Over Sidebar */}
        {mobileSidebarOpen && (
          <div className="fixed inset-0 z-40 md:hidden flex">
            <div
              className="fixed inset-0 bg-black/40 backdrop-blur-xs"
              onClick={() => setMobileSidebarOpen(false)}
            />
            <div className="relative z-50 w-72 bg-white h-full shadow-2xl flex flex-col">
              <div className="p-4 border-b border-slate-200 flex items-center justify-between">
                <span className="font-bold text-slate-900 text-sm">Campus AI Hub</span>
                <button
                  onClick={() => setMobileSidebarOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto">
                <Sidebar currentPage={currentPage} onNavigate={handleNavigate} />
              </div>
            </div>
          </div>
        )}

        {/* Main Page Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto min-w-0">
          {renderCurrentView()}
        </main>
      </div>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <AppContent />
      </NotificationProvider>
    </AuthProvider>
  );
}
