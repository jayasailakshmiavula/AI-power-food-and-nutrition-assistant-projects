const BASE_URL = '/api';

export const getAuthToken = (): string | null => {
  return localStorage.getItem('campus_hub_token');
};

export const setAuthToken = (token: string): void => {
  localStorage.setItem('campus_hub_token', token);
};

export const clearAuthToken = (): void => {
  localStorage.removeItem('campus_hub_token');
};

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const errorMsg = data.message || `Request failed with status ${response.status}`;
    throw new Error(errorMsg);
  }

  return data;
}

export const api = {
  // Auth
  register: (payload: any) => request<any>('/auth/register', { method: 'POST', body: JSON.stringify(payload) }),
  login: (payload: any) => request<any>('/auth/login', { method: 'POST', body: JSON.stringify(payload) }),
  getMe: () => request<any>('/auth/me'),
  updateProfile: (payload: any) => request<any>('/auth/profile', { method: 'PUT', body: JSON.stringify(payload) }),

  // Nutrition
  getNutritionProfile: () => request<any>('/nutrition/profile'),
  updateNutritionProfile: (payload: any) => request<any>('/nutrition/profile', { method: 'PUT', body: JSON.stringify(payload) }),
  generateMealPlan: (payload: any) => request<any>('/nutrition/meal-plan/generate', { method: 'POST', body: JSON.stringify(payload) }),
  getMealPlans: () => request<any>('/nutrition/meal-plans'),
  saveMealPlan: (payload: any) => request<any>('/nutrition/meal-plans', { method: 'POST', body: JSON.stringify(payload) }),
  deleteMealPlan: (id: string) => request<any>(`/nutrition/meal-plans/${id}`, { method: 'DELETE' }),
  analyzeFood: (payload: any) => request<any>('/nutrition/analyze-food', { method: 'POST', body: JSON.stringify(payload) }),
  getMealLogs: (date?: string) => request<any>(`/nutrition/meal-log${date ? `?date=${date}` : ''}`),
  logMeal: (payload: any) => request<any>('/nutrition/meal-log', { method: 'POST', body: JSON.stringify(payload) }),
  deleteMealLog: (id: string) => request<any>(`/nutrition/meal-log/${id}`, { method: 'DELETE' }),
  getDailySummary: () => request<any>('/nutrition/daily-summary'),
  getGroceryList: () => request<any>('/nutrition/grocery-list'),
  addGroceryItem: (payload: any) => request<any>('/nutrition/grocery-list', { method: 'POST', body: JSON.stringify(payload) }),
  updateGroceryItem: (id: string, payload: any) => request<any>(`/nutrition/grocery-list/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteGroceryItem: (id: string) => request<any>(`/nutrition/grocery-list/${id}`, { method: 'DELETE' }),
  syncGroceryFromPlan: (mealPlanId?: string) => request<any>('/nutrition/grocery-list/from-plan', { method: 'POST', body: JSON.stringify({ mealPlanId }) }),

  // Lost & Found
  getLostFoundItems: (params: Record<string, string> = {}) => {
    const query = new URLSearchParams(params).toString();
    return request<any>(`/lost-found${query ? `?${query}` : ''}`);
  },
  getItemById: (id: string) => request<any>(`/lost-found/${id}`),
  reportLost: (payload: any) => request<any>('/lost-found/lost', { method: 'POST', body: JSON.stringify(payload) }),
  reportFound: (payload: any) => request<any>('/lost-found/found', { method: 'POST', body: JSON.stringify(payload) }),
  updateLostFoundItem: (id: string, payload: any) => request<any>(`/lost-found/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteLostFoundItem: (id: string) => request<any>(`/lost-found/${id}`, { method: 'DELETE' }),
  claimItem: (id: string, payload: any) => request<any>(`/lost-found/${id}/claim`, { method: 'POST', body: JSON.stringify(payload) }),
  getMyReports: () => request<any>('/lost-found/my-items'),
  getAllMatches: () => request<any>('/lost-found/all-matches'),
  getItemMatches: (id: string) => request<any>(`/lost-found/matches/${id}`),

  // Notifications
  getNotifications: () => request<any>('/notifications'),
  markNotificationRead: (id: string) => request<any>(`/notifications/${id}/read`, { method: 'PUT' }),
  markAllNotificationsRead: () => request<any>('/notifications/read-all', { method: 'PUT' }),

  // Admin
  getAdminDashboard: () => request<any>('/admin/dashboard'),
  getAdminUsers: () => request<any>('/admin/users'),
  updateAdminUser: (id: string, payload: any) => request<any>(`/admin/users/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteAdminUser: (id: string) => request<any>(`/admin/users/${id}`, { method: 'DELETE' }),
  getAdminItems: () => request<any>('/admin/items'),
  updateAdminItemStatus: (id: string, status: string) => request<any>(`/admin/items/${id}/status`, { method: 'PUT', body: JSON.stringify({ status }) }),
  deleteAdminItem: (id: string) => request<any>(`/admin/items/${id}`, { method: 'DELETE' }),
  getAdminClaims: () => request<any>('/admin/claims'),
  updateAdminClaim: (id: string, status: string, adminNotes?: string) => request<any>(`/admin/claims/${id}`, { method: 'PUT', body: JSON.stringify({ status, adminNotes }) }),
  getAdminActivityLogs: () => request<any>('/admin/activity-logs'),
};
