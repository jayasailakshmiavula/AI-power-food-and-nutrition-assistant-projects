import React, { useState } from 'react';
import {
  PlusCircle,
  Sparkles,
  MapPin,
  Calendar,
  Clock,
  Image as ImageIcon,
  CheckCircle2,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { api } from '../services/api.ts';

const CATEGORIES = [
  'ID Card',
  'Books',
  'Calculator',
  'Bottle',
  'Wallet',
  'Phone',
  'Laptop',
  'Keys',
  'Bag',
  'Clothing',
  'Accessories',
  'Other',
];

interface ReportLostPageProps {
  onNavigate: (page: string) => void;
}

export const ReportLostPage: React.FC<ReportLostPageProps> = ({ onNavigate }) => {
  const [itemName, setItemName] = useState('');
  const [category, setCategory] = useState('Calculator');
  const [description, setDescription] = useState('');
  const [color, setColor] = useState('Black');
  const [brand, setBrand] = useState('');
  const [uniqueFeatures, setUniqueFeatures] = useState('');
  const [location, setLocation] = useState('Central Library 2nd Floor');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('14:30');
  const [contactPreference, setContactPreference] = useState('Campus Portal & Email');
  const [imageUrl, setImageUrl] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Result state
  const [result, setResult] = useState<{ trackingId: string; item: any } | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemName || !description || !location || !date) return;

    setSubmitting(true);
    try {
      const res = await api.reportLost({
        itemName,
        category,
        description,
        color,
        brand,
        uniqueFeatures,
        location,
        date,
        time,
        contactPreference,
        imageUrl,
      });

      if (res.success && res.data) {
        setResult(res.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 pb-16">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 flex items-center gap-2.5">
          <PlusCircle className="w-6 h-6 text-red-600" />
          Report Lost Belonging
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Provide detailed parameters so the AI matching engine can correlate with items turned in across campus.
        </p>
      </div>

      {result ? (
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-xl text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-2xl font-black text-slate-900">Your lost item has been reported.</h2>
            <p className="text-xs text-slate-500 mt-1">
              Our automated AI system is now scanning turn-in records across all campus security desks.
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 max-w-sm mx-auto">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block">
              Tracking ID
            </span>
            <span className="text-2xl font-mono font-extrabold text-blue-600 mt-1 block">
              {result.trackingId}
            </span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => onNavigate('lost-found/matches')}
              className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" /> Check Potential Matches Now
            </button>
            <button
              onClick={() => onNavigate('lost-found')}
              className="px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
            >
              Back to Browse
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6 text-xs">
          {/* Item Name & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-700 mb-1.5">Item Name *</label>
              <input
                type="text"
                required
                value={itemName}
                onChange={e => setItemName(e.target.value)}
                placeholder="e.g. Black Casio FX-991EX Scientific Calculator"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white focus:outline-blue-500"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1.5">Category *</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
              >
                {CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block font-bold text-slate-700 mb-1.5">Description *</label>
            <textarea
              rows={3}
              required
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Describe color shades, condition, what was inside, or circumstances..."
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white resize-none"
            />
          </div>

          {/* Color & Brand */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 mb-1.5">Color</label>
              <input
                type="text"
                value={color}
                onChange={e => setColor(e.target.value)}
                placeholder="e.g. Black, Matte Navy, Silver"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1.5">Brand / Manufacturer</label>
              <input
                type="text"
                value={brand}
                onChange={e => setBrand(e.target.value)}
                placeholder="e.g. Casio, Apple, Hydro Flask, Lenovo"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
              />
            </div>
          </div>

          {/* Unique Identifying Features */}
          <div>
            <label className="block font-bold text-slate-700 mb-1.5">
              Unique Identifying Features (Crucial for AI Match Verification)
            </label>
            <input
              type="text"
              value={uniqueFeatures}
              onChange={e => setUniqueFeatures(e.target.value)}
              placeholder="e.g. Metallic initial sticker 'A.S.' on sliding cover, cracked corner, keychain"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
            />
          </div>

          {/* Location & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-700 mb-1.5">Last Seen Location *</label>
              <input
                type="text"
                required
                value={location}
                onChange={e => setLocation(e.target.value)}
                placeholder="e.g. Central Library 2nd Floor Desk #14"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1.5">Date Lost *</label>
              <input
                type="date"
                required
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
              />
            </div>
          </div>

          {/* Time & Contact Preference */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 mb-1.5">Approx. Time</label>
              <input
                type="time"
                value={time}
                onChange={e => setTime(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1.5">Contact Preference</label>
              <input
                type="text"
                value={contactPreference}
                onChange={e => setContactPreference(e.target.value)}
                placeholder="Campus Lost & Found Portal / Email"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
              />
            </div>
          </div>

          {/* Image Upload */}
          <div>
            <label className="block font-bold text-slate-700 mb-1.5">Reference Image (Optional)</label>
            <div className="border-2 border-dashed border-slate-200 rounded-2xl p-4 text-center">
              {imageUrl ? (
                <div className="relative inline-block">
                  <img src={imageUrl} alt="Uploaded" className="h-32 object-cover rounded-xl" />
                  <button
                    type="button"
                    onClick={() => setImageUrl('')}
                    className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full p-1"
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <label className="cursor-pointer block py-3">
                  <ImageIcon className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                  <span className="font-bold text-blue-600">Upload photo of similar item or proof</span>
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </label>
              )}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => onNavigate('lost-found')}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-6 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-bold rounded-xl shadow-md shadow-red-600/20 flex items-center gap-2"
            >
              <PlusCircle className="w-4 h-4" />
              {submitting ? 'Registering & Running AI Match...' : 'Report Lost Item'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
