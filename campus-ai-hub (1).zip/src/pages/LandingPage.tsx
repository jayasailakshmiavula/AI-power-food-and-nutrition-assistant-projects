import React from 'react';
import {
  Sparkles,
  Utensils,
  Search,
  CheckCircle2,
  TrendingUp,
  ShieldCheck,
  ArrowRight,
  BrainCircuit,
  Zap,
  Clock,
  HeartHandshake,
  Users,
  ChevronDown,
  GraduationCap,
  ShieldAlert,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';

interface LandingPageProps {
  onNavigate: (page: string) => void;
  onOpenAuth: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate, onOpenAuth }) => {
  const { user, loginAsDemoStudent, loginAsDemoAdmin } = useAuth();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {/* Top Banner Navigation */}
      <nav className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <span className="font-extrabold text-xl tracking-tight text-slate-900">
              Campus <span className="text-blue-600">AI Hub</span>
            </span>
            <span className="ml-2 text-[10px] font-semibold uppercase px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full">
              University Edition
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loginAsDemoStudent}
            className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-xl transition-all"
          >
            <GraduationCap className="w-4 h-4" />
            Quick Student Demo
          </button>
          <button
            onClick={loginAsDemoAdmin}
            className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 rounded-xl transition-all"
          >
            <ShieldAlert className="w-4 h-4" />
            Quick Admin Demo
          </button>
          {user ? (
            <button
              onClick={() => onNavigate('dashboard')}
              className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-md shadow-blue-600/20 transition-all hover:scale-[1.02]"
            >
              Go to Dashboard
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-md shadow-blue-600/20 transition-all hover:scale-[1.02]"
            >
              Sign In / Register
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 px-4 sm:px-6 lg:px-8 text-center max-w-5xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold mb-6 animate-pulse">
          <Sparkles className="w-3.5 h-3.5" />
          Powered by Gemini 3.8 Intelligence & Multi-Modal Matching
        </div>

        <h1 className="text-4xl sm:text-6xl font-extrabold text-slate-900 tracking-tight leading-tight sm:leading-none">
          Campus <span className="text-blue-600">AI Hub</span>
        </h1>
        <p className="text-2xl sm:text-3xl font-bold text-slate-700 mt-3 tracking-tight">
          Smart Nutrition. Smarter Campus.
        </p>

        <p className="mt-5 text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
          Your AI-powered assistant for personalized nutrition and campus lost &amp; found.
          Designed specifically for college life, busy schedules, student budgets, and campus security.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={() => onNavigate('dashboard')}
            className="px-7 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-xl shadow-lg shadow-blue-600/25 flex items-center gap-2 transition-all hover:-translate-y-0.5"
          >
            Get Started
            <ArrowRight className="w-4 h-4" />
          </button>
          <a
            href="#features"
            className="px-6 py-3.5 bg-white hover:bg-slate-100 text-slate-800 font-semibold text-sm rounded-xl border border-slate-200 shadow-xs transition-all"
          >
            Explore Features
          </a>
        </div>

        {/* Demo Fast Tracks */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-3 text-xs text-slate-500">
          <span>Instant Login:</span>
          <button
            onClick={loginAsDemoStudent}
            className="underline hover:text-blue-600 font-medium"
          >
            Student Account (student@campus.edu)
          </button>
          <span>•</span>
          <button
            onClick={loginAsDemoAdmin}
            className="underline hover:text-amber-600 font-medium"
          >
            Admin Account (admin@campus.edu)
          </button>
        </div>
      </section>

      {/* Two Major Module Feature Cards */}
      <section id="features" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Card 1: AI Nutrition Assistant */}
          <div className="group relative bg-white rounded-3xl p-8 sm:p-10 border border-emerald-100 shadow-xl shadow-emerald-500/5 hover:border-emerald-300 transition-all">
            <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-6">
              <Utensils className="w-7 h-7" />
            </div>
            <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">
              Module 01
            </span>
            <h3 className="text-2xl font-bold text-slate-900 mt-1 mb-3">
              AI Nutrition Assistant
            </h3>
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed mb-6">
              "Plan meals based on your goals, preferences, budget and available ingredients."
            </p>

            <ul className="space-y-3 mb-8">
              <li className="flex items-start gap-3 text-sm text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Personalized Meal Planner:</strong> Tailored to campus hostel budgets, mess food, allergies, and calorie goals.
                </span>
              </li>
              <li className="flex items-start gap-3 text-sm text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>AI Food &amp; Image Analyzer:</strong> Instant macronutrient breakdown, health score (0-100), and healthier swaps.
                </span>
              </li>
              <li className="flex items-start gap-3 text-sm text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Auto Grocery List Generator:</strong> Automatically aggregates weekly meal plan ingredients by category.
                </span>
              </li>
            </ul>

            <button
              onClick={() => onNavigate('nutrition/meal-planner')}
              className="inline-flex items-center gap-2 text-sm font-bold text-emerald-700 hover:text-emerald-800 group-hover:translate-x-1 transition-transform"
            >
              Open AI Nutrition Assistant
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Card 2: Campus Lost & Found */}
          <div className="group relative bg-white rounded-3xl p-8 sm:p-10 border border-amber-100 shadow-xl shadow-amber-500/5 hover:border-amber-300 transition-all">
            <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mb-6">
              <Search className="w-7 h-7" />
            </div>
            <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">
              Module 02
            </span>
            <h3 className="text-2xl font-bold text-slate-900 mt-1 mb-3">
              Campus Lost &amp; Found
            </h3>
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed mb-6">
              "Report, search and recover lost belongings anywhere on campus."
            </p>

            <ul className="space-y-3 mb-8">
              <li className="flex items-start gap-3 text-sm text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  <strong>AI Smart Matching:</strong> Instant semantic match score and multi-point comparison between lost &amp; found items.
                </span>
              </li>
              <li className="flex items-start gap-3 text-sm text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Secure Verification &amp; Claiming:</strong> Requires physical proof / identifying questions before admin approval.
                </span>
              </li>
              <li className="flex items-start gap-3 text-sm text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Tracking ID &amp; Notifications:</strong> Automated tracking numbers (LF-2026-XXXXXX) and real-time status alerts.
                </span>
              </li>
            </ul>

            <button
              onClick={() => onNavigate('lost-found')}
              className="inline-flex items-center gap-2 text-sm font-bold text-amber-700 hover:text-amber-800 group-hover:translate-x-1 transition-transform"
            >
              Browse Lost &amp; Found Portal
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-white py-16 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <h2 className="text-3xl font-extrabold text-slate-900">How It Works</h2>
            <p className="mt-3 text-slate-600 text-sm sm:text-base">
              A unified campus workflow designed for students, faculty, and security desks.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 text-center">
              <div className="w-12 h-12 mx-auto rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-lg mb-4">
                1
              </div>
              <h4 className="font-bold text-slate-900 text-base mb-2">Set Profile &amp; Preferences</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Log your student details, dietary needs, budget, and campus locations. Fast 1-click onboarding.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 text-center">
              <div className="w-12 h-12 mx-auto rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-lg mb-4">
                2
              </div>
              <h4 className="font-bold text-slate-900 text-base mb-2">AI Generates &amp; Analyzes</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Get macro-optimized meal plans, ingredient grocery checklists, and instant food health scores.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 text-center">
              <div className="w-12 h-12 mx-auto rounded-full bg-amber-600 text-white flex items-center justify-center font-bold text-lg mb-4">
                3
              </div>
              <h4 className="font-bold text-slate-900 text-base mb-2">Auto-Match &amp; Recover</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Report lost items; AI compares locations, dates, and images to notify you immediately of verified matches.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 w-full">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center shadow-xs">
            <p className="text-3xl sm:text-4xl font-extrabold text-blue-600">4,500+</p>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-2">
              Active Campus Students
            </p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center shadow-xs">
            <p className="text-3xl sm:text-4xl font-extrabold text-emerald-600">12,400+</p>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-2">
              AI Meals Planned
            </p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center shadow-xs">
            <p className="text-3xl sm:text-4xl font-extrabold text-amber-600">88%</p>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-2">
              Lost Belongings Recovered
            </p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center shadow-xs">
            <p className="text-3xl sm:text-4xl font-extrabold text-purple-600">&lt; 15 Min</p>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-2">
              Avg. AI Match Time
            </p>
          </div>
        </div>
      </section>

      {/* Student Testimonials */}
      <section className="bg-slate-100/70 py-16 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-center text-slate-900 mb-10">
            What Students &amp; Faculty Are Saying
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow-xs border border-slate-200">
              <p className="text-xs text-slate-600 italic leading-relaxed">
                "I lost my Casio scientific calculator before the mid-terms. Within 2 hours of posting on Campus AI Hub, the system matched it with one turned in at the library!"
              </p>
              <div className="mt-4 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">
                  AS
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">Aarav Sharma</p>
                  <p className="text-[10px] text-slate-500">Computer Science, 3rd Year</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-xs border border-slate-200">
              <p className="text-xs text-slate-600 italic leading-relaxed">
                "As an athlete on a tight ₹200/day hostel budget, the AI meal planner showed me high-protein options using campus mess ingredients. It's a lifesaver."
              </p>
              <div className="mt-4 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                  PK
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">Pooja K.</p>
                  <p className="text-[10px] text-slate-500">Biotechnology, 2nd Year</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-xs border border-slate-200">
              <p className="text-xs text-slate-600 italic leading-relaxed">
                "The admin portal makes managing lost property straightforward. The automated AI match score gives security confidence before approving claim requests."
              </p>
              <div className="mt-4 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center font-bold text-xs">
                  EV
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">Prof. Elena Vance</p>
                  <p className="text-[10px] text-slate-500">Campus Operations</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 w-full">
        <h2 className="text-2xl font-bold text-center text-slate-900 mb-8">
          Frequently Asked Questions
        </h2>
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200">
            <h4 className="text-sm font-bold text-slate-900">
              How does the AI match lost and found items?
            </h4>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Our AI service compares category, color, brand, location zone, date ranges, and unique identifying text. It computes a semantic confidence score and explains matching reasons to both the student and admin.
            </p>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-slate-200">
            <h4 className="text-sm font-bold text-slate-900">
              Can the AI Nutrition Assistant cater to food allergies?
            </h4>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Yes. You specify strict allergy tags (such as peanuts, gluten, lactose, shellfish). The AI service strictly enforces exclusion of allergic ingredients in every generated recipe.
            </p>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-slate-200">
            <h4 className="text-sm font-bold text-slate-900">
              Are nutrition suggestions considered medical advice?
            </h4>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              No. Suggestions are designed as general lifestyle and nutritional guidance for active campus students. Users with specific medical conditions should consult a qualified healthcare professional.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto bg-slate-900 text-slate-400 py-10 border-t border-slate-800 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-400" />
            <span className="font-bold text-white text-sm">Campus AI Hub</span>
            <span className="text-slate-500">© 2026 University Tech Initiative</span>
          </div>
          <div className="flex items-center gap-6 text-slate-400">
            <button onClick={() => onNavigate('dashboard')} className="hover:text-white">
              Dashboard
            </button>
            <button onClick={() => onNavigate('nutrition/meal-planner')} className="hover:text-white">
              Nutrition
            </button>
            <button onClick={() => onNavigate('lost-found')} className="hover:text-white">
              Lost &amp; Found
            </button>
            <button onClick={loginAsDemoAdmin} className="hover:text-amber-400">
              Admin Access
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
