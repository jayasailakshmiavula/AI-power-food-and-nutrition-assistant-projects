import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Users,
  Search,
  CheckCircle2,
  Clock,
  Sparkles,
  BarChart3,
  PieChart as PieIcon,
  Check,
  X,
  Trash2,
  Edit,
  ArrowRight,
  TrendingUp,
  Building,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line,
} from 'recharts';
import { api } from '../services/api.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { User, LostFoundItem, Claim } from '../types.ts';

const PIE_COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#6366F1'];

export const AdminDashboardPage: React.FC = () => {
  const { user } = useAuth();
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [itemsList, setItemsList] = useState<LostFoundItem[]>([]);
  const [claimsList, setClaimsList] = useState<Claim[]>([]);
  const [loading, setLoading] = useState(true);

  // Active Admin Sub-tab
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'CLAIMS' | 'ITEMS' | 'USERS' | 'LOGS'>('OVERVIEW');

  // Claim modal
  const [selectedClaim, setSelectedClaim] = useState<any | null>(null);
  const [adminNotes, setAdminNotes] = useState('');

  const loadAllAdminData = async () => {
    try {
      setLoading(true);
      const [dashRes, usersRes, itemsRes, claimsRes] = await Promise.all([
        api.getAdminDashboard(),
        api.getAdminUsers(),
        api.getAdminItems(),
        api.getAdminClaims(),
      ]);

      if (dashRes.success) setDashboardData(dashRes.data);
      if (usersRes.success) setUsersList(usersRes.data);
      if (itemsRes.success) setItemsList(itemsRes.data);
      if (claimsRes.success) setClaimsList(claimsRes.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllAdminData();
  }, []);

  const handleUpdateClaimStatus = async (claimId: string, status: string) => {
    try {
      await api.updateAdminClaim(claimId, status, adminNotes || undefined);
      setSelectedClaim(null);
      setAdminNotes('');
      loadAllAdminData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateItemStatus = async (itemId: string, status: string) => {
    try {
      await api.updateAdminItemStatus(itemId, status);
      loadAllAdminData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteItem = async (itemId: string) => {
    if (!confirm('Are you sure you want to delete this item record?')) return;
    try {
      await api.deleteAdminItem(itemId);
      loadAllAdminData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleToggleUserRole = async (targetUser: User) => {
    const newRole = targetUser.role === 'ADMIN' ? 'STUDENT' : 'ADMIN';
    try {
      await api.updateAdminUser(targetUser.id, { role: newRole });
      loadAllAdminData();
    } catch (err) {
      console.error(err);
    }
  };

  const metrics = dashboardData?.metrics || {
    totalUsers: 2,
    lostItems: 2,
    foundItems: 3,
    potentialMatches: 1,
    claimRequests: 0,
    returnedItems: 1,
    unclaimedItems: 2,
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-800 text-xs font-bold rounded-full mb-2 border border-amber-200">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
            Administrative Operations Portal
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Campus Hub Admin Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Monitor property recovery rates, manage ownership verification claims, and review student activity.
          </p>
        </div>

        {/* Tab switchers */}
        <div className="flex flex-wrap items-center bg-slate-100 p-1.5 rounded-2xl text-xs font-bold border border-slate-200">
          <button
            onClick={() => setActiveTab('OVERVIEW')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              activeTab === 'OVERVIEW' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('CLAIMS')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              activeTab === 'CLAIMS' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Claims ({claimsList.filter(c => c.status === 'PENDING').length})
          </button>
          <button
            onClick={() => setActiveTab('ITEMS')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              activeTab === 'ITEMS' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Inventory ({itemsList.length})
          </button>
          <button
            onClick={() => setActiveTab('USERS')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              activeTab === 'USERS' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Students ({usersList.length})
          </button>
          <button
            onClick={() => setActiveTab('LOGS')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              activeTab === 'LOGS' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Activity Logs
          </button>
        </div>
      </div>

      {/* OVERVIEW TAB */}
      {activeTab === 'OVERVIEW' && (
        <div className="space-y-8">
          {/* Metrics 7-Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Total Users</span>
              <p className="text-2xl font-black text-slate-900 mt-1">{metrics.totalUsers}</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] font-bold text-red-500 uppercase">Lost Items</span>
              <p className="text-2xl font-black text-red-600 mt-1">{metrics.lostItems}</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] font-bold text-emerald-500 uppercase">Found Items</span>
              <p className="text-2xl font-black text-emerald-600 mt-1">{metrics.foundItems}</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] font-bold text-amber-500 uppercase">Matches</span>
              <p className="text-2xl font-black text-amber-600 mt-1">{metrics.potentialMatches}</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] font-bold text-purple-500 uppercase">Claims</span>
              <p className="text-2xl font-black text-purple-600 mt-1">{metrics.claimRequests}</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] font-bold text-green-600 uppercase">Recovered</span>
              <p className="text-2xl font-black text-green-700 mt-1">{metrics.returnedItems}</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs col-span-2 sm:col-span-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Unclaimed</span>
              <p className="text-2xl font-black text-slate-700 mt-1">{metrics.unclaimedItems}</p>
            </div>
          </div>

          {/* Recharts Analytics 2x2 Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Category Chart */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-blue-600" />
                Lost Items by Category
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dashboardData?.charts?.itemsByCategory || []}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                    <XAxis dataKey="name" stroke="#94A3B8" fontSize={10} interval={0} angle={-25} textAnchor="end" height={45} />
                    <YAxis stroke="#94A3B8" fontSize={11} />
                    <Tooltip contentStyle={{ backgroundColor: '#1E293B', borderRadius: '12px', color: '#fff', fontSize: '11px' }} />
                    <Bar dataKey="count" fill="#3B82F6" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Location Chart */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2">
                <Building className="w-4 h-4 text-emerald-600" />
                Lost Items by Campus Location
              </h3>
              <div className="h-64 flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={dashboardData?.charts?.itemsByLocation || []}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      paddingAngle={4}
                      dataKey="count"
                    >
                      {(dashboardData?.charts?.itemsByLocation || []).map((_: any, idx: number) => (
                        <Cell key={`loc-${idx}`} fill={PIE_COLORS[idx % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: '#1E293B', borderRadius: '12px', color: '#fff', fontSize: '11px' }} />
                    <Legend iconType="circle" wrapperStyle={{ fontSize: '11px' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Monthly Recovery Rate */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-amber-500" />
                Monthly Property Recovery Rate (%)
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={dashboardData?.charts?.monthlyRecovery || []}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                    <XAxis dataKey="month" stroke="#94A3B8" fontSize={11} />
                    <YAxis stroke="#94A3B8" fontSize={11} domain={[50, 100]} />
                    <Tooltip contentStyle={{ backgroundColor: '#1E293B', borderRadius: '12px', color: '#fff', fontSize: '11px' }} />
                    <Line type="monotone" dataKey="rate" stroke="#F59E0B" strokeWidth={3} dot={{ r: 5 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Nutrition Module Usage */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-600" />
                AI Nutrition Module Usage
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dashboardData?.charts?.nutritionUsage || []} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                    <XAxis type="number" stroke="#94A3B8" fontSize={11} />
                    <YAxis type="category" dataKey="feature" stroke="#94A3B8" fontSize={10} width={130} />
                    <Tooltip contentStyle={{ backgroundColor: '#1E293B', borderRadius: '12px', color: '#fff', fontSize: '11px' }} />
                    <Bar dataKey="count" fill="#8B5CF6" radius={[0, 6, 6, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CLAIMS MANAGEMENT TAB */}
      {activeTab === 'CLAIMS' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <h2 className="text-sm font-bold text-slate-900">Submitted Ownership Claims</h2>
          {claimsList.length === 0 ? (
            <p className="text-xs text-slate-400 py-8 text-center">No claim requests in queue</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Item</th>
                    <th className="py-3 px-4">Claimant</th>
                    <th className="py-3 px-4">Where / When Lost</th>
                    <th className="py-3 px-4">Identifying Feature</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {claimsList.map(claim => (
                    <tr key={claim.id} className="hover:bg-slate-50/50">
                      <td className="py-3 px-4 font-bold text-slate-900">
                        {claim.itemTitle || claim.item?.itemName}
                      </td>
                      <td className="py-3 px-4">
                        <p className="font-semibold text-slate-800">{claim.claimantName}</p>
                        <p className="text-[11px] text-slate-400">{claim.claimantEmail}</p>
                      </td>
                      <td className="py-3 px-4">
                        {claim.whereLost} ({claim.whenLost})
                      </td>
                      <td className="py-3 px-4 max-w-xs truncate" title={claim.uniqueFeature}>
                        {claim.uniqueFeature}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            claim.status === 'APPROVED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : claim.status === 'REJECTED'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {claim.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right space-x-1">
                        <button
                          onClick={() => handleUpdateClaimStatus(claim.id, 'APPROVED')}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-[11px]"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => handleUpdateClaimStatus(claim.id, 'REJECTED')}
                          className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-[11px]"
                        >
                          Reject
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* INVENTORY MANAGEMENT TAB */}
      {activeTab === 'ITEMS' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <h2 className="text-sm font-bold text-slate-900">Campus Property Inventory</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Tracking ID</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Item Name</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Location</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {itemsList.map(item => (
                  <tr key={item.id} className="hover:bg-slate-50/50">
                    <td className="py-3 px-4 font-mono font-bold text-blue-600">{item.trackingId}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          item.type === 'LOST' ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'
                        }`}
                      >
                        {item.type}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900">{item.itemName}</td>
                    <td className="py-3 px-4">{item.category}</td>
                    <td className="py-3 px-4">{item.location}</td>
                    <td className="py-3 px-4">
                      <select
                        value={item.status}
                        onChange={e => handleUpdateItemStatus(item.id, e.target.value)}
                        className="px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold"
                      >
                        <option value="LOST">LOST</option>
                        <option value="FOUND">FOUND</option>
                        <option value="MATCHED">MATCHED</option>
                        <option value="CLAIM_PENDING">CLAIM_PENDING</option>
                        <option value="CLAIMED">CLAIMED</option>
                        <option value="RETURNED">RETURNED</option>
                        <option value="CLOSED">CLOSED</option>
                      </select>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleDeleteItem(item.id)}
                        className="text-red-500 hover:text-red-700 p-1"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* USERS MANAGEMENT TAB */}
      {activeTab === 'USERS' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <h2 className="text-sm font-bold text-slate-900">Campus Registered Users</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">User</th>
                  <th className="py-3 px-4">Student/Staff ID</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Year</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4 text-right">Toggle Role</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {usersList.map(u => (
                  <tr key={u.id} className="hover:bg-slate-50/50">
                    <td className="py-3 px-4">
                      <p className="font-bold text-slate-900">{u.fullName}</p>
                      <p className="text-[11px] text-slate-400">{u.email}</p>
                    </td>
                    <td className="py-3 px-4 font-mono">{u.studentId || 'N/A'}</td>
                    <td className="py-3 px-4">{u.department || 'General'}</td>
                    <td className="py-3 px-4">{u.year || 'N/A'}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          u.role === 'ADMIN' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {u.role}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleToggleUserRole(u)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg text-[11px]"
                      >
                        Make {u.role === 'ADMIN' ? 'Student' : 'Admin'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ACTIVITY LOGS TAB */}
      {activeTab === 'LOGS' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <h2 className="text-sm font-bold text-slate-900">Security &amp; System Audit Trail</h2>
          <div className="space-y-3">
            {(dashboardData?.recentActivity || []).map((log: any) => (
              <div key={log.id} className="p-3 bg-slate-50 rounded-2xl border border-slate-100 text-xs flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900">{log.action}</span>
                  <p className="text-slate-600 mt-0.5">{log.details}</p>
                  {log.userName && <span className="text-[11px] text-slate-400">By: {log.userName}</span>}
                </div>
                <span className="text-[11px] text-slate-400">
                  {new Date(log.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
