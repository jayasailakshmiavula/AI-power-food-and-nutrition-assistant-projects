import React, { useState } from 'react';
import {
  User as UserIcon,
  GraduationCap,
  Mail,
  Building,
  Calendar,
  Save,
  Shield,
  Utensils,
  DollarSign,
  AlertCircle,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';

export const ProfilePage: React.FC = () => {
  const { user, profile, refreshUser } = useAuth();

  const [fullName, setFullName] = useState(user?.fullName || '');
  const [studentId, setStudentId] = useState(user?.studentId || '');
  const [department, setDepartment] = useState(user?.department || '');
  const [year, setYear] = useState(user?.year || '');
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.updateProfile({
        fullName,
        studentId,
        department,
        year,
      });
      await refreshUser();
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-16">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 flex items-center gap-2.5">
          <UserIcon className="w-6 h-6 text-blue-600" />
          Student &amp; User Profile
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Manage your personal university credentials, academic department, and linked nutrition targets.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Profile Card Left */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs text-center space-y-4">
          <img
            src={
              user?.avatarUrl ||
              `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user?.fullName || 'User')}`
            }
            alt={user?.fullName}
            className="w-24 h-24 rounded-2xl mx-auto object-cover bg-blue-50 border-2 border-slate-200"
          />

          <div>
            <h2 className="text-lg font-black text-slate-900">{user?.fullName}</h2>
            <p className="text-xs text-slate-500">{user?.email}</p>
            <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold uppercase bg-blue-100 text-blue-800">
              <GraduationCap className="w-3.5 h-3.5" />
              {user?.role}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 text-left text-xs space-y-2 text-slate-600">
            <div className="flex justify-between">
              <span className="text-slate-400">Campus ID:</span>
              <span className="font-mono font-bold">{user?.studentId || 'N/A'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Department:</span>
              <span className="font-semibold">{user?.department || 'Engineering'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Academic Year:</span>
              <span>{user?.year || '3rd Year'}</span>
            </div>
          </div>
        </div>

        {/* Profile Edit Form */}
        <div className="md:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-5">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
            Academic Information
          </h3>

          <form onSubmit={handleUpdate} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                required
                value={fullName}
                onChange={e => setFullName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                disabled
                value={user?.email}
                className="w-full px-3.5 py-2.5 bg-slate-100 text-slate-500 border border-slate-200 rounded-xl font-medium cursor-not-allowed"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Student / Staff ID</label>
                <input
                  type="text"
                  value={studentId}
                  onChange={e => setStudentId(e.target.value)}
                  placeholder="e.g. CS-2023-049"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Department</label>
                <input
                  type="text"
                  value={department}
                  onChange={e => setDepartment(e.target.value)}
                  placeholder="e.g. Computer Science"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Year of Study</label>
              <input
                type="text"
                value={year}
                onChange={e => setYear(e.target.value)}
                placeholder="e.g. 3rd Year"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
              />
            </div>

            <div className="pt-2 flex items-center justify-between">
              {savedSuccess ? (
                <span className="text-emerald-600 font-bold">Profile updated successfully!</span>
              ) : (
                <span />
              )}

              <button
                type="submit"
                disabled={saving}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                {saving ? 'Saving...' : 'Save Profile'}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Linked Nutrition Profile Snapshot */}
      {profile && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Utensils className="w-4 h-4 text-emerald-600" />
              Active Nutrition Parameters
            </h3>
            <span className="text-xs font-semibold text-emerald-600">{profile.primaryGoal}</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
            <div className="bg-slate-50 p-3 rounded-2xl">
              <span className="text-slate-400 block font-semibold">Calorie Target</span>
              <p className="font-mono font-bold text-slate-900 mt-1">{profile.calorieTarget} kcal</p>
            </div>
            <div className="bg-slate-50 p-3 rounded-2xl">
              <span className="text-slate-400 block font-semibold">Protein Target</span>
              <p className="font-mono font-bold text-slate-900 mt-1">{profile.proteinTarget}g / day</p>
            </div>
            <div className="bg-slate-50 p-3 rounded-2xl">
              <span className="text-slate-400 block font-semibold">Diet Type</span>
              <p className="font-bold text-slate-900 mt-1">{profile.dietType}</p>
            </div>
            <div className="bg-slate-50 p-3 rounded-2xl">
              <span className="text-slate-400 block font-semibold">Daily Budget</span>
              <p className="font-mono font-bold text-slate-900 mt-1">₹{profile.dailyBudget}</p>
            </div>
          </div>

          {profile.allergies && profile.allergies.length > 0 && (
            <div className="p-3 bg-red-50/60 rounded-2xl border border-red-100 text-xs text-red-900 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>Strict Allergy Constraints: {profile.allergies.join(', ')}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
