import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Flame,
  Dumbbell,
  Wheat,
  Droplet,
  Search,
  PlusCircle,
  Utensils,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Clock,
  ChevronRight,
  Plus,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { LostFoundItem, ItemMatch } from '../types.ts';

interface StudentDashboardProps {
  onNavigate: (page: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ onNavigate }) => {
  const { user, profile } = useAuth();
  const [summary, setSummary] = useState<any>(null);
  const [lostItemsCount, setLostItemsCount] = useState(0);
  const [foundItemsCount, setFoundItemsCount] = useState(0);
  const [matches, setMatches] = useState<ItemMatch[]>([]);
  const [recentItems, setRecentItems] = useState<LostFoundItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [waterGlasses, setWaterGlasses] = useState(6); // 6 x 250ml = 1500ml

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const [sumRes, itemsRes, matchesRes] = await Promise.all([
          api.getDailySummary(),
          api.getLostFoundItems({}),
          api.getAllMatches(),
        ]);

        if (sumRes.success) setSummary(sumRes.data);

        if (itemsRes.success && Array.isArray(itemsRes.data)) {
          const items: LostFoundItem[] = itemsRes.data;
          setLostItemsCount(items.filter(i => i.type === 'LOST').length);
          setFoundItemsCount(items.filter(i => i.type === 'FOUND').length);
          setRecentItems(items.slice(0, 4));
        }

        if (matchesRes.success && Array.isArray(matchesRes.data)) {
          setMatches(matchesRes.data);
        }
      } catch (err) {
        console.error('Error loading dashboard data:', err);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, []);

  const calories = summary?.consumed?.calories || 1200;
  const calGoal = summary?.goals?.calories || 2200;
  const calPercent = Math.min(Math.round((calories / calGoal) * 100), 100);

  const protein = summary?.consumed?.protein || 64;
  const protGoal = summary?.goals?.protein || 120;
  const protPercent = Math.min(Math.round((protein / protGoal) * 100), 100);

  const carbs = summary?.consumed?.carbs || 158;
  const carbsGoal = summary?.goals?.carbs || 250;

  const waterTotalMl = waterGlasses * 250;
  const waterGoalMl = 3000;
  const waterPercent = Math.min(Math.round((waterTotalMl / waterGoalMl) * 100), 100);

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-white/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 text-white/90 text-xs font-semibold mb-3">
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              Campus Academic Term 2026
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
              Welcome back, {user?.fullName || 'Student'}!
            </h1>
            <p className="text-blue-100 text-sm sm:text-base mt-2 max-w-xl">
              Here is your campus overview today. Track your nutritional milestones and check active lost &amp; found property updates.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => onNavigate('nutrition/meal-planner')}
              className="px-4 py-2.5 bg-white text-blue-800 hover:bg-blue-50 text-xs font-bold rounded-xl shadow-sm transition-all"
            >
              Generate Meal Plan
            </button>
            <button
              onClick={() => onNavigate('lost-found/report-lost')}
              className="px-4 py-2.5 bg-blue-500/40 hover:bg-blue-500/60 text-white text-xs font-bold rounded-xl border border-white/20 transition-all"
            >
              Report Lost Item
            </button>
          </div>
        </div>
      </div>

      {/* Quick Action Buttons Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
        <button
          onClick={() => onNavigate('nutrition/meal-planner')}
          className="p-4 bg-white hover:bg-emerald-50/50 rounded-2xl border border-slate-200 hover:border-emerald-300 text-left transition-all shadow-xs group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <Sparkles className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-900 leading-tight">Generate Meal Plan</p>
          <p className="text-[11px] text-slate-500 mt-1">AI macro &amp; budget planning</p>
        </button>

        <button
          onClick={() => onNavigate('nutrition/analyzer')}
          className="p-4 bg-white hover:bg-emerald-50/50 rounded-2xl border border-slate-200 hover:border-emerald-300 text-left transition-all shadow-xs group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <Utensils className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-900 leading-tight">Analyze Food</p>
          <p className="text-[11px] text-slate-500 mt-1">Image or text nutrition score</p>
        </button>

        <button
          onClick={() => onNavigate('lost-found/report-lost')}
          className="p-4 bg-white hover:bg-red-50/50 rounded-2xl border border-slate-200 hover:border-red-300 text-left transition-all shadow-xs group"
        >
          <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <PlusCircle className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-900 leading-tight">Add Lost Item</p>
          <p className="text-[11px] text-slate-500 mt-1">Get tracking ID &amp; match alerts</p>
        </button>

        <button
          onClick={() => onNavigate('lost-found/report-found')}
          className="p-4 bg-white hover:bg-amber-50/50 rounded-2xl border border-slate-200 hover:border-amber-300 text-left transition-all shadow-xs group"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-900 leading-tight">Report Found Item</p>
          <p className="text-[11px] text-slate-500 mt-1">Deposit at security desk</p>
        </button>

        <button
          onClick={() => onNavigate('lost-found')}
          className="p-4 bg-white hover:bg-blue-50/50 rounded-2xl border border-slate-200 hover:border-blue-300 text-left transition-all shadow-xs group col-span-2 sm:col-span-1"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <Search className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-900 leading-tight">Search Lost &amp; Found</p>
          <p className="text-[11px] text-slate-500 mt-1">Live campus directory</p>
        </button>
      </div>

      {/* Today's Overview Section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Today's Overview</h2>
            <p className="text-xs text-slate-500">Real-time daily wellness metrics &amp; campus items</p>
          </div>
          <button
            onClick={() => onNavigate('nutrition/summary')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
          >
            Detailed Analytics <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Calories Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">Calories</span>
              <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center">
                <Flame className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black text-slate-900">{calories}</span>
                <span className="text-xs text-slate-400 font-medium">/ {calGoal} kcal</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 mt-3 overflow-hidden">
                <div
                  className="bg-orange-500 h-2.5 rounded-full transition-all duration-500"
                  style={{ width: `${calPercent}%` }}
                />
              </div>
              <div className="flex justify-between items-center text-[11px] text-slate-500 mt-2 font-medium">
                <span>{calPercent}% of target</span>
                <span>{Math.max(0, calGoal - calories)} left</span>
              </div>
            </div>
          </div>

          {/* Protein Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">Protein Target</span>
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
                <Dumbbell className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black text-slate-900">{protein}g</span>
                <span className="text-xs text-slate-400 font-medium">/ {protGoal}g</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 mt-3 overflow-hidden">
                <div
                  className="bg-emerald-500 h-2.5 rounded-full transition-all duration-500"
                  style={{ width: `${protPercent}%` }}
                />
              </div>
              <div className="flex justify-between items-center text-[11px] text-slate-500 mt-2 font-medium">
                <span>{protPercent}% target reached</span>
                <span>{Math.max(0, protGoal - protein)}g left</span>
              </div>
            </div>
          </div>

          {/* Carbohydrates Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">Carbohydrates</span>
              <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-600 flex items-center justify-center">
                <Wheat className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black text-slate-900">{carbs}g</span>
                <span className="text-xs text-slate-400 font-medium">/ {carbsGoal}g</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 mt-3 overflow-hidden">
                <div
                  className="bg-amber-500 h-2.5 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(Math.round((carbs / carbsGoal) * 100), 100)}%` }}
                />
              </div>
              <div className="flex justify-between items-center text-[11px] text-slate-500 mt-2 font-medium">
                <span>Energy Reserve</span>
                <span>Active</span>
              </div>
            </div>
          </div>

          {/* Water Intake with Quick +250ml Action */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">Water Intake</span>
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
                <Droplet className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3">
              <div className="flex items-baseline justify-between">
                <div>
                  <span className="text-2xl font-black text-slate-900">
                    {(waterTotalMl / 1000).toFixed(1)}L
                  </span>
                  <span className="text-xs text-slate-400 font-medium"> / 3.0L</span>
                </div>
                <button
                  onClick={() => setWaterGlasses(prev => prev + 1)}
                  className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 text-[11px] font-bold rounded-lg border border-blue-200 flex items-center gap-1 transition-all"
                  title="Add 250ml glass"
                >
                  <Plus className="w-3 h-3" /> +250ml
                </button>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 mt-3 overflow-hidden">
                <div
                  className="bg-blue-500 h-2.5 rounded-full transition-all duration-500"
                  style={{ width: `${waterPercent}%` }}
                />
              </div>
              <div className="flex justify-between items-center text-[11px] text-slate-500 mt-2 font-medium">
                <span>{waterGlasses} glasses</span>
                <span>{waterPercent}% of 3L</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Campus Lost & Found Summary Banner */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              Campus Lost &amp; Found Portal Status
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Current campus inventory and active AI correlation engine
            </p>
          </div>
          <button
            onClick={() => onNavigate('lost-found/matches')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-semibold rounded-xl border border-amber-200 self-start sm:self-auto"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            View Potential AI Matches ({matches.length})
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-5">
          <div
            onClick={() => onNavigate('lost-found?type=LOST')}
            className="p-4 rounded-2xl bg-red-50/60 border border-red-100 hover:border-red-200 cursor-pointer transition-all"
          >
            <span className="text-xs font-bold text-red-700">Lost Items Reported</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-3xl font-extrabold text-red-900">{lostItemsCount}</span>
              <span className="text-xs text-red-600 font-medium">Pending return</span>
            </div>
          </div>

          <div
            onClick={() => onNavigate('lost-found?type=FOUND')}
            className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-100 hover:border-emerald-200 cursor-pointer transition-all"
          >
            <span className="text-xs font-bold text-emerald-700">Found Items Logged</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-3xl font-extrabold text-emerald-900">{foundItemsCount}</span>
              <span className="text-xs text-emerald-600 font-medium">At security desk</span>
            </div>
          </div>

          <div
            onClick={() => onNavigate('lost-found/matches')}
            className="p-4 rounded-2xl bg-amber-50/60 border border-amber-100 hover:border-amber-200 cursor-pointer transition-all"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-800">Potential Matches</span>
              <span className="text-[10px] bg-amber-200 text-amber-900 font-bold px-1.5 py-0.5 rounded-full">
                AI Match
              </span>
            </div>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-3xl font-extrabold text-amber-900">{matches.length}</span>
              <span className="text-xs text-amber-700 font-medium">High confidence</span>
            </div>
          </div>
        </div>
      </div>

      {/* Two Columns: Recent Lost & Found Items + Today's Logged Meals */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Lost & Found Items */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-900 text-sm">Recent Campus Items</h3>
            <button
              onClick={() => onNavigate('lost-found')}
              className="text-xs text-blue-600 font-semibold hover:underline"
            >
              Browse All
            </button>
          </div>

          <div className="space-y-3">
            {recentItems.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">No recent items reported</p>
            ) : (
              recentItems.map(item => (
                <div
                  key={item.id}
                  onClick={() => onNavigate(`lost-found/${item.id}`)}
                  className="flex items-center gap-3 p-3 rounded-2xl hover:bg-slate-50 border border-slate-100 cursor-pointer transition-all"
                >
                  <img
                    src={item.imageUrl || 'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=100'}
                    alt={item.itemName}
                    className="w-12 h-12 rounded-xl object-cover bg-slate-100 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                          item.type === 'LOST'
                            ? 'bg-red-100 text-red-700'
                            : 'bg-emerald-100 text-emerald-700'
                        }`}
                      >
                        {item.type}
                      </span>
                      <span className="text-xs text-slate-400 truncate">{item.trackingId}</span>
                    </div>
                    <p className="text-xs font-bold text-slate-900 truncate mt-0.5">
                      {item.itemName}
                    </p>
                    <p className="text-[11px] text-slate-500 truncate">
                      📍 {item.location} • 📅 {item.date}
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-300 shrink-0" />
                </div>
              ))
            )}
          </div>
        </div>

        {/* Today's Meals & Nutrition Summary */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-900 text-sm">Today's Meal Timeline</h3>
            <button
              onClick={() => onNavigate('nutrition/summary')}
              className="text-xs text-emerald-600 font-semibold hover:underline"
            >
              + Log Food
            </button>
          </div>

          <div className="space-y-3">
            {summary?.todayLogs && summary.todayLogs.length > 0 ? (
              summary.todayLogs.map((log: any) => (
                <div
                  key={log.id}
                  className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs"
                >
                  <div>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full uppercase">
                      {log.mealType}
                    </span>
                    <p className="font-bold text-slate-900 mt-1">{log.foodName}</p>
                    <p className="text-[11px] text-slate-500">
                      Prot: {log.protein}g • Carbs: {log.carbs}g • Fat: {log.fat}g
                    </p>
                  </div>
                  <span className="font-black text-slate-800 text-sm">
                    {log.calories} kcal
                  </span>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-slate-400">
                <Utensils className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                <p className="text-xs">No meals logged for today yet.</p>
                <button
                  onClick={() => onNavigate('nutrition/summary')}
                  className="mt-2 text-xs font-semibold text-emerald-600 hover:underline"
                >
                  Log your breakfast or lunch
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
