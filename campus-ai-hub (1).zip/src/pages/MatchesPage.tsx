import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  MapPin,
  Calendar,
  Layers,
  ChevronRight,
  X,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { ItemMatch, LostFoundItem } from '../types.ts';

interface MatchesPageProps {
  onNavigate: (page: string) => void;
}

export const MatchesPage: React.FC<MatchesPageProps> = ({ onNavigate }) => {
  const [matches, setMatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMatch, setSelectedMatch] = useState<any | null>(null);

  // Claim dialog
  const [showClaimModal, setShowClaimModal] = useState(false);
  const [claimWhere, setClaimWhere] = useState('');
  const [claimWhen, setClaimWhen] = useState('');
  const [claimFeature, setClaimFeature] = useState('');
  const [claimSubmitted, setClaimSubmitted] = useState(false);

  useEffect(() => {
    loadMatches();
  }, []);

  const loadMatches = async () => {
    try {
      setLoading(true);
      const res = await api.getAllMatches();
      if (res.success && Array.isArray(res.data)) {
        setMatches(res.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenClaim = (match: any) => {
    setSelectedMatch(match);
    setShowClaimModal(true);
    setClaimWhere(match.lostItem?.location || '');
    setClaimWhen(match.lostItem?.date || '');
    setClaimFeature(match.lostItem?.uniqueFeatures || '');
    setClaimSubmitted(false);
  };

  const handleSubmitClaim = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMatch?.foundItem) return;

    try {
      const res = await api.claimItem(selectedMatch.foundItem.id, {
        whereLost: claimWhere,
        whenLost: claimWhen,
        uniqueFeature: claimFeature,
      });

      if (res.success) {
        setClaimSubmitted(true);
        setTimeout(() => {
          setShowClaimModal(false);
          loadMatches();
        }, 2500);
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-16">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-800 text-xs font-bold rounded-full mb-2 border border-amber-200">
          <Sparkles className="w-3.5 h-3.5 text-amber-600" />
          AI Multi-Factor Correlation Engine
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
          AI Lost &amp; Found Item Matches
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Automated comparison between reported lost belongings and verified turned-in items across campus.
        </p>
      </div>

      {/* Verification Notice Banner */}
      <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-2xl flex items-start gap-3 text-xs text-blue-900 shadow-xs">
        <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Security Verification Protocol: </span>
          AI matching computes mathematical similarity but does not automatically transfer ownership.
          To claim an item, submit physical verification details which are reviewed by Campus Security before release.
        </div>
      </div>

      {/* Matches Grid */}
      {loading ? (
        <div className="text-center py-16 text-slate-400 text-xs animate-pulse">
          Computing correlation scores...
        </div>
      ) : matches.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 text-slate-400">
          <Sparkles className="w-12 h-12 mx-auto text-slate-300 mb-2" />
          <p className="text-sm font-semibold">No high-confidence matches found yet.</p>
          <p className="text-xs mt-1">
            As students and security desks report items, the AI engine will automatically correlate them.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {matches.map((match: any) => {
            const lost = match.lostItem;
            const found = match.foundItem;
            if (!lost || !found) return null;

            return (
              <div
                key={match.id}
                className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs hover:border-amber-300 transition-all space-y-6"
              >
                {/* Match Header with Score */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-14 h-14 rounded-2xl flex items-center justify-center font-black text-xl text-white shadow-sm ${
                        match.score >= 85
                          ? 'bg-emerald-600'
                          : match.score >= 70
                          ? 'bg-amber-500'
                          : 'bg-blue-600'
                      }`}
                    >
                      {match.score}%
                    </div>
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        Correlation Confidence
                      </span>
                      <h3 className="text-lg font-black text-slate-900">
                        Potential Match: {lost.itemName}
                      </h3>
                      <p className="text-xs text-slate-500">
                        Lost ID: <span className="font-mono">{lost.trackingId}</span> ↔ Found ID:{' '}
                        <span className="font-mono">{found.trackingId}</span>
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleOpenClaim(match)}
                    className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 self-start sm:self-auto transition-colors"
                  >
                    Claim This Item
                  </button>
                </div>

                {/* Side-by-Side Comparison */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-50/70 p-5 rounded-2xl border border-slate-200/60">
                  {/* Left: Lost Item Report */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-red-100 text-red-700">
                        Reported Lost
                      </span>
                      <span className="text-xs text-slate-400">{lost.date}</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <img
                        src={lost.imageUrl || 'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=100'}
                        alt={lost.itemName}
                        className="w-16 h-16 rounded-xl object-cover bg-slate-200 shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="font-bold text-slate-900 text-sm truncate">{lost.itemName}</p>
                        <p className="text-xs text-slate-500 truncate">
                          📍 {lost.location}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          Color: {lost.color} {lost.brand ? `• Brand: ${lost.brand}` : ''}
                        </p>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed bg-white p-3 rounded-xl border border-slate-100 line-clamp-2">
                      {lost.description}
                    </p>
                  </div>

                  {/* Right: Found Item Record */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-100 text-emerald-700">
                        Deposited / Found
                      </span>
                      <span className="text-xs text-slate-400">{found.date}</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <img
                        src={found.imageUrl || 'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=100'}
                        alt={found.itemName}
                        className="w-16 h-16 rounded-xl object-cover bg-slate-200 shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="font-bold text-slate-900 text-sm truncate">{found.itemName}</p>
                        <p className="text-xs text-slate-500 truncate">
                          📍 {found.location}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          Color: {found.color} {found.brand ? `• Brand: ${found.brand}` : ''}
                        </p>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed bg-white p-3 rounded-xl border border-slate-100 line-clamp-2">
                      {found.description}
                    </p>
                  </div>
                </div>

                {/* AI Match Reasons */}
                <div>
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                    Verified Match Reasons
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {match.reasons.map((reason: string, i: number) => (
                      <div
                        key={i}
                        className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-50/50 border border-emerald-100 text-xs text-emerald-900"
                      >
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>{reason}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Claim Dialog */}
      {showClaimModal && selectedMatch && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-5">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                  Ownership Verification
                </span>
                <h2 className="text-lg font-black text-slate-900 mt-1">
                  Claim Item: {selectedMatch.foundItem?.itemName}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Confirm identifying features to initiate administrative release.
                </p>
              </div>
              <button
                onClick={() => setShowClaimModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {claimSubmitted ? (
              <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-2 animate-bounce">
                <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                <h3 className="text-sm font-bold text-emerald-900">Claim Request Submitted!</h3>
                <p className="text-xs text-emerald-700">
                  Campus security will verify the details and notify you.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitClaim} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Where did you lose it on campus?
                  </label>
                  <input
                    type="text"
                    required
                    value={claimWhere}
                    onChange={e => setClaimWhere(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">When did you lose it?</label>
                  <input
                    type="text"
                    required
                    value={claimWhen}
                    onChange={e => setClaimWhen(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Describe a unique identifying feature
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={claimFeature}
                    onChange={e => setClaimFeature(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white resize-none"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowClaimModal(false)}
                    className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl shadow-xs"
                  >
                    Confirm &amp; Submit Claim
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
