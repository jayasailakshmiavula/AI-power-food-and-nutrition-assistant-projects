import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  PlusCircle,
  CheckCircle2,
  MapPin,
  Calendar,
  Tag,
  ShieldCheck,
  Sparkles,
  ExternalLink,
  ChevronDown,
  X,
  Clock,
  User,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { LostFoundItem } from '../types.ts';
import { useAuth } from '../context/AuthContext.tsx';

const CATEGORIES = [
  'All',
  'ID Card',
  'Books',
  'Calculator',
  'Bottle',
  'Wallet',
  'Phone',
  'Laptop',
  'Keys',
  'Bag',
  'Clothing',
  'Accessories',
  'Other',
];

interface LostFoundBrowsePageProps {
  onNavigate: (page: string) => void;
  initialQuery?: string;
}

export const LostFoundBrowsePage: React.FC<LostFoundBrowsePageProps> = ({
  onNavigate,
  initialQuery = '',
}) => {
  const { user } = useAuth();
  const [items, setItems] = useState<LostFoundItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [activeTypeTab, setActiveTypeTab] = useState<'ALL' | 'LOST' | 'FOUND'>('ALL');
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');

  // Details Modal
  const [selectedItem, setSelectedItem] = useState<LostFoundItem | null>(null);

  // Claim Modal
  const [showClaimModal, setShowClaimModal] = useState(false);
  const [claimWhere, setClaimWhere] = useState('');
  const [claimWhen, setClaimWhen] = useState('');
  const [claimFeature, setClaimFeature] = useState('');
  const [claimProof, setClaimProof] = useState('');
  const [claimSubmitted, setClaimSubmitted] = useState(false);

  const loadItems = async () => {
    try {
      setLoading(true);
      const params: Record<string, string> = {};
      if (activeTypeTab !== 'ALL') params.type = activeTypeTab;
      if (selectedCategory !== 'All') params.category = selectedCategory;
      if (selectedStatus !== 'All') params.status = selectedStatus;
      if (searchQuery.trim()) params.query = searchQuery.trim();

      const res = await api.getLostFoundItems(params);
      if (res.success && Array.isArray(res.data)) {
        setItems(res.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadItems();
  }, [activeTypeTab, selectedCategory, selectedStatus]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadItems();
  };

  const handleOpenClaim = (item: LostFoundItem) => {
    setSelectedItem(item);
    setShowClaimModal(true);
    setClaimWhere('');
    setClaimWhen('');
    setClaimFeature('');
    setClaimProof('');
    setClaimSubmitted(false);
  };

  const handleSubmitClaim = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return;

    try {
      const res = await api.claimItem(selectedItem.id, {
        whereLost: claimWhere,
        whenLost: claimWhen,
        uniqueFeature: claimFeature,
        proofNotes: claimProof,
      });

      if (res.success) {
        setClaimSubmitted(true);
        loadItems();
        setTimeout(() => {
          setShowClaimModal(false);
          setSelectedItem(null);
        }, 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'LOST':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'FOUND':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'MATCHED':
        return 'bg-purple-100 text-purple-700 border-purple-200 animate-pulse';
      case 'CLAIM_PENDING':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'CLAIMED':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'RETURNED':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 flex items-center gap-2.5">
            <Search className="w-6 h-6 text-amber-500" />
            Campus Lost &amp; Found Portal
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Search, report, and recover lost campus belongings with intelligent verification.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onNavigate('lost-found/report-lost')}
            className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 transition-colors"
          >
            <PlusCircle className="w-4 h-4" /> Report Lost
          </button>
          <button
            onClick={() => onNavigate('lost-found/report-found')}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 transition-colors"
          >
            <CheckCircle2 className="w-4 h-4" /> Report Found
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
        {/* Type Tabs: All, Lost, Found */}
        <div className="flex items-center gap-2 border-b border-slate-100 pb-4">
          <button
            onClick={() => setActiveTypeTab('ALL')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTypeTab === 'ALL'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Items
          </button>
          <button
            onClick={() => setActiveTypeTab('LOST')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTypeTab === 'LOST'
                ? 'bg-red-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Lost Reports
          </button>
          <button
            onClick={() => setActiveTypeTab('FOUND')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTypeTab === 'FOUND'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Found Turn-Ins
          </button>
        </div>

        {/* Search Input & Selectors */}
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by name, description, brand, location, or tracking ID..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-blue-500"
            />
          </div>

          <div className="sm:col-span-3">
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white"
            >
              {CATEGORIES.map(cat => (
                <option key={cat} value={cat}>
                  Category: {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-3 flex gap-2">
            <select
              value={selectedStatus}
              onChange={e => setSelectedStatus(e.target.value)}
              className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white"
            >
              <option value="All">Status: All</option>
              <option value="LOST">Status: Lost</option>
              <option value="FOUND">Status: Found</option>
              <option value="MATCHED">Status: Matched</option>
              <option value="CLAIM_PENDING">Status: Claim Pending</option>
              <option value="RETURNED">Status: Returned</option>
            </select>

            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs"
            >
              Search
            </button>
          </div>
        </form>
      </div>

      {/* Items Cards Grid */}
      {loading ? (
        <div className="text-center py-16 text-slate-400 text-xs animate-pulse">
          Loading campus inventory...
        </div>
      ) : items.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 text-slate-400">
          <Search className="w-12 h-12 mx-auto text-slate-300 mb-2" />
          <p className="text-sm font-semibold">No items found matching criteria.</p>
          <p className="text-xs mt-1">Lost something on campus? Report it right away.</p>
          <button
            onClick={() => onNavigate('lost-found/report-lost')}
            className="mt-4 px-4 py-2 bg-red-600 text-white text-xs font-bold rounded-xl inline-flex items-center gap-1.5"
          >
            <PlusCircle className="w-3.5 h-3.5" /> Report Lost Item
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map(item => (
            <div
              key={item.id}
              className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-xs hover:shadow-md hover:border-slate-300 transition-all flex flex-col group"
            >
              {/* Image & Badges */}
              <div className="relative h-48 bg-slate-100 overflow-hidden">
                <img
                  src={
                    item.imageUrl ||
                    'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=400&auto=format&fit=crop&q=80'
                  }
                  alt={item.itemName}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />

                <div className="absolute top-3 left-3 flex items-center gap-1.5">
                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      item.type === 'LOST'
                        ? 'bg-red-600 text-white'
                        : 'bg-emerald-600 text-white'
                    }`}
                  >
                    {item.type}
                  </span>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-white/90 backdrop-blur-xs text-slate-800">
                    {item.category}
                  </span>
                </div>

                <div className="absolute top-3 right-3">
                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase border shadow-xs ${getStatusBadge(
                      item.status
                    )}`}
                  >
                    {item.status.replace('_', ' ')}
                  </span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>{item.trackingId}</span>
                    {item.brand && <span>Brand: {item.brand}</span>}
                  </div>
                  <h3 className="font-bold text-slate-900 text-base mt-1 line-clamp-1">
                    {item.itemName}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="space-y-1.5 text-xs text-slate-500 pt-2 border-t border-slate-100">
                  <div className="flex items-center gap-1.5 truncate">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{item.location}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>
                      {item.date} {item.time ? `• ${item.time}` : ''}
                    </span>
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={() => setSelectedItem(item)}
                    className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-colors text-center"
                  >
                    View Details
                  </button>

                  {item.type === 'FOUND' && item.status !== 'RETURNED' && (
                    <button
                      onClick={() => handleOpenClaim(item)}
                      className="px-3 py-2 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-xl transition-colors shadow-xs"
                    >
                      Claim Item
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Item Details Modal */}
      {selectedItem && !showClaimModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      selectedItem.type === 'LOST'
                        ? 'bg-red-100 text-red-700'
                        : 'bg-emerald-100 text-emerald-700'
                    }`}
                  >
                    {selectedItem.type}
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    {selectedItem.trackingId}
                  </span>
                </div>
                <h2 className="text-xl font-black text-slate-900 mt-1">
                  {selectedItem.itemName}
                </h2>
              </div>
              <button
                onClick={() => setSelectedItem(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <img
              src={selectedItem.imageUrl}
              alt={selectedItem.itemName}
              className="w-full h-56 object-cover rounded-2xl bg-slate-100"
            />

            <div className="space-y-4 text-xs">
              <div>
                <span className="font-bold text-slate-700 block mb-1">Description</span>
                <p className="text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl">
                  {selectedItem.description}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-50 p-3 rounded-xl">
                  <span className="font-bold text-slate-700 block">Category</span>
                  <p className="text-slate-600 mt-0.5">{selectedItem.category}</p>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl">
                  <span className="font-bold text-slate-700 block">Color / Brand</span>
                  <p className="text-slate-600 mt-0.5">
                    {selectedItem.color} {selectedItem.brand ? `(${selectedItem.brand})` : ''}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-50 p-3 rounded-xl">
                  <span className="font-bold text-slate-700 block">Location</span>
                  <p className="text-slate-600 mt-0.5">{selectedItem.location}</p>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl">
                  <span className="font-bold text-slate-700 block">Date &amp; Time</span>
                  <p className="text-slate-600 mt-0.5">
                    {selectedItem.date} {selectedItem.time}
                  </p>
                </div>
              </div>

              {selectedItem.uniqueFeatures && (
                <div>
                  <span className="font-bold text-slate-700 block mb-1">
                    Unique Identifying Features
                  </span>
                  <p className="text-slate-600 bg-amber-50/50 p-3 rounded-xl border border-amber-100">
                    {selectedItem.uniqueFeatures}
                  </p>
                </div>
              )}

              {selectedItem.submittedLocation && (
                <div>
                  <span className="font-bold text-slate-700 block mb-1">
                    Where Item Was Turned In
                  </span>
                  <p className="text-slate-600 bg-emerald-50/50 p-3 rounded-xl border border-emerald-100">
                    🏢 {selectedItem.submittedLocation}
                  </p>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
              <button
                onClick={() => setSelectedItem(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
              >
                Close
              </button>
              {selectedItem.type === 'FOUND' && selectedItem.status !== 'RETURNED' && (
                <button
                  onClick={() => setShowClaimModal(true)}
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Claim This Item
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Claim Modal Flow */}
      {showClaimModal && selectedItem && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-5">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                  Verification Required
                </span>
                <h2 className="text-lg font-black text-slate-900 mt-1">
                  Claim Item: {selectedItem.itemName}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Help security verify your ownership before releasing this item.
                </p>
              </div>
              <button
                onClick={() => setShowClaimModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {claimSubmitted ? (
              <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-2 animate-bounce">
                <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                <h3 className="text-sm font-bold text-emerald-900">Claim Request Submitted!</h3>
                <p className="text-xs text-emerald-700">
                  Campus security will review your responses. Check notifications or "My Reports" for updates.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitClaim} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Where did you lose it on campus?
                  </label>
                  <input
                    type="text"
                    required
                    value={claimWhere}
                    onChange={e => setClaimWhere(e.target.value)}
                    placeholder="e.g. Central Library 2nd floor desk near windows"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">When did you lose it?</label>
                  <input
                    type="text"
                    required
                    value={claimWhen}
                    onChange={e => setClaimWhen(e.target.value)}
                    placeholder="e.g. Yesterday afternoon around 4:30 PM (Oct 5)"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Describe a unique identifying feature
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={claimFeature}
                    onChange={e => setClaimFeature(e.target.value)}
                    placeholder="e.g. Small scratch near power switch, sticker of astronaut, initials on slip cover..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white resize-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Proof Notes / Receipt / Student ID reference
                  </label>
                  <input
                    type="text"
                    value={claimProof}
                    onChange={e => setClaimProof(e.target.value)}
                    placeholder="e.g. Have purchase invoice on Amazon, Student ID matching initials"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowClaimModal(false)}
                    className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl shadow-xs"
                  >
                    Submit Claim for Verification
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
