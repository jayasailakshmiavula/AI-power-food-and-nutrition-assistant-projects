import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Utensils,
  RefreshCw,
  Printer,
  Bookmark,
  ShoppingCart,
  Plus,
  Trash2,
  DollarSign,
  AlertCircle,
  Clock,
  Layers,
  ChevronRight,
  Flame,
  Check,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { MealPlan, MealItem } from '../types.ts';

interface NutritionPlannerPageProps {
  onNavigate: (page: string) => void;
}

export const NutritionPlannerPage: React.FC<NutritionPlannerPageProps> = ({ onNavigate }) => {
  const { user, profile, setProfile } = useAuth();

  // Form states
  const [goal, setGoal] = useState<string>(profile?.primaryGoal || 'Build Muscle');
  const [calories, setCalories] = useState<number>(profile?.calorieTarget || 2300);
  const [proteinTarget, setProteinTarget] = useState<number>(profile?.proteinTarget || 120);
  const [budget, setBudget] = useState<number>(profile?.dailyBudget || 220);
  const [diet, setDiet] = useState<string>(profile?.dietType || 'High Protein');
  const [allergiesInput, setAllergiesInput] = useState<string>(profile?.allergies?.join(', ') || 'Peanuts');
  const [preferencesInput, setPreferencesInput] = useState<string>(profile?.foodPreferences?.join(', ') || 'Oatmeal, Paneer, Eggs, Bananas');
  const [ingredientsInput, setIngredientsInput] = useState<string>(profile?.availableIngredients?.join(', ') || 'Eggs, Oats, Milk, Spinach, Rice, Curd');

  const [activePlan, setActivePlan] = useState<MealPlan | null>(null);
  const [savedPlans, setSavedPlans] = useState<MealPlan[]>([]);
  const [generating, setGenerating] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [grocerySuccess, setGrocerySuccess] = useState<boolean>(false);
  const [showConfig, setShowConfig] = useState<boolean>(true);

  useEffect(() => {
    loadSavedPlans();
  }, []);

  const loadSavedPlans = async () => {
    try {
      const res = await api.getMealPlans();
      if (res.success && Array.isArray(res.data)) {
        setSavedPlans(res.data);
        if (res.data.length > 0 && !activePlan) {
          setActivePlan(res.data[0]);
        }
      }
    } catch (err) {
      console.error('Failed to load meal plans:', err);
    }
  };

  const handleGeneratePlan = async () => {
    setGenerating(true);
    setSaveSuccess(false);
    setGrocerySuccess(false);

    try {
      const allergies = allergiesInput.split(',').map(s => s.trim()).filter(Boolean);
      const preferences = preferencesInput.split(',').map(s => s.trim()).filter(Boolean);
      const availableIngredients = ingredientsInput.split(',').map(s => s.trim()).filter(Boolean);

      const payload = {
        goal,
        calories: Number(calories),
        proteinTarget: Number(proteinTarget),
        budget: Number(budget),
        diet,
        allergies,
        preferences,
        availableIngredients,
      };

      const res = await api.generateMealPlan(payload);
      if (res.success && res.data) {
        const generated = res.data;
        const newPlan: MealPlan = {
          id: 'temp_' + Date.now(),
          userId: user?.id || 'usr_demo',
          title: generated.title || `Campus ${goal} Meal Plan`,
          goal,
          totalCalories: generated.totalCalories,
          totalProtein: generated.totalProtein,
          totalCost: generated.totalCost,
          diet: generated.diet || diet,
          meals: generated.meals,
          createdAt: new Date().toISOString(),
        };
        setActivePlan(newPlan);
        setShowConfig(false);
      }
    } catch (err) {
      console.error('Error generating plan:', err);
    } finally {
      setGenerating(false);
    }
  };

  const handleSavePlan = async () => {
    if (!activePlan) return;
    try {
      const res = await api.saveMealPlan(activePlan);
      if (res.success) {
        setSaveSuccess(true);
        loadSavedPlans();
        setTimeout(() => setSaveSuccess(false), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSyncToGrocery = async () => {
    try {
      const res = await api.syncGroceryFromPlan(activePlan?.id);
      if (res.success) {
        setGrocerySuccess(true);
        setTimeout(() => setGrocerySuccess(false), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-16">
      {/* Medical Guidance Disclaimer Banner */}
      <div className="p-4 bg-amber-50/80 border border-amber-200/80 rounded-2xl flex items-start gap-3 text-xs text-amber-900 shadow-xs">
        <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">General Guidance Disclaimer: </span>
          Nutrition and meal suggestions provided are generated as educational guidance for university students.
          They do not constitute medical diagnosis or clinical dietetic treatment. Students with allergies or metabolic conditions should consult a qualified health professional.
        </div>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 flex items-center gap-2.5">
            <Sparkles className="w-6 h-6 text-emerald-600" />
            AI Meal Planner
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Build nutritious, cost-optimized meal schedules tailored to student budgets and hostel kitchens.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowConfig(!showConfig)}
            className="px-4 py-2 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl border border-slate-200 shadow-xs transition-colors"
          >
            {showConfig ? 'Hide Parameters' : 'Edit Constraints'}
          </button>
          <button
            onClick={handleGeneratePlan}
            disabled={generating}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-600/20 flex items-center gap-2 transition-all hover:scale-[1.02]"
          >
            <Sparkles className={`w-3.5 h-3.5 ${generating ? 'animate-spin' : ''}`} />
            {generating ? 'Generating with AI...' : 'Generate My Meal Plan'}
          </button>
        </div>
      </div>

      {/* Config Form / Parameters Drawer */}
      {showConfig && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <h2 className="text-sm font-bold text-slate-900">Configure Your Nutritional Targets &amp; Budget</h2>
            <span className="text-xs text-slate-400">Strict allergy filters enforced</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Primary Goal */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Primary Goal</label>
              <select
                value={goal}
                onChange={e => setGoal(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-blue-500"
              >
                <option value="Lose Weight">Lose Weight</option>
                <option value="Gain Weight">Gain Weight</option>
                <option value="Build Muscle">Build Muscle</option>
                <option value="Maintain Weight">Maintain Weight</option>
                <option value="Improve General Health">Improve General Health</option>
              </select>
            </div>

            {/* Diet Type */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Diet Type</label>
              <select
                value={diet}
                onChange={e => setDiet(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-blue-500"
              >
                <option value="Vegetarian">Vegetarian</option>
                <option value="Vegan">Vegan</option>
                <option value="Non-Vegetarian">Non-Vegetarian</option>
                <option value="Eggetarian">Eggetarian</option>
                <option value="High Protein">High Protein</option>
                <option value="Keto">Keto</option>
                <option value="No Preference">No Preference</option>
              </select>
            </div>

            {/* Daily Calorie Target */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Calories (kcal)</label>
              <input
                type="number"
                value={calories}
                onChange={e => setCalories(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-blue-500"
                placeholder="2200"
              />
            </div>

            {/* Protein Target */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Protein (g)</label>
              <input
                type="number"
                value={proteinTarget}
                onChange={e => setProteinTarget(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-blue-500"
                placeholder="120"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Daily Budget */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Daily Budget (₹ / $)</label>
              <input
                type="number"
                value={budget}
                onChange={e => setBudget(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-blue-500"
                placeholder="250"
              />
            </div>

            {/* Allergies */}
            <div>
              <label className="block text-xs font-bold text-red-600 mb-1.5">
                Allergies (Strict Exclusions)
              </label>
              <input
                type="text"
                value={allergiesInput}
                onChange={e => setAllergiesInput(e.target.value)}
                className="w-full px-3 py-2 bg-red-50/40 border border-red-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-red-500"
                placeholder="e.g. Peanuts, Shellfish, Gluten"
              />
            </div>

            {/* Food Preferences */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Preferences / Favorites</label>
              <input
                type="text"
                value={preferencesInput}
                onChange={e => setPreferencesInput(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-blue-500"
                placeholder="Oats, Paneer, Chicken, Bananas"
              />
            </div>

            {/* Available Ingredients */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Available In Pantry</label>
              <input
                type="text"
                value={ingredientsInput}
                onChange={e => setIngredientsInput(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-blue-500"
                placeholder="Rice, Lentils, Curd, Bread"
              />
            </div>
          </div>
        </div>
      )}

      {/* Loading Skeleton */}
      {generating && (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs space-y-4 animate-pulse">
          <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
            <Sparkles className="w-8 h-8 animate-spin" />
          </div>
          <h3 className="text-lg font-bold text-slate-800">
            Generating your personalized meal plan...
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Balancing {calories} kcal, {proteinTarget}g protein, hostel cooking simplicity, and your daily budget of ₹{budget}...
          </p>
        </div>
      )}

      {/* Active Plan Display */}
      {!generating && activePlan && (
        <div className="space-y-6">
          {/* Plan Summary Bar */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full">
                  {activePlan.diet}
                </span>
                <span className="text-xs text-slate-400 font-medium">• Goal: {activePlan.goal}</span>
              </div>
              <h2 className="text-xl font-extrabold text-slate-900 mt-1">{activePlan.title}</h2>
              <div className="flex flex-wrap items-center gap-4 text-xs font-semibold text-slate-600 mt-2">
                <span>🔥 {activePlan.totalCalories} kcal</span>
                <span>💪 {activePlan.totalProtein}g protein</span>
                <span>💰 Estimated Cost: ₹{activePlan.totalCost}</span>
              </div>
            </div>

            {/* Action Buttons: Regenerate, Replace, Save, Print */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={handleGeneratePlan}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors"
                title="Regenerate Plan"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Regenerate
              </button>

              <button
                onClick={handleSavePlan}
                className="px-3.5 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors border border-blue-200"
              >
                <Bookmark className="w-3.5 h-3.5" />
                {saveSuccess ? 'Saved!' : 'Save Plan'}
              </button>

              <button
                onClick={handleSyncToGrocery}
                className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors border border-emerald-200"
              >
                <ShoppingCart className="w-3.5 h-3.5" />
                {grocerySuccess ? 'Synced to List!' : 'Add to Grocery'}
              </button>

              <button
                onClick={handlePrint}
                className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-colors"
                title="Print Plan"
              >
                <Printer className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Meals Grid: Breakfast, Lunch, Snack, Dinner */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {activePlan.meals.map((meal: MealItem, idx: number) => (
              <div
                key={idx}
                className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs hover:border-emerald-200 transition-all space-y-4"
              >
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full uppercase tracking-wider border border-emerald-100">
                      {meal.mealType}
                    </span>
                    <h3 className="text-base font-bold text-slate-900 mt-2">{meal.mealName}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">Serving: {meal.servingSize}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-black text-slate-900">{meal.calories} kcal</span>
                    <p className="text-[11px] text-emerald-600 font-bold mt-0.5">
                      {meal.protein}g protein
                    </p>
                  </div>
                </div>

                {/* Macro Strip */}
                <div className="grid grid-cols-4 gap-2 bg-slate-50 p-2.5 rounded-2xl text-center text-xs">
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-semibold">Prot</p>
                    <p className="font-bold text-slate-800">{meal.protein}g</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-semibold">Carbs</p>
                    <p className="font-bold text-slate-800">{meal.carbs}g</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-semibold">Fat</p>
                    <p className="font-bold text-slate-800">{meal.fat}g</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-semibold">Cost</p>
                    <p className="font-bold text-emerald-700">₹{meal.estimatedCost}</p>
                  </div>
                </div>

                {/* Ingredients */}
                <div>
                  <h4 className="text-xs font-bold text-slate-700 mb-1.5">Ingredients</h4>
                  <ul className="text-xs text-slate-600 space-y-1">
                    {meal.ingredients.map((ing, i) => (
                      <li key={i} className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                        <span>{ing}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Preparation Instructions */}
                <div className="pt-2 border-t border-slate-100">
                  <h4 className="text-xs font-bold text-slate-700 mb-1">Quick Prep Instructions</h4>
                  <p className="text-xs text-slate-600 leading-relaxed bg-emerald-50/40 p-3 rounded-xl border border-emerald-100/50">
                    {meal.preparationInstructions}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Saved Meal Plans Carousel / List */}
      {savedPlans.length > 0 && (
        <div className="bg-slate-50 rounded-3xl p-6 border border-slate-200 space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Your Saved Meal Plans</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {savedPlans.map(plan => (
              <div
                key={plan.id}
                onClick={() => setActivePlan(plan)}
                className={`p-4 rounded-2xl bg-white border cursor-pointer transition-all ${
                  activePlan?.id === plan.id
                    ? 'border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-bold text-slate-900 truncate">{plan.title}</span>
                  <span className="text-[10px] text-slate-400">{plan.diet}</span>
                </div>
                <p className="text-xs text-slate-500">
                  {plan.totalCalories} kcal • {plan.totalProtein}g protein • ₹{plan.totalCost}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
