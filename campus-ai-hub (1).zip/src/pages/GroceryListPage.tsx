import React, { useState, useEffect } from 'react';
import {
  ShoppingCart,
  Plus,
  Trash2,
  Check,
  RefreshCw,
  Sparkles,
  DollarSign,
  Layers,
  CheckCheck,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { GroceryItem } from '../types.ts';

const CATEGORIES: Array<GroceryItem['category']> = [
  'Vegetables',
  'Fruits',
  'Grains',
  'Protein',
  'Dairy',
  'Spices',
  'Other',
];

export const GroceryListPage: React.FC = () => {
  const [items, setItems] = useState<GroceryItem[]>([]);
  const [estimatedTotal, setEstimatedTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  // Add Item form
  const [newItemName, setNewItemName] = useState('');
  const [newItemCategory, setNewItemCategory] = useState<GroceryItem['category']>('Vegetables');
  const [newItemQuantity, setNewItemQuantity] = useState('1 kg');
  const [newItemPrice, setNewItemPrice] = useState('80');

  const loadGroceryList = async () => {
    try {
      setLoading(true);
      const res = await api.getGroceryList();
      if (res.success && res.data) {
        setItems(res.data.items || []);
        setEstimatedTotal(res.data.estimatedTotal || 0);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadGroceryList();
  }, []);

  const handleTogglePurchased = async (item: GroceryItem) => {
    try {
      const updated = !item.purchased;
      await api.updateGroceryItem(item.id, { purchased: updated });
      setItems(prev =>
        prev.map(i => (i.id === item.id ? { ...i, purchased: updated } : i))
      );
      // recalculate total
      const newTotal = items.reduce(
        (sum, i) =>
          sum +
          (i.id === item.id
            ? updated
              ? 0
              : i.estimatedPrice
            : i.purchased
            ? 0
            : i.estimatedPrice),
        0
      );
      setEstimatedTotal(newTotal);
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName) return;

    try {
      const res = await api.addGroceryItem({
        name: newItemName,
        category: newItemCategory,
        quantity: newItemQuantity,
        estimatedPrice: Number(newItemPrice) || 50,
      });

      if (res.success) {
        setNewItemName('');
        setNewItemQuantity('1 unit');
        setNewItemPrice('50');
        loadGroceryList();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteItem = async (id: string) => {
    try {
      await api.deleteGroceryItem(id);
      loadGroceryList();
    } catch (err) {
      console.error(err);
    }
  };

  const handleSyncFromMealPlan = async () => {
    try {
      setLoading(true);
      await api.syncGroceryFromPlan();
      await loadGroceryList();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleClearPurchased = async () => {
    const purchasedItems = items.filter(i => i.purchased);
    for (const item of purchasedItems) {
      await api.deleteGroceryItem(item.id);
    }
    loadGroceryList();
  };

  // Group items by category
  const groupedByCategory = CATEGORIES.reduce((acc, cat) => {
    acc[cat] = items.filter(i => i.category === cat);
    return acc;
  }, {} as Record<GroceryItem['category'], GroceryItem[]>);

  const purchasedCount = items.filter(i => i.purchased).length;

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 flex items-center gap-2.5">
            <ShoppingCart className="w-6 h-6 text-emerald-600" />
            Campus Grocery &amp; Pantry Checklist
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Categorized shopping list synchronized from your weekly campus meal plans.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleSyncFromMealPlan}
            className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            Auto-Sync from Meal Plan
          </button>
          {purchasedCount > 0 && (
            <button
              onClick={handleClearPurchased}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors"
            >
              Clear Purchased ({purchasedCount})
            </button>
          )}
        </div>
      </div>

      {/* Overview Cards: Total Budget & Progress */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500">Estimated Total (Pending)</span>
          <p className="text-3xl font-black text-emerald-600 mt-1">₹{estimatedTotal}</p>
          <p className="text-[11px] text-slate-400 mt-1">Calculated from unpurchased items</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500">Checklist Items</span>
          <p className="text-3xl font-black text-slate-900 mt-1">
            {items.length}{' '}
            <span className="text-xs font-medium text-slate-400">
              ({purchasedCount} purchased)
            </span>
          </p>
          <div className="w-full bg-slate-100 rounded-full h-2 mt-2 overflow-hidden">
            <div
              className="bg-emerald-500 h-2 rounded-full"
              style={{
                width: `${items.length ? (purchasedCount / items.length) * 100 : 0}%`,
              }}
            />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500">Categories Covered</span>
          <p className="text-3xl font-black text-blue-600 mt-1">
            {Object.values(groupedByCategory).filter(arr => arr.length > 0).length} / 7
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Balanced weekly grocery groups</p>
        </div>
      </div>

      {/* Add Custom Item Form */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
          Add Custom Grocery Item
        </h3>
        <form onSubmit={handleAddItem} className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-xs">
          <div className="sm:col-span-2">
            <input
              type="text"
              required
              value={newItemName}
              onChange={e => setNewItemName(e.target.value)}
              placeholder="Item name (e.g. Rolled Oats, Green Apples)"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
            />
          </div>

          <div>
            <select
              value={newItemCategory}
              onChange={e => setNewItemCategory(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
            >
              {CATEGORIES.map(cat => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <input
              type="text"
              value={newItemQuantity}
              onChange={e => setNewItemQuantity(e.target.value)}
              placeholder="Quantity (e.g. 500g, 2 packs)"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
            />
          </div>

          <div className="flex gap-2">
            <input
              type="number"
              value={newItemPrice}
              onChange={e => setNewItemPrice(e.target.value)}
              placeholder="₹ Price"
              className="w-24 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
            />
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center justify-center gap-1 shadow-xs"
            >
              <Plus className="w-4 h-4" /> Add
            </button>
          </div>
        </form>
      </div>

      {/* Categorized Grocery List Sections */}
      <div className="space-y-6">
        {CATEGORIES.map(category => {
          const categoryItems = groupedByCategory[category];
          if (!categoryItems || categoryItems.length === 0) return null;

          return (
            <div
              key={category}
              className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-3"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  {category}
                </h3>
                <span className="text-[11px] font-semibold text-slate-400">
                  {categoryItems.filter(i => i.purchased).length} / {categoryItems.length} checked
                </span>
              </div>

              <div className="divide-y divide-slate-100">
                {categoryItems.map(item => (
                  <div
                    key={item.id}
                    className={`py-3 flex items-center justify-between gap-4 transition-opacity ${
                      item.purchased ? 'opacity-50' : 'opacity-100'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={item.purchased}
                        onChange={() => handleTogglePurchased(item)}
                        className="w-4 h-4 text-emerald-600 rounded-md border-slate-300 focus:ring-emerald-500 cursor-pointer"
                      />
                      <div>
                        <span
                          className={`text-xs font-bold text-slate-900 ${
                            item.purchased ? 'line-through text-slate-400' : ''
                          }`}
                        >
                          {item.name}
                        </span>
                        <p className="text-[11px] text-slate-400">Qty: {item.quantity}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <span className="text-xs font-mono font-bold text-slate-700">
                        ₹{item.estimatedPrice}
                      </span>
                      <button
                        onClick={() => handleDeleteItem(item.id)}
                        className="text-slate-300 hover:text-red-500 transition-colors"
                        title="Delete item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {items.length === 0 && !loading && (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 text-slate-400">
            <ShoppingCart className="w-12 h-12 mx-auto text-slate-300 mb-2" />
            <p className="text-sm font-semibold">Your grocery checklist is empty.</p>
            <p className="text-xs mt-1">
              Click "Auto-Sync from Meal Plan" to convert your planned meals into groceries.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
