import React, { useState } from 'react';
import {
  Utensils,
  Sparkles,
  Upload,
  Image as ImageIcon,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Plus,
  Flame,
  Dumbbell,
  Wheat,
  Activity,
  HeartHandshake,
} from 'lucide-react';
import { api } from '../services/api.ts';

interface FoodAnalyzerPageProps {
  onNavigate: (page: string) => void;
}

export const FoodAnalyzerPage: React.FC<FoodAnalyzerPageProps> = ({ onNavigate }) => {
  const [foodName, setFoodName] = useState('Chicken Tikka Rice Bowl');
  const [ingredients, setIngredients] = useState('Marinated chicken breast, steamed basmati rice, bell peppers, onions, light yogurt mint sauce');
  const [servingSize, setServingSize] = useState('1 standard meal box (350g)');
  const [imagePreview, setImagePreview] = useState<string | null>(
    'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&auto=format&fit=crop&q=80'
  );
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<any>({
    foodName: 'Chicken Tikka Rice Bowl',
    servingSize: '1 standard meal box (350g)',
    calories: 460,
    protein: 38,
    carbohydrates: 52,
    fat: 12,
    fiber: 5,
    sugar: 4,
    score: 84,
    summary: 'Excellent balanced campus lunch with high-quality lean protein and complex carbohydrates. Fits well into muscle building or weight maintenance goals.',
    keyHighlights: [
      'High protein density (38g) supporting athletic recovery',
      'Moderate dietary fat with low saturated content',
      'Low added sugar levels',
    ],
    healthierAlternatives: [
      'Swap white basmati rice with brown rice or quinoa to increase micronutrient density and fiber to 8g',
      'Add extra roasted broccoli or green beans to maximize volume satiety without adding calories',
    ],
  });
  const [logSuccess, setLogSuccess] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!foodName && !imagePreview) return;
    setAnalyzing(true);
    setLogSuccess(false);

    try {
      const res = await api.analyzeFood({
        foodName,
        ingredients,
        servingSize,
        imageBase64: imagePreview,
      });

      if (res.success && res.data) {
        setAnalysis(res.data);
      }
    } catch (err) {
      console.error('Error analyzing food:', err);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleLogMeal = async () => {
    if (!analysis) return;
    try {
      await api.logMeal({
        foodName: analysis.foodName,
        mealType: 'Lunch',
        calories: analysis.calories,
        protein: analysis.protein,
        carbs: analysis.carbohydrates,
        fat: analysis.fat,
        fiber: analysis.fiber,
      });
      setLogSuccess(true);
      setTimeout(() => setLogSuccess(false), 3000);
    } catch (err) {
      console.error('Error logging meal:', err);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-16">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 flex items-center gap-2.5">
          <Utensils className="w-6 h-6 text-emerald-600" />
          AI Food &amp; Nutrition Analyzer
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Evaluate any hostel meal, cafeteria dish, or recipe with AI nutritional scoring and healthier swaps.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Input Form (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-5">
          <h2 className="text-sm font-bold text-slate-900">Food Details &amp; Image</h2>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">Food / Dish Name</label>
            <input
              type="text"
              value={foodName}
              onChange={e => setFoodName(e.target.value)}
              placeholder="e.g. Paneer Wrap, Veg Biryani, Whey Shake"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Ingredients / Description
            </label>
            <textarea
              rows={3}
              value={ingredients}
              onChange={e => setIngredients(e.target.value)}
              placeholder="Key ingredients or cooking style..."
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-blue-500 resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">Serving Size</label>
            <input
              type="text"
              value={servingSize}
              onChange={e => setServingSize(e.target.value)}
              placeholder="e.g. 1 plate (300g), 2 slices, 1 cup"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-blue-500"
            />
          </div>

          {/* Image Upload Area */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Food Image (Optional)
            </label>
            <div className="relative border-2 border-dashed border-slate-200 hover:border-emerald-400 rounded-2xl p-4 text-center transition-colors">
              {imagePreview ? (
                <div className="relative group">
                  <img
                    src={imagePreview}
                    alt="Uploaded food"
                    className="w-full h-36 object-cover rounded-xl"
                  />
                  <div className="absolute inset-0 bg-black/40 rounded-xl opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <label className="px-3 py-1.5 bg-white text-slate-800 text-xs font-bold rounded-lg cursor-pointer">
                      Change Image
                      <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                    </label>
                  </div>
                </div>
              ) : (
                <label className="cursor-pointer block py-4">
                  <ImageIcon className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <span className="text-xs font-bold text-emerald-700">Click to upload photo</span>
                  <p className="text-[10px] text-slate-400 mt-1">JPG, PNG or WEBP</p>
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </label>
              )}
            </div>
          </div>

          <button
            onClick={handleAnalyze}
            disabled={analyzing}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all"
          >
            <Sparkles className={`w-4 h-4 ${analyzing ? 'animate-spin' : ''}`} />
            {analyzing ? 'Analyzing with AI...' : 'Analyze Nutrition'}
          </button>
        </div>

        {/* Right Analysis Result (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {analyzing ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs space-y-4 animate-pulse">
              <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                <Sparkles className="w-8 h-8 animate-spin" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">Analyzing your food...</h3>
              <p className="text-xs text-slate-500">
                Evaluating caloric distribution, macronutrient density, and health alternatives...
              </p>
            </div>
          ) : analysis ? (
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
              {/* Score Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-6">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Analysis Result
                  </span>
                  <h2 className="text-xl font-black text-slate-900 mt-0.5">{analysis.foodName}</h2>
                  <p className="text-xs text-slate-500">{analysis.servingSize}</p>
                </div>

                {/* Nutrition Score Dial */}
                <div className="flex items-center gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-100">
                  <div
                    className={`w-14 h-14 rounded-2xl flex items-center justify-center font-black text-xl text-white shadow-sm ${
                      analysis.score >= 80
                        ? 'bg-emerald-600'
                        : analysis.score >= 60
                        ? 'bg-amber-500'
                        : 'bg-red-500'
                    }`}
                  >
                    {analysis.score}
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-800">Nutrition Score</p>
                    <p className="text-[11px] text-slate-500">
                      {analysis.score >= 80
                        ? 'Optimal / Nutrient Rich'
                        : analysis.score >= 60
                        ? 'Moderate / Acceptable'
                        : 'Calorically Dense'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Macronutrient Metric Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-orange-50/70 p-3.5 rounded-2xl border border-orange-100">
                  <span className="text-[10px] font-bold text-orange-700 uppercase">Calories</span>
                  <p className="text-xl font-black text-orange-950 mt-1">{analysis.calories} kcal</p>
                </div>

                <div className="bg-emerald-50/70 p-3.5 rounded-2xl border border-emerald-100">
                  <span className="text-[10px] font-bold text-emerald-700 uppercase">Protein</span>
                  <p className="text-xl font-black text-emerald-950 mt-1">{analysis.protein}g</p>
                </div>

                <div className="bg-blue-50/70 p-3.5 rounded-2xl border border-blue-100">
                  <span className="text-[10px] font-bold text-blue-700 uppercase">Carbohydrates</span>
                  <p className="text-xl font-black text-blue-950 mt-1">{analysis.carbohydrates}g</p>
                </div>

                <div className="bg-amber-50/70 p-3.5 rounded-2xl border border-amber-100">
                  <span className="text-[10px] font-bold text-amber-700 uppercase">Fat / Fiber</span>
                  <p className="text-sm font-bold text-amber-950 mt-1">
                    {analysis.fat}g fat • {analysis.fiber || 3}g fiber
                  </p>
                </div>
              </div>

              {/* Summary */}
              <div>
                <h3 className="text-xs font-bold text-slate-700 mb-2">Nutritional Summary</h3>
                <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  {analysis.summary}
                </p>
              </div>

              {/* Key Highlights */}
              {analysis.keyHighlights && analysis.keyHighlights.length > 0 && (
                <div>
                  <h3 className="text-xs font-bold text-slate-700 mb-2">Key Highlights</h3>
                  <div className="space-y-1.5">
                    {analysis.keyHighlights.map((highlight: string, i: number) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{highlight}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Healthier Alternatives */}
              {analysis.healthierAlternatives && analysis.healthierAlternatives.length > 0 && (
                <div className="bg-emerald-50/40 p-4 rounded-2xl border border-emerald-100">
                  <h3 className="text-xs font-bold text-emerald-800 mb-2 flex items-center gap-1.5">
                    <HeartHandshake className="w-4 h-4 text-emerald-600" />
                    Recommended Healthier Alternatives
                  </h3>
                  <ul className="space-y-2 text-xs text-slate-700">
                    {analysis.healthierAlternatives.map((alt: string, i: number) => (
                      <li key={i} className="flex items-start gap-2">
                        <ArrowRight className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{alt}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Quick Log Action Button */}
              <div className="pt-2 flex items-center justify-between">
                <span className="text-xs text-slate-400">Log this meal into today's calorie tracker</span>
                <button
                  onClick={handleLogMeal}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  {logSuccess ? 'Logged Successfully!' : 'Log To Today\'s Meals'}
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 text-slate-400">
              <Utensils className="w-12 h-12 mx-auto text-slate-300 mb-3" />
              <p className="text-sm font-semibold">Enter food details to run analysis</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
