import React, { useState, useEffect } from 'react';
import {
  FolderHeart,
  PlusCircle,
  Clock,
  CheckCircle2,
  AlertCircle,
  MapPin,
  Calendar,
  ChevronRight,
  ShieldCheck,
  Tag,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { LostFoundItem, Claim } from '../types.ts';

interface MyReportsPageProps {
  onNavigate: (page: string) => void;
}

export const MyReportsPage: React.FC<MyReportsPageProps> = ({ onNavigate }) => {
  const [items, setItems] = useState<LostFoundItem[]>([]);
  const [claims, setClaims] = useState<Claim[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'ITEMS' | 'CLAIMS'>('ITEMS');

  useEffect(() => {
    loadMyData();
  }, []);

  const loadMyData = async () => {
    try {
      setLoading(true);
      const res = await api.getMyReports();
      if (res.success && res.data) {
        setItems(res.data.items || []);
        setClaims(res.data.claims || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getClaimBadge = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'PENDING':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'MORE_INFO_NEEDED':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'REJECTED':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 flex items-center gap-2.5">
            <FolderHeart className="w-6 h-6 text-amber-600" />
            My Reports &amp; Claims
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Track all property reports you have lodged and monitor verification claim approvals.
          </p>
        </div>

        <button
          onClick={() => onNavigate('lost-found/report-lost')}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 self-start sm:self-auto transition-colors"
        >
          <PlusCircle className="w-4 h-4" /> Report New Item
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
        <button
          onClick={() => setTab('ITEMS')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            tab === 'ITEMS'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          My Reported Items ({items.length})
        </button>
        <button
          onClick={() => setTab('CLAIMS')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            tab === 'CLAIMS'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          My Submitted Claims ({claims.length})
        </button>
      </div>

      {/* Content */}
      {tab === 'ITEMS' ? (
        <div className="space-y-4">
          {items.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 text-slate-400">
              <FolderHeart className="w-12 h-12 mx-auto text-slate-300 mb-2" />
              <p className="text-sm font-semibold">You haven't reported any items yet.</p>
              <button
                onClick={() => onNavigate('lost-found/report-lost')}
                className="mt-3 px-4 py-2 bg-blue-600 text-white text-xs font-bold rounded-xl inline-flex items-center gap-1.5"
              >
                <PlusCircle className="w-3.5 h-3.5" /> Report Lost Item
              </button>
            </div>
          ) : (
            items.map(item => (
              <div
                key={item.id}
                onClick={() => onNavigate(`lost-found/${item.id}`)}
                className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs hover:border-slate-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer"
              >
                <div className="flex items-center gap-4">
                  <img
                    src={item.imageUrl || 'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=100'}
                    alt={item.itemName}
                    className="w-16 h-16 rounded-2xl object-cover bg-slate-100 shrink-0"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                          item.type === 'LOST'
                            ? 'bg-red-100 text-red-700'
                            : 'bg-emerald-100 text-emerald-700'
                        }`}
                      >
                        {item.type}
                      </span>
                      <span className="text-xs font-mono text-slate-400">{item.trackingId}</span>
                    </div>
                    <h3 className="font-bold text-slate-900 text-sm mt-1">{item.itemName}</h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      📍 {item.location} • 📅 {item.date}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 self-end sm:self-auto">
                  <span
                    className={`text-xs font-bold px-3 py-1 rounded-full uppercase border ${
                      item.status === 'MATCHED'
                        ? 'bg-purple-100 text-purple-700 border-purple-200 animate-pulse'
                        : item.status === 'LOST'
                        ? 'bg-red-50 text-red-700 border-red-200'
                        : item.status === 'RETURNED'
                        ? 'bg-green-100 text-green-800 border-green-200'
                        : 'bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    {item.status.replace('_', ' ')}
                  </span>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {claims.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 text-slate-400">
              <ShieldCheck className="w-12 h-12 mx-auto text-slate-300 mb-2" />
              <p className="text-sm font-semibold">No claim requests submitted yet.</p>
              <p className="text-xs mt-1">
                When you locate a found item matching your belongings, submit a claim for security review.
              </p>
            </div>
          ) : (
            claims.map(claim => (
              <div
                key={claim.id}
                className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4"
              >
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <span className="text-xs font-bold text-slate-400 uppercase">
                      Claim on Item
                    </span>
                    <h3 className="text-base font-black text-slate-900 mt-0.5">
                      {claim.itemTitle || 'Campus Found Item'}
                    </h3>
                  </div>
                  <span
                    className={`text-xs font-bold px-3 py-1 rounded-full uppercase border ${getClaimBadge(
                      claim.status
                    )}`}
                  >
                    {claim.status.replace('_', ' ')}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="bg-slate-50 p-3 rounded-xl">
                    <span className="font-bold text-slate-700 block">Reported Where/When</span>
                    <p className="text-slate-600 mt-0.5">
                      {claim.whereLost} ({claim.whenLost})
                    </p>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl">
                    <span className="font-bold text-slate-700 block">
                      Identifying Feature Given
                    </span>
                    <p className="text-slate-600 mt-0.5">{claim.uniqueFeature}</p>
                  </div>
                </div>

                {claim.adminNotes && (
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900">
                    <span className="font-bold block">Security Desk Note:</span>
                    <p className="mt-0.5">{claim.adminNotes}</p>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
