import React from 'react';
import {
  Bell,
  CheckCheck,
  Sparkles,
  ShieldCheck,
  Utensils,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { useNotifications } from '../context/NotificationContext.tsx';

interface NotificationsPageProps {
  onNavigate: (page: string) => void;
}

export const NotificationsPage: React.FC<NotificationsPageProps> = ({ onNavigate }) => {
  const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotifications();

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 flex items-center gap-2.5">
            <Bell className="w-6 h-6 text-blue-600" />
            Notifications
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Stay informed on AI match alerts, claim approvals, and meal plan updates.
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={markAllAsRead}
            className="px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold rounded-xl border border-blue-200 flex items-center gap-1.5 self-start sm:self-auto transition-colors"
          >
            <CheckCheck className="w-4 h-4" />
            Mark all as read
          </button>
        )}
      </div>

      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs divide-y divide-slate-100">
        {notifications.length === 0 ? (
          <div className="text-center py-12 text-slate-400 text-xs">
            No notifications in your inbox.
          </div>
        ) : (
          notifications.map(notif => (
            <div
              key={notif.id}
              onClick={() => {
                markAsRead(notif.id);
                if (notif.link) onNavigate(notif.link.replace(/^\//, ''));
              }}
              className={`p-4 hover:bg-slate-50 cursor-pointer rounded-2xl transition-colors flex items-start justify-between gap-4 ${
                !notif.isRead ? 'bg-blue-50/40' : ''
              }`}
            >
              <div className="flex items-start gap-3.5">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                    notif.type === 'match'
                      ? 'bg-amber-100 text-amber-700'
                      : notif.type === 'claim'
                      ? 'bg-purple-100 text-purple-700'
                      : notif.type === 'meal_plan'
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-blue-100 text-blue-700'
                  }`}
                >
                  {notif.type === 'match' ? (
                    <Sparkles className="w-4 h-4" />
                  ) : notif.type === 'meal_plan' ? (
                    <Utensils className="w-4 h-4" />
                  ) : (
                    <Bell className="w-4 h-4" />
                  )}
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-slate-900 text-sm">{notif.title}</h3>
                    {!notif.isRead && (
                      <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0" />
                    )}
                  </div>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">{notif.message}</p>
                  <span className="text-[10px] text-slate-400 mt-2 block">
                    {new Date(notif.createdAt).toLocaleDateString()} at{' '}
                    {new Date(notif.createdAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
              </div>

              {notif.link && <ChevronRight className="w-4 h-4 text-slate-400 shrink-0 mt-2" />}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
