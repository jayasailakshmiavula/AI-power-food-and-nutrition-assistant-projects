import React, { useState, useEffect } from 'react';
import {
  Flame,
  Dumbbell,
  Wheat,
  Droplet,
  Plus,
  Trash2,
  Calendar,
  Sparkles,
  TrendingUp,
  Scale,
  PieChart as PieIcon,
  BarChart3,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { api } from '../services/api.ts';
import { MealLog } from '../types.ts';

const MACRO_COLORS = ['#10B981', '#3B82F6', '#F59E0B'];

export const DailySummaryPage: React.FC = () => {
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // New Meal Log form modal
  const [showLogModal, setShowLogModal] = useState(false);
  const [foodName, setFoodName] = useState('');
  const [mealType, setMealType] = useState('Breakfast');
  const [calories, setCalories] = useState('');
  const [protein, setProtein] = useState('');
  const [carbs, setCarbs] = useState('');
  const [fat, setFat] = useState('');

  const loadSummary = async () => {
    try {
      setLoading(true);
      const res = await api.getDailySummary();
      if (res.success) {
        setSummary(res.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSummary();
  }, []);

  const handleCreateMealLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!foodName || !calories) return;

    try {
      await api.logMeal({
        foodName,
        mealType,
        calories: Number(calories),
        protein: Number(protein) || 0,
        carbs: Number(carbs) || 0,
        fat: Number(fat) || 0,
      });

      setShowLogModal(false);
      setFoodName('');
      setCalories('');
      setProtein('');
      setCarbs('');
      setFat('');
      loadSummary();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteLog = async (id: string) => {
    try {
      await api.deleteMealLog(id);
      loadSummary();
    } catch (err) {
      console.error(err);
    }
  };

  const consumed = summary?.consumed || { calories: 1200, protein: 64, carbs: 158, fat: 38, fiber: 20, water: 2200 };
  const goals = summary?.goals || { calories: 2200, protein: 120, carbs: 250, fat: 60, water: 3000 };
  const percentages = summary?.percentages || { calories: 55, protein: 53, carbs: 63, fat: 63 };

  // Macro pie chart data
  const macroData = [
    { name: 'Protein (g)', value: consumed.protein },
    { name: 'Carbs (g)', value: consumed.carbs },
    { name: 'Fat (g)', value: consumed.fat },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 flex items-center gap-2.5">
            <Flame className="w-6 h-6 text-orange-500" />
            Daily Nutrition Summary &amp; Analytics
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Track daily calories, macronutrient balance, 7-day progress, and meal logs.
          </p>
        </div>

        <button
          onClick={() => setShowLogModal(true)}
          className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-600/20 flex items-center gap-2 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Log Meal
        </button>
      </div>

      {/* Progress Bars Summary Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
        <h2 className="text-sm font-bold text-slate-900">Today's Caloric &amp; Nutrient Progress</h2>

        <div className="space-y-4">
          {/* Calories Progress */}
          <div>
            <div className="flex justify-between items-center text-xs font-bold mb-1.5">
              <span className="flex items-center gap-2 text-slate-800">
                <Flame className="w-4 h-4 text-orange-500" /> Calories
              </span>
              <span className="font-mono text-orange-600">
                {consumed.calories} / {goals.calories} kcal ({percentages.calories}%)
              </span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
              <div
                className="bg-orange-500 h-3 rounded-full transition-all duration-500"
                style={{ width: `${percentages.calories}%` }}
              />
            </div>
          </div>

          {/* Protein Progress */}
          <div>
            <div className="flex justify-between items-center text-xs font-bold mb-1.5">
              <span className="flex items-center gap-2 text-slate-800">
                <Dumbbell className="w-4 h-4 text-emerald-600" /> Protein
              </span>
              <span className="font-mono text-emerald-600">
                {consumed.protein}g / {goals.protein}g ({percentages.protein}%)
              </span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
              <div
                className="bg-emerald-500 h-3 rounded-full transition-all duration-500"
                style={{ width: `${percentages.protein}%` }}
              />
            </div>
          </div>

          {/* Carbs Progress */}
          <div>
            <div className="flex justify-between items-center text-xs font-bold mb-1.5">
              <span className="flex items-center gap-2 text-slate-800">
                <Wheat className="w-4 h-4 text-blue-500" /> Carbohydrates
              </span>
              <span className="font-mono text-blue-600">
                {consumed.carbs}g / {goals.carbs}g ({percentages.carbs}%)
              </span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
              <div
                className="bg-blue-500 h-3 rounded-full transition-all duration-500"
                style={{ width: `${percentages.carbs}%` }}
              />
            </div>
          </div>

          {/* Water Progress */}
          <div>
            <div className="flex justify-between items-center text-xs font-bold mb-1.5">
              <span className="flex items-center gap-2 text-slate-800">
                <Droplet className="w-4 h-4 text-cyan-500" /> Hydration
              </span>
              <span className="font-mono text-cyan-600">
                {consumed.water}ml / {goals.water}ml ({Math.min(Math.round((consumed.water / goals.water) * 100), 100)}%)
              </span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
              <div
                className="bg-cyan-500 h-3 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(Math.round((consumed.water / goals.water) * 100), 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Recharts Analytics Grid (2x2) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Calories Progress Chart */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-blue-600" />
              7-Day Caloric Intake
            </h3>
            <span className="text-[11px] text-slate-400">Target: {goals.calories} kcal</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={summary?.weeklyProgress || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="day" stroke="#94A3B8" fontSize={11} />
                <YAxis stroke="#94A3B8" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1E293B', borderRadius: '12px', color: '#fff', fontSize: '11px' }}
                />
                <Bar dataKey="calories" fill="#3B82F6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Macronutrient Distribution Chart */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-emerald-600" />
              Today's Macronutrient Split (Grams)
            </h3>
            <span className="text-[11px] text-slate-400">Protein / Carbs / Fat</span>
          </div>
          <div className="h-64 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={macroData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {macroData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={MACRO_COLORS[index % MACRO_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#1E293B', borderRadius: '12px', color: '#fff', fontSize: '11px' }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Weekly Protein Progress Chart */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              Weekly Protein Adherence
            </h3>
            <span className="text-[11px] text-slate-400">Target: {goals.protein}g</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={summary?.weeklyProgress || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="day" stroke="#94A3B8" fontSize={11} />
                <YAxis stroke="#94A3B8" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1E293B', borderRadius: '12px', color: '#fff', fontSize: '11px' }}
                />
                <Line type="monotone" dataKey="protein" stroke="#10B981" strokeWidth={3} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Weight Progress Chart */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Scale className="w-4 h-4 text-purple-600" />
              Weight Progression (kg)
            </h3>
            <span className="text-[11px] text-slate-400">Campus Goal Progress</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={summary?.weightProgress || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="date" stroke="#94A3B8" fontSize={11} />
                <YAxis stroke="#94A3B8" fontSize={11} domain={['dataMin - 1', 'dataMax + 1']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1E293B', borderRadius: '12px', color: '#fff', fontSize: '11px' }}
                />
                <Line type="monotone" dataKey="weight" stroke="#8B5CF6" strokeWidth={3} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Today's Logged Meals Table */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">Today's Logged Meals</h3>
          <span className="text-xs text-slate-400">
            {summary?.todayLogs?.length || 0} meals registered today
          </span>
        </div>

        {summary?.todayLogs && summary.todayLogs.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Meal</th>
                  <th className="py-3 px-4">Food Item</th>
                  <th className="py-3 px-4">Calories</th>
                  <th className="py-3 px-4">Protein</th>
                  <th className="py-3 px-4">Carbs</th>
                  <th className="py-3 px-4">Fat</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {summary.todayLogs.map((log: MealLog) => (
                  <tr key={log.id} className="hover:bg-slate-50/50">
                    <td className="py-3 px-4 font-bold text-slate-900">{log.mealType}</td>
                    <td className="py-3 px-4">{log.foodName}</td>
                    <td className="py-3 px-4 font-mono font-bold">{log.calories} kcal</td>
                    <td className="py-3 px-4">{log.protein}g</td>
                    <td className="py-3 px-4">{log.carbs}g</td>
                    <td className="py-3 px-4">{log.fat}g</td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleDeleteLog(log.id)}
                        className="text-red-500 hover:text-red-700 p-1 rounded-md"
                        title="Delete meal"
                      >
                        <Trash2 className="w-4 h-4 inline" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8 text-slate-400 text-xs">
            No meals logged for today yet. Click "Log Meal" to record your food.
          </div>
        )}
      </div>

      {/* Log Meal Modal */}
      {showLogModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200">
            <h2 className="text-base font-bold text-slate-900 mb-4">Log Food / Meal</h2>
            <form onSubmit={handleCreateMealLog} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Meal Type</label>
                <select
                  value={mealType}
                  onChange={e => setMealType(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                >
                  <option value="Breakfast">Breakfast</option>
                  <option value="Lunch">Lunch</option>
                  <option value="Snack">Snack</option>
                  <option value="Dinner">Dinner</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Food Name</label>
                <input
                  type="text"
                  required
                  value={foodName}
                  onChange={e => setFoodName(e.target.value)}
                  placeholder="e.g. Scrambled Eggs & Toast"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Calories (kcal)</label>
                  <input
                    type="number"
                    required
                    value={calories}
                    onChange={e => setCalories(e.target.value)}
                    placeholder="350"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Protein (g)</label>
                  <input
                    type="number"
                    value={protein}
                    onChange={e => setProtein(e.target.value)}
                    placeholder="20"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Carbs (g)</label>
                  <input
                    type="number"
                    value={carbs}
                    onChange={e => setCarbs(e.target.value)}
                    placeholder="40"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Fat (g)</label>
                  <input
                    type="number"
                    value={fat}
                    onChange={e => setFat(e.target.value)}
                    placeholder="10"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowLogModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-xs"
                >
                  Save Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
